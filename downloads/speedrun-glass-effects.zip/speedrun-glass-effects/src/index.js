import './runtime/glass.css';
import './styles.css';
import preset from './runtime/final.json';
import {createGlassSurface} from './runtime/engine.js';
import {createHoverMotion} from './runtime/hover-motion.js';
import {entryOrigin, quoteArrival} from './runtime/triggers.js';

const mounted = new WeakMap();
const merge = (base, next = {}) => {
  const result = structuredClone(base);
  for (const [key, value] of Object.entries(next)) {
    if (value === undefined) continue;
    result[key] = value && typeof value === 'object' && !Array.isArray(value)
      ? merge(result[key] || {}, value) : structuredClone(value);
  }
  return result;
};
const resolve = (target, name = 'element') => {
  const element = typeof target === 'string' ? document.querySelector(target) : target;
  if (!(element instanceof HTMLElement)) throw new TypeError(`Glass ${name} must be an HTMLElement or a matching selector.`);
  return element;
};
const listen = (node, type, handler, options, cleanup) => {
  node.addEventListener(type, handler, options);
  cleanup.push(() => node.removeEventListener(type, handler, options));
};
function attributes(element, names) {
  const previous = names.map(name => [name, element.getAttribute(name)]);
  return () => previous.forEach(([name, value]) => value === null ? element.removeAttribute(name) : element.setAttribute(name, value));
}
function classes(element, names) {
  const added = names.filter(name => !element.classList.contains(name));
  element.classList.add(...added);
  return () => element.classList.remove(...added);
}
function styles(element, values) {
  const previous = Object.keys(values).map(name => [name, element.style.getPropertyValue(name), element.style.getPropertyPriority(name)]);
  for (const [name, value] of Object.entries(values)) element.style.setProperty(name, value);
  return () => previous.forEach(([name, value, priority]) => value ? element.style.setProperty(name, value, priority) : element.style.removeProperty(name));
}
const span = name => {const element = document.createElement('span'); element.className = name; return element;};

/** A fresh copy prevents one component's overrides from changing the locked preset. */
export function getGlassPreset() {return structuredClone(preset);}

/** Enhances an existing native button/link; never replaces its click behavior. */
export function mountGlassButton(target, {video = null, lift = true, settings = {}} = {}) {
  const element = resolve(target);
  if (mounted.has(element)) return mounted.get(element);
  const source = video ? resolve(video, 'video') : null;
  if (source && !(source instanceof HTMLVideoElement)) throw new TypeError('Glass video must be a <video> element.');
  let config = merge(preset.button, settings), destroyed = false;
  const cleanup = [];
  const restoreAttributes = attributes(element, ['data-sr-glass-video']);
  if (source) element.setAttribute('data-sr-glass-video', '');
  const restoreClasses = classes(element, ['sr-glass-kit-button']);
  const restoreStyles = styles(element, {padding: '0', background: 'none'});
  // Frameworks may render this stable anatomy themselves; plain HTML is wrapped.
  let visual = element.querySelector(':scope > .sr-button-visual');
  const wrapped = !visual;
  let clip, content, hit;
  if (wrapped) {
    visual = span('sr-button-visual'); clip = span('sr-button-clip'); content = span('sr-button-content');
    while (element.firstChild) content.append(element.firstChild);
    clip.append(content); visual.append(clip); element.append(visual);
  } else {
    clip = visual.querySelector(':scope > .sr-button-clip');
    content = clip?.querySelector(':scope > .sr-button-content');
    if (!clip || !content) {
      restoreStyles(); restoreClasses(); restoreAttributes();
      throw new TypeError('Existing .sr-button-visual requires .sr-button-clip > .sr-button-content.');
    }
  }
  hit = element.querySelector(':scope > .sr-button-hit-area');
  const ownHit = !hit;
  if (ownHit) {hit = span('sr-button-hit-area'); hit.setAttribute('aria-hidden', 'true'); element.append(hit);}
  const surface = createGlassSurface(element, {kind:'button', content:visual, settings:config, video:source});
  clip.append(element.querySelector(':scope > .sr-glass-fx'));
  const hoverSettings = () => lift ? config : {...config, lift:0, hoverScale:1};
  const hover = createHoverMotion(element, hoverSettings(), {onFrame:() => surface.refreshMaterial()});
  const enabled = () => !element.matches(':disabled,[aria-disabled="true"]');
  const leave = () => {element.classList.remove('sr-glass-hovered'); hover.leave();};
  const reset = () => {surface.reset(); hover.reset(); element.classList.remove('sr-glass-hovered');};
  const enter = event => {
    if (!enabled() || event.pointerType === 'touch') return;
    element.classList.add('sr-glass-hovered'); hover.enter();
    surface.play(config.hoverOrigin === 'entry'
      ? entryOrigin(element.getBoundingClientRect(), event.clientX, event.clientY, config.origin) : config.origin);
  };
  listen(element, 'pointerenter', enter, undefined, cleanup);
  listen(element, 'pointerleave', leave, undefined, cleanup);
  listen(element, 'blur', leave, undefined, cleanup);
  listen(element, 'focus', () => {if (element.matches(':focus-visible')) enter({});}, undefined, cleanup);
  listen(element, 'click', event => {
    if (!enabled()) return;
    const rect = element.getBoundingClientRect();
    const origin = event.detail && config.clickOrigin === 'pointer'
      ? {x:(event.clientX-rect.left)/rect.width, y:(event.clientY-rect.top)/rect.height} : config.origin;
    surface.play(origin);
  }, true, cleanup);
  listen(document, 'visibilitychange', () => {if (document.hidden) reset();}, undefined, cleanup);
  const visibility = new IntersectionObserver(entries => {if (!entries[0].isIntersecting) reset();});
  visibility.observe(element); cleanup.push(() => visibility.disconnect());
  const api = {
    play(origin = config.origin) {if (!destroyed && enabled()) surface.play(origin);},
    reset() {if (!destroyed) reset();},
    update(next) {if (destroyed) return; config=merge(config,next); surface.update(config); hover.update(hoverSettings());},
    destroy() {
      if (destroyed) return;
      destroyed = true; cleanup.forEach(stop => stop()); hover.destroy(); surface.destroy();
      element.classList.remove('sr-glass-hovered');
      if (ownHit) hit.remove();
      if (wrapped) {while (content.firstChild) element.insertBefore(content.firstChild, visual); visual.remove();}
      restoreStyles(); restoreClasses(); restoreAttributes(); mounted.delete(element);
    },
  };
  mounted.set(element, api); return api;
}

/** Scroll collects, visibility releases, and clicks start a fresh outward ripple. */
export function mountGlassQuote(target, {content: suppliedContent, headerOffset = 64, settings = {}, scroll = true} = {}) {
  const element = resolve(target);
  if (mounted.has(element)) return mounted.get(element);
  if (!Number.isFinite(headerOffset) || headerOffset < 0) throw new TypeError('headerOffset must be a nonnegative number.');
  let content = suppliedContent ? resolve(suppliedContent, 'content') : element.querySelector(':scope > .sr-quote-content');
  if (content && (content === element || !element.contains(content))) throw new TypeError('Quote content must be inside its frame.');
  const wrapped = !content;
  if (wrapped) {content=document.createElement('div'); while (element.firstChild) content.append(element.firstChild); element.append(content);}
  const restoreRoot = classes(element, ['sr-glass-kit-quote']);
  const restoreContent = classes(content, ['sr-quote-content']);
  let config=merge(preset.quote,settings), visible=false, released=false, frame=0, destroyed=false;
  const cleanup=[];
  const surface=createGlassSurface(element,{kind:'quote',content,settings:config});
  const cancel=() => {if(frame) cancelAnimationFrame(frame); frame=0;};
  const updateArrival=() => {
    frame=0;
    if(destroyed || !scroll || !visible || released || document.hidden) return;
    const arrival=quoteArrival(element.getBoundingClientRect(),innerHeight,config.warmup,headerOffset);
    if(!arrival.visible) {surface.reset(); return;}
    if(arrival.release) {released=true; surface.play({...config.origin,fromWarmup:config.warmup.enabled});}
    else if(config.warmup.enabled) surface.warmup(arrival.progress,config.origin);
    else surface.reset();
  };
  const queue=() => {if(!frame && scroll && visible && !released && !destroyed) frame=requestAnimationFrame(updateArrival);};
  const reset=() => {cancel(); released=false; surface.reset();};
  const visibility=new IntersectionObserver(entries => {
    visible=entries[0].isIntersecting;
    window.removeEventListener('scroll',queue);
    if(visible) {if(scroll) window.addEventListener('scroll',queue,{passive:true}); queue();}
    else reset();
  },{rootMargin:`-${headerOffset}px 0px 0px 0px`});
  visibility.observe(element);
  cleanup.push(() => {visibility.disconnect(); window.removeEventListener('scroll',queue);});
  listen(window,'resize',queue,{passive:true},cleanup);
  listen(document,'visibilitychange',() => {if(document.hidden) cancel(); else queue();},undefined,cleanup);
  const play=(origin=config.origin) => {if(destroyed) return; cancel(); released=true; surface.play({...origin,fromWarmup:false,click:true});};
  listen(element,'click',event => {
    if(getSelection()?.toString() || event.target.closest?.('a,button,input,textarea,select,[contenteditable="true"]')) return;
    const rect=element.getBoundingClientRect();
    play(event.detail && config.clickOrigin==='pointer'
      ? {x:(event.clientX-rect.left)/rect.width,y:(event.clientY-rect.top)/rect.height} : config.origin);
  },undefined,cleanup);
  const api={
    play,
    reset() {if(!destroyed) reset();},
    update(next) {if(destroyed) return; config=merge(config,next); surface.update(config); queue();},
    destroy() {
      if(destroyed) return; destroyed=true; cancel(); cleanup.forEach(stop=>stop()); surface.destroy();
      restoreRoot(); restoreContent();
      if(wrapped) {while(content.firstChild) element.insertBefore(content.firstChild,content); content.remove();}
      mounted.delete(element);
    },
  };
  mounted.set(element,api); return api;
}

/** Optional HTML-only setup. Call destroy() before removing its subtree. */
export function mountGlass(root=document) {
  const effects=[];
  try {
    for(const element of root.querySelectorAll('[data-glass-button]')) effects.push(mountGlassButton(element,{
      video:element.getAttribute('data-glass-video') || null,
      lift:element.getAttribute('data-glass-lift')!=='off',
    }));
    for(const element of root.querySelectorAll('[data-glass-quote]')) effects.push(mountGlassQuote(element,{
      headerOffset:Number(element.getAttribute('data-glass-header-offset') ?? 64),
    }));
  } catch(error) {effects.forEach(effect=>effect.destroy()); throw error;}
  return {destroy() {effects.forEach(effect=>effect.destroy());}};
}
