/** Pure animation math. No DOM, timers or dependencies. */
export const clamp = (value, min = 0, max = 1) => Math.min(max, Math.max(min, value));
export const smoothstep = (value) => { const t = clamp(value); return t * t * (3 - 2 * t); };
export const RIPPLE_CENTER = .68;

export function cubicBezier(progress, curve = [.22, .1, .25, 1]) {
  const p = clamp(progress);
  if (p === 0 || p === 1) return p;
  const [ax, ay, bx, by] = curve;
  const sample = (t, a, b) => 3 * (1 - t) ** 2 * t * a + 3 * (1 - t) * t * t * b + t ** 3;
  let low = 0, high = 1;
  for (let i = 0; i < 22; i++) {
    const mid = (low + high) / 2;
    if (sample(mid, clamp(ax), clamp(bx)) < p) low = mid;
    else high = mid;
  }
  return sample((low + high) / 2, ay, by);
}

export function normalizeEnvelope(points, {zeroEnds = true} = {}) {
  const values = new Map();
  for (const point of Array.isArray(points) ? points : []) {
    if (Number.isFinite(point?.t) && Number.isFinite(point?.value)) {
      const normalized = {value:clamp(point.value,0,2)};
      if (Array.isArray(point.ease) && point.ease.length === 4 && point.ease.every(Number.isFinite)) normalized.ease = point.ease.map(value=>clamp(value));
      values.set(clamp(point.t),normalized);
    }
  }
  for (const t of [0,1]) {
    if (zeroEnds) values.set(t,{...values.get(t),value:0});
    else if (!values.has(t)) values.set(t,{value:1});
  }
  return [...values].sort((a, b) => a[0] - b[0]).map(([t, point]) => ({ t, ...point }));
}

/** Smooth interpolation also supports nonzero endpoints (e.g. hue keyframes). */
export function keyframeAt(progress, points) {
  const p = clamp(progress);
  if (!points?.length) return 0;
  if (p <= points[0].t) return points[0].value;
  for (let index = 1; index < points.length; index++) {
    const next = points[index], previous = points[index - 1];
    if (p === next.t) return next.value;
    if (p <= next.t) {
      const time = (p - previous.t) / Math.max(.000001, next.t - previous.t);
      const local = previous.ease ? cubicBezier(time,previous.ease) : smoothstep(time);
      return previous.value + (next.value - previous.value) * local;
    }
  }
  return points.at(-1).value;
}

export function envelopeAt(progress, points) {
  const p = clamp(progress);
  return p === 0 || p === 1 ? 0 : keyframeAt(p, points);
}

/** Unit peak, positive/negative pair: compression followed by stretching. */
export function gaussianDerivative(q) { return q * Math.exp((1 - q * q) / 2); }
export function farthestCorner(width, height, x, y) {
  return Math.hypot(Math.max(x, width - x), Math.max(y, height - y));
}

/** Band width is shared by displacement and all visible radial gradients. */
export function rippleSigma(width) { return .015 + clamp(width, .05, .8) * .15; }
export function radialDisplacement(x, y, width) {
  const radius = Math.hypot(x, y);
  if (radius < .00001 || radius >= 1) return [0, 0];
  const fade = smoothstep((1 - radius) / .045) * smoothstep(radius / .045);
  const value = gaussianDerivative((radius - RIPPLE_CENTER) / rippleSigma(width)) * fade;
  return [x / radius * value, y / radius * value];
}

const lightDuration = settings => Number.isFinite(settings.coreDuration) && settings.coreDuration > 0 ? settings.coreDuration : settings.duration;
const releaseFade = settings => Number.isFinite(settings.warmup?.releaseFade) ? Math.max(0,settings.warmup.releaseFade) : settings.duration * .3;
const warmupCarry = (elapsed,settings,fromWarmup) => {
  const fade = releaseFade(settings);
  return fromWarmup && settings.warmup?.enabled && fade > 0 ? 1-smoothstep(elapsed/fade) : 0;
};
const warmupCoreAt = (progress,settings) => settings.warmup?.coreEnvelope?.length ? keyframeAt(progress,settings.warmup.coreEnvelope) : 1;

/** Fresh quote clicks ease light into view without changing authored layer clocks.
 * Apply to source white/halo and ring light only; warp and stretch stay untouched.
 */
export function quoteClickLightOnset(elapsed, settings) {
  const duration = lightDuration(settings);
  const attack = Number.isFinite(duration) && duration > 0 ? Math.min(120,duration*.6) : 120;
  return smoothstep((Number.isFinite(elapsed) ? elapsed : 0)/attack);
}

export function animationDuration(settings) {
  return Math.max(settings.duration, settings.stretchDelay + settings.stretchDuration, lightDuration(settings), settings.warmup?.enabled ? releaseFade(settings) : 0);
}
export function animationPhases(progress, settings) {
  const elapsed = clamp(progress) * animationDuration(settings);
  const optical = clamp(elapsed / settings.duration);
  const stretch = clamp((elapsed - settings.stretchDelay) / settings.stretchDuration);
  const core = clamp(elapsed / lightDuration(settings));
  return { elapsed, optical, core, stretch, stretchEased: clamp(cubicBezier(stretch, settings.stretchTravel)) };
}

/** Pointer flashes have their own footprint; scroll release keeps the collected pool. */
export function originDiameter(settings, size, {kind='quote', phase='release', click=false}={}) {
  const isQuoteClick = kind === 'quote' && phase === 'release' && click;
  const clickSize = Number.isFinite(settings.clickHighlightSize) ? settings.clickHighlightSize : Math.min(settings.highlightSize,.12);
  const radius = isQuoteClick ? clickSize : settings.highlightSize;
  return Math.min(Math.max(1,size.width),Math.max(1,size.height))*clamp(radius,.05,1)*2;
}

/** The source pool contracts during collection, then expands on its own light clock. */
export function originScaleAt(progress, settings, { phase = 'release', fromWarmup = false, reducedMotion = false } = {}) {
  if (reducedMotion || !settings.coreMotion || (phase !== 'warmup' && !fromWarmup)) return 1;
  const motion = settings.coreMotion;
  const scale = name => Number.isFinite(motion[name]) ? clamp(motion[name],.1,3) : 1;
  const curve = name => Array.isArray(motion[name]) && motion[name].length === 4 && motion[name].every(Number.isFinite) ? motion[name] : [0,0,1,1];
  const p = clamp(Number.isFinite(progress) ? progress : 0);
  let from, to, local, easing;
  if (phase === 'warmup') {
    const start = Number.isFinite(motion.contractStart) ? clamp(motion.contractStart,0,.95) : 0;
    from = scale('startScale'); to = scale('releaseScale');
    local = clamp((p-start)/(1-start)); easing = curve('contractCurve');
  } else {
    const duration = Math.max(lightDuration(settings),fromWarmup && settings.warmup?.enabled ? releaseFade(settings) : 0);
    from = scale('releaseScale'); to = scale('endScale');
    local = clamp(p*animationDuration(settings)/Math.max(1,duration)); easing = curve('expandCurve');
  }
  if (local === 0) return from;
  if (local === 1) return to;
  return from+(to-from)*clamp(cubicBezier(local,easing));
}

/** Extra vertical expansion belongs to collection, including its release handoff. */
export function upwardStretchAt(progress,settings,{phase='release',fromWarmup=false}={}) {
  const amount = Number.isFinite(settings.warmup?.stretchY) ? clamp(settings.warmup.stretchY,0,.16) : 0;
  if (!amount) return 0;
  const p = clamp(Number.isFinite(progress) ? progress : 0);
  if (phase === 'warmup') return amount*smoothstep(cubicBezier(p,settings.warmup.curve));
  return amount*warmupCarry(p*animationDuration(settings),settings,fromWarmup);
}

function geometry(settings, size, origin) {
  const width = Math.max(1, size.width), height = Math.max(1, size.height);
  const x = clamp(origin.x) * width, y = clamp(origin.y) * height;
  return { x, y, maximumRadius: farthestCorner(width, height, x, y) * settings.radius };
}
function circle(radius) {
  // feImage is square and CSS uses circle closest-side: both place the ring at .68.
  return { radius, width: radius * 2 / RIPPLE_CENTER, height: radius * 2 / RIPPLE_CENTER };
}
export function waveFrame(progress, settings, size, origin = settings.origin) {
  const phases = animationPhases(progress, settings);
  const travel = clamp(cubicBezier(phases.optical, settings.travel));
  const position = geometry(settings, size, origin);
  return { progress: clamp(progress), ...phases, travel,
    amplitude: envelopeAt(phases.optical, settings.envelope),
    coreAmplitude: envelopeAt(phases.core, settings.coreEnvelope || settings.envelope),
    stretchAmplitude: envelopeAt(phases.stretchEased, settings.stretchEnvelope),
    hue: keyframeAt(phases.optical, settings.spectrumShift), ...position,
    ...circle(1 + travel * Math.max(1, position.maximumRadius - 1)) };
}

/** Shared by release playback and Studio so the gathered source has one handoff. */
export function releaseAmounts(state, settings, fromWarmup = false) {
  const carry = warmupCarry(state.elapsed,settings,fromWarmup);
  const coreAmplitude = envelopeAt(clamp(state.elapsed / lightDuration(settings)), settings.coreEnvelope || settings.envelope);
  return {
    coreAmount: clamp(settings.coreGlow * coreAmplitude + settings.warmup.coreGlow * warmupCoreAt(1,settings) * carry),
    stretchAmount: settings.stretch * state.stretchAmplitude + settings.warmup.stretch * carry,
  };
}
export function warmupFrame(progress, settings, size, origin = settings.origin) {
  const p = clamp(progress), travel = clamp(cubicBezier(p, settings.warmup.curve));
  const position = geometry(settings, size, origin);
  const build = smoothstep(travel);
  return { progress: p, travel, ...position,
    amplitude: Math.sin(Math.PI * travel), build, core: build*warmupCoreAt(p,settings),
    hue: keyframeAt(1 - travel, settings.spectrumShift),
    ...circle(1 + (1 - travel) * Math.max(1, position.maximumRadius - 1)) };
}
