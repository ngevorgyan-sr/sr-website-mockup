const MAX_SIGMA = 4;
const MAX_PAIRS = 6;

/** Dense Gaussian samples combined in adjacent bilinear pairs (13 reads at most). */
export function gaussianKernel(sigma) {
  if (!Number.isFinite(sigma) || sigma <= .001) return {center:1,weights:new Float32Array(MAX_PAIRS),offsets:new Float32Array(MAX_PAIRS)};
  sigma = Math.min(MAX_SIGMA,sigma);
  const radius=Math.min(MAX_PAIRS*2,Math.ceil(sigma*3));
  const taps=Array.from({length:radius+1},(_,i)=>Math.exp(-i*i/(2*sigma*sigma)));
  const sum=taps[0]+2*taps.slice(1).reduce((total,value)=>total+value,0);
  const weights=new Float32Array(MAX_PAIRS),offsets=new Float32Array(MAX_PAIRS);
  for(let i=1;i<=radius;i+=2){
    const first=taps[i]/sum,second=(taps[i+1]||0)/sum,weight=first+second,index=(i-1)/2;
    weights[index]=weight;offsets[index]=weight>0?(i*first+(i+1)*second)/weight:0;
  }
  return {center:taps[0]/sum,weights,offsets};
}

/** Keep sample spacing at one texture pixel even for a wide CSS blur. */
export function gaussianPlan(width,height,sigmaX,sigmaY=sigmaX) {
  let targetWidth=width,targetHeight=height;
  const levels=[];
  while(Math.max(sigmaX*targetWidth/width,sigmaY*targetHeight/height)>MAX_SIGMA && (targetWidth>1||targetHeight>1)){
    targetWidth=Math.max(1,Math.ceil(targetWidth/2));targetHeight=Math.max(1,Math.ceil(targetHeight/2));
    levels.push({width:targetWidth,height:targetHeight});
  }
  const remaining=(sigma,scale)=>Math.sqrt(Math.max(0,sigma*sigma-(scale*scale-1)/12))/scale;
  return {levels,width:targetWidth,height:targetHeight,
    sigmaX:remaining(sigmaX,width/targetWidth),sigmaY:remaining(sigmaY,height/targetHeight)};
}

/** Canvas drawImage leaves out-of-source pixels clear; repeat its boundary instead. */
export function clampedCropTiles(crop,source,width,height) {
  const axis=(start,length,limit,target)=>{
    const first=Math.max(0,Math.min(1,-start/length)),last=Math.max(0,Math.min(1,(limit-start)/length));
    const pieces=[];
    if(first>0)pieces.push([0,Math.min(1,limit),0,first*target]);
    if(last>first)pieces.push([Math.max(0,start+first*length),Math.min(limit,(last-first)*length),first*target,(last-first)*target]);
    if(last<1)pieces.push([Math.max(0,limit-1),Math.min(1,limit),last*target,(1-last)*target]);
    return pieces;
  };
  const xs=axis(crop.x,crop.width,source.width,width),ys=axis(crop.y,crop.height,source.height,height);
  return ys.flatMap(([sy,sh,dy,dh])=>xs.map(([sx,sw,dx,dw])=>[sx,sy,sw,sh,dx,dy,dw,dh]));
}
