import { normalizeButtonMaterial } from './material-model.js';

const positive = value => Number.isFinite(value) ? Math.max(0,value) : 0;
const peak = points => Array.isArray(points) && points.length ? Math.max(0,...points.map(point=>Math.min(2,positive(point?.value)))) : 2;

/** Source pixels needed outside the stable mask, in untransformed CSS pixels. */
export function buttonBleed(config = {}, size = {}) {
  const warmup = config.warmup || {}, material = normalizeButtonMaterial(config.surface);
  const dispersion = positive(config.dispersion);
  // SVG RGB channels use twice this displacement scale against a centered map.
  const displacement = Math.max(
    (positive(config.strength) + dispersion / 2) * peak(config.envelope),
    positive(warmup.strength) + dispersion * .225,
  );
  const stretch = positive(config.stretch) * peak(config.stretchEnvelope || config.envelope)
    + (warmup.enabled ? positive(warmup.stretch) : 0);
  // A click can anchor at either vertical edge. Invert the smallest Y scale;
  // adding a fixed fraction of height would under-pad the strongest settings.
  const smallestScaleY = Math.max(.01,1 - Math.max(stretch,positive(warmup.stretch)) * .3);
  const contraction = positive(size.height) * (1 / smallestScaleY - 1);
  // The material samples outside its output pixel too: lens offset, split RGB,
  // distortion and the widest blur tap must still find real backdrop pixels.
  const materialSampling = material.refraction * material.zRadius * .65
    + material.chromAberration * 8 + material.distortion * 4
    + (material.blur > .001 ? 4 * material.blur + 2 : 0);
  return Math.max(16,Math.ceil(displacement + contraction + materialSampling + 3));
}

/** The completed object includes its shadow before SVG displacement. */
export function buttonFilterPadding(config = {}, size = {}, isVideoButton = false) {
  const material=normalizeButtonMaterial(config.surface);
  const opacity=isVideoButton?material.videoShadowOpacity:material.shadowOpacity;
  const spread=isVideoButton?material.videoShadowSpread:material.shadowSpread;
  // Each independent layer needs padding even when the other is disabled.
  // Blur tails are 1.5× the CSS blur radius, plus the 8px vertical offset.
  const dark=opacity>0?spread+38:0;
  const center=!isVideoButton&&material.shadowCenterOpacity>0?material.shadowCenterSpread+18.5:0;
  return buttonBleed(config,size) + Math.ceil(Math.max(dark,center));
}
