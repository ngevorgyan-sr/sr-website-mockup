import { clamp } from './motion.js';

export const MATERIAL_LIMITS = {
  tintOpacity:[0,2,1],blur:[0,24,2],saturation:[0,3,1],shine:[0,2,1],edge:[0,2,1],
  refraction:[0,2,.35],chromAberration:[0,1,.03],edgeHighlight:[0,2,0],specular:[0,2,.08],specularSharpness:[0,1,.5],
  fresnel:[0,2,.15],distortion:[0,1,0],zRadius:[1,100,18],opacity:[0,1,1],brightness:[.25,2,1],
  shadowOpacity:[0,1,.16],shadowSpread:[0,32,8],
};
export function normalizeButtonMaterial(input={}) {
  const result={};
  for(const [key,[min,max,fallback]] of Object.entries(MATERIAL_LIMITS))result[key]=Number.isFinite(input[key])?clamp(input[key],min,max):fallback;
  result.videoTintOpacity=Number.isFinite(input.videoTintOpacity)?clamp(input.videoTintOpacity,0,2):result.tintOpacity;
  result.shadowCenterOpacity=Number.isFinite(input.shadowCenterOpacity)?clamp(input.shadowCenterOpacity,0,2):result.shadowOpacity*18/10;
  result.shadowCenterSpread=Number.isFinite(input.shadowCenterSpread)?clamp(input.shadowCenterSpread,0,32):result.shadowSpread*.5;
  result.videoShadowOpacity=Number.isFinite(input.videoShadowOpacity)?clamp(input.videoShadowOpacity,0,1):result.shadowOpacity;
  result.videoShadowSpread=Number.isFinite(input.videoShadowSpread)?clamp(input.videoShadowSpread,0,32):result.shadowSpread;
  result.cornerRadius=Number.isFinite(input.cornerRadius)?clamp(input.cornerRadius,0,100):null;
  result.bevelMode=input.bevelMode==='dome'?'dome':'pill';
  result.tintColor=typeof input.tintColor==='string'&&/^#[0-9a-fA-F]{6}$/.test(input.tintColor)?input.tintColor:null;
  return result;
}
/** 50% preserves the existing 18/6 lobes; endpoints span broad to crisp. */
export function specularExponent(sharpness=.5) {
  return 18 * 6 ** (2 * clamp(Number.isFinite(sharpness)?sharpness:.5,0,1) - 1);
}
/** Maps the exact displayed object-fit:cover video pixels into an extended button tile. */
export function coverCrop(source, videoRect, sampleRect, position={x:.5,y:.5}) {
  const scale=Math.max(videoRect.width/source.width,videoRect.height/source.height);
  const left=videoRect.left+(videoRect.width-source.width*scale)*position.x;
  const top=videoRect.top+(videoRect.height-source.height*scale)*position.y;
  return {x:(sampleRect.left-left)/scale,y:(sampleRect.top-top)/scale,width:sampleRect.width/scale,height:sampleRect.height/scale};
}
export function materialResolution(width,height,dpr=1) {
  const scale=Math.min(Math.max(1,dpr),1.5,Math.sqrt(380000/Math.max(1,width*height)));
  return {width:Math.max(1,Math.round(width*scale)),height:Math.max(1,Math.round(height*scale))};
}
/** Only the masked body reaches the page; retain two pixels for antialiasing.
 * The larger source texture remains intact for refraction and blur sampling.
 */
export function materialScissor(area,pixels,bleed) {
  const x=Math.max(0,Math.floor(bleed*pixels.width/area.width)-2);
  const y=Math.max(0,Math.floor(bleed*pixels.height/area.height)-2);
  return {x,y,width:pixels.width-2*x,height:pixels.height-2*y};
}
