/** Input/scroll geometry only. No per-frame pointer tracking or DOM access. */
export const unit = value => Math.max(0, Math.min(1, value));

export function entryOrigin(rect, clientX, clientY, fallback = {x:0,y:.5}) {
  if (!Number.isFinite(clientX) || !Number.isFinite(clientY)) return {...fallback};
  const edges = [
    {distance:Math.abs(clientX-rect.left),x:0,y:.5},
    {distance:Math.abs(rect.right-clientX),x:1,y:.5},
    {distance:Math.abs(clientY-rect.top),x:.5,y:0},
    {distance:Math.abs(rect.bottom-clientY),x:.5,y:1},
  ];
  edges.sort((a,b)=>a.distance-b.distance);
  return {x:edges[0].x,y:edges[0].y};
}

export function quoteArrival(rect, viewportHeight, warmup, header = 64) {
  const available = Math.max(1,viewportHeight-header);
  const visible = Math.max(0,Math.min(rect.bottom,viewportHeight)-Math.max(rect.top,header));
  // A quote taller than the viewport can still reach the release threshold.
  const fraction = unit(visible/Math.max(1,Math.min(rect.height,available)));
  const progress = unit((fraction-warmup.start)/Math.max(.001,warmup.release-warmup.start));
  return {fraction,progress,visible:visible>0,release:fraction>=warmup.release};
}
