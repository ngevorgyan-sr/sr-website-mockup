import './button-material.css';
import { normalizeButtonMaterial, coverCrop, materialResolution, materialScissor, specularExponent } from './material-model.js';
import { gaussianKernel, gaussianPlan, clampedCropTiles } from './material-kernel.js';

const surfaces=new Set(),dirty=new Set();
let gpu=null,frame=0,failed=false,warned=false;
const VERTEX=`attribute vec2 a; varying vec2 uv; void main(){uv=vec2(a.x*.5+.5,.5-a.y*.5);gl_Position=vec4(a,0.,1.);}`;
// Offscreen passes preserve the upload's row order; only the final pass flips Y.
const PASS_VERTEX=`attribute vec2 a; varying vec2 uv; void main(){uv=a*.5+.5;gl_Position=vec4(a,0.,1.);}`;
const DOWNSAMPLE=`precision highp float;varying vec2 uv;uniform sampler2D image;uniform vec2 stepSize;
void main(){gl_FragColor=(texture2D(image,uv+stepSize)+texture2D(image,uv-stepSize)+texture2D(image,uv+vec2(stepSize.x,-stepSize.y))+texture2D(image,uv+vec2(-stepSize.x,stepSize.y)))*.25;}`;
const GAUSSIAN=`precision highp float;varying vec2 uv;uniform sampler2D image;uniform vec2 direction;uniform float center;uniform float weights[6],offsets[6];
void main(){vec4 color=texture2D(image,uv)*center;for(int i=0;i<6;i++){if(weights[i]>0.){vec2 delta=direction*offsets[i];color+=(texture2D(image,uv+delta)+texture2D(image,uv-delta))*weights[i];}}gl_FragColor=color;}`;
const FRAGMENT=`precision highp float;
varying vec2 uv; uniform sampler2D image;
uniform vec2 size,body; uniform vec4 tint; uniform float bleed,radius,depth,refraction,aberration,edgeLight,specular,specularPower,fresnel,distortion,brightness,saturation,dome,hasVideo;
float outlineDistance(vec2 p){vec2 q=abs(p)-body*.5+radius;return length(max(q,0.))+min(max(q.x,q.y),0.)-radius;}
void main(){
 vec2 p=uv*size-vec2(bleed)-body*.5;
 // One separable height field, H*sqrt(1-uX^2)*sqrt(1-uY^2), rolls the two
 // axes together without choosing a closest side or a diagonal bisector.
 // u=t^2*(2-t) eases each circular roll into a genuinely flat center.
 float halfSpan=min(body.x,body.y)*.5;
 float band=max(1.,min(depth*mix(1.1,1.65,dome),halfSpan*mix(.72,.86,dome)));
 vec2 axis=sqrt(p*p+vec2(.25));
 vec2 t=clamp((axis-body*.5+band)/band,0.,1.);
 vec2 u=t*t*(2.-t);
 vec2 derivative=t*(4.-3.*t)*(p/axis)/band;
 vec2 circle=max(vec2(.0001),1.-u*u);
 float height=sqrt(circle.x*circle.y);
 float thickness=depth*mix(.55,.75,dome);
 // Homogeneous analytic gradient: multiplying by fX*fY avoids division by
 // a vanishing circle height. Normalize only after combining both axes.
 vec3 normal=normalize(vec3(thickness*u.x*derivative.x*circle.y,thickness*u.y*derivative.y*circle.x,height));
 float bend=1.-height;
 vec2 edgeWarp=normal.xy*(distortion*4.*bend);
 vec2 offset=(normal.xy*refraction*depth*.65+edgeWarp)/size;
 vec2 split=normal.xy*aberration*8./size;
 // A broad glossy reflection and bevel glow describe one curved cross-section,
 // rather than painting a narrow bright line at the component boundary.
 float facing=max(dot(normal,normalize(vec3(-.45,-.65,1.8))),0.);
 // A polished core sits inside a broad reflection; both use the same normal,
 // with less central lift and no border-aligned shine or extra brightness.
 float reflection=pow(facing,specularPower)*.27+pow(facing,specularPower/3.)*.11;
 // Height drop starts at fourth order; its square root brings polish in
 // earlier along the round roll while retaining zero slope at the flat join.
 float light=specular*reflection*(.16+.84*sqrt(bend));
 // Fresnel follows the actual rounded mask, not the rectangular height field.
 // Reuse its circular cross-section along the outline's inward distance, then
 // feather the final subpixel edge so the rounded clip cannot cut a bright cap.
 if(fresnel>.0001){
  float inset=max(0.,-outlineDistance(p));
  float rimT=clamp(1.-inset/band,0.,1.);
  float rimU=rimT*rimT*(2.-rimT);
  float rimSlope=thickness*rimU*rimT*(4.-3.*rimT)/band;
  float rimHeight=sqrt(max(.0001,1.-rimU*rimU));
  float rimZ=rimHeight/sqrt(rimHeight*rimHeight+rimSlope*rimSlope);
  light+=pow(1.-rimZ,2.)*fresnel*.55*smoothstep(0.,.6,inset);
 }
 light+=bend*edgeLight*.28*(.35+.65*facing);
 if(hasVideo>.5){
  vec3 color=texture2D(image,uv-offset).rgb;
  if(aberration>.0001){color.r=texture2D(image,uv-offset-split).r;color.b=texture2D(image,uv-offset+split).b;}
  float luma=dot(color,vec3(.2126,.7152,.0722));color=mix(vec3(luma),color,saturation)*brightness;color=mix(color,tint.rgb,tint.a);
  gl_FragColor=vec4(clamp(color+light,0.,1.),1.);
 }else{gl_FragColor=vec4(vec3(1.),clamp(light,0.,.8));}
}`;
function createGPU(canvas=document.createElement('canvas')){
  const gl=canvas.getContext('webgl',{alpha:true,premultipliedAlpha:false,antialias:false,preserveDrawingBuffer:true});
  if(!gl)return null;
  const compile=(type,source)=>{const shader=gl.createShader(type);gl.shaderSource(shader,source);gl.compileShader(shader);if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS)){const reason=gl.getShaderInfoLog(shader);gl.deleteShader(shader);throw Error(`Glass material shader did not compile: ${reason}`);}return shader;};
  const programs=[],textures=[],targets=[];
  let buffer;
  const makeProgram=(vertexSource,fragmentSource,names)=>{
    let vertex,fragment,program;
    try{
      vertex=compile(gl.VERTEX_SHADER,vertexSource);fragment=compile(gl.FRAGMENT_SHADER,fragmentSource);program=gl.createProgram();programs.push(program);
      gl.attachShader(program,vertex);gl.attachShader(program,fragment);gl.bindAttribLocation(program,0,'a');gl.linkProgram(program);
      if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(`Glass material shader did not link: ${gl.getProgramInfoLog(program)}`);
      return {program,uniforms:Object.fromEntries(names.map(name=>[name,gl.getUniformLocation(program,name)]))};
    }finally{if(vertex)gl.deleteShader(vertex);if(fragment)gl.deleteShader(fragment);}
  };
  const makeTexture=()=>{
    const texture=gl.createTexture();textures.push(texture);gl.bindTexture(gl.TEXTURE_2D,texture);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
    return texture;
  };
  let material,gaussian,downsample,texture;
  try{
    material=makeProgram(VERTEX,FRAGMENT,['image','tint','size','body','bleed','radius','depth','refraction','aberration','edgeLight','specular','specularPower','fresnel','distortion','brightness','saturation','dome','hasVideo']);
    gaussian=makeProgram(PASS_VERTEX,GAUSSIAN,['image','direction','center','weights[0]','offsets[0]']);
    downsample=makeProgram(PASS_VERTEX,DOWNSAMPLE,['image','stepSize']);
    buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,2,gl.FLOAT,false,0,0);
    texture=makeTexture();
    for(let i=0;i<2;i++)targets.push({texture:makeTexture(),framebuffer:gl.createFramebuffer(),width:0,height:0});
  }catch(error){for(const program of programs)gl.deleteProgram(program);for(const texture of textures)gl.deleteTexture(texture);for(const target of targets)gl.deleteFramebuffer(target.framebuffer);if(buffer)gl.deleteBuffer(buffer);throw error;}
  const result={canvas,gl,...material,gaussian,downsample,programs,textures,targets,buffer,texture,lost:false};
  result.onLost=event=>{event.preventDefault();if(gpu!==result)return;result.lost=true;for(const surface of surfaces)surface.fallback();};
  result.onRestored=()=>{
    if(gpu!==result)return;
    releaseGPU(result);gpu=null;failed=false;
    try{gpu=createGPU(canvas);}catch(error){failGPU(error);return;}
    if(!gpu){failGPU();return;}
    for(const surface of surfaces)surface.visibilityChanged();
  };
  canvas.addEventListener('webglcontextlost',result.onLost);
  canvas.addEventListener('webglcontextrestored',result.onRestored);
  return result;
}
function releaseGPU(resource){
  if(!resource)return;
  const {canvas,gl}=resource;
  canvas.removeEventListener('webglcontextlost',resource.onLost);canvas.removeEventListener('webglcontextrestored',resource.onRestored);
  if(!resource.lost){for(const texture of resource.textures)gl.deleteTexture(texture);for(const target of resource.targets)gl.deleteFramebuffer(target.framebuffer);gl.deleteBuffer(resource.buffer);for(const program of resource.programs)gl.deleteProgram(program);}
}
function prepareTarget(resource,target,width,height){
  const {gl}=resource;
  gl.bindFramebuffer(gl.FRAMEBUFFER,target.framebuffer);
  if(target.width!==width||target.height!==height){
    gl.bindTexture(gl.TEXTURE_2D,target.texture);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,width,height,0,gl.RGBA,gl.UNSIGNED_BYTE,null);
    gl.framebufferTexture2D(gl.FRAMEBUFFER,gl.COLOR_ATTACHMENT0,gl.TEXTURE_2D,target.texture,0);
    if(gl.checkFramebufferStatus(gl.FRAMEBUFFER)!==gl.FRAMEBUFFER_COMPLETE)throw Error('Glass material blur framebuffer is unavailable');
    target.width=width;target.height=height;
  }
  gl.viewport(0,0,width,height);
}
function preblur(resource,pixels,area,amount){
  if(amount<=.001)return resource.texture;
  const {gl,targets}=resource;
  const key=[pixels.width,pixels.height,area.width,area.height,amount].join(',');
  if(resource.blurCache?.key!==key){
    const plan=gaussianPlan(pixels.width,pixels.height,amount*pixels.width/area.width,amount*pixels.height/area.height);
    resource.blurCache={key,plan,kernels:[gaussianKernel(plan.sigmaX),gaussianKernel(plan.sigmaY)]};
  }
  const {plan,kernels}=resource.blurCache;
  let source=resource.texture,targetIndex=0;
  const pass=(shader,width,height,configure)=>{
    const target=targets[targetIndex];targetIndex=1-targetIndex;
    prepareTarget(resource,target,width,height);gl.useProgram(shader.program);gl.bindTexture(gl.TEXTURE_2D,source);gl.uniform1i(shader.uniforms.image,0);
    configure(shader.uniforms);gl.drawArrays(gl.TRIANGLE_STRIP,0,4);source=target.texture;
  };
  for(const level of plan.levels)pass(resource.downsample,level.width,level.height,u=>gl.uniform2f(u.stepSize,.25/level.width,.25/level.height));
  for(const [kernel,x,y] of [[kernels[0],1/plan.width,0],[kernels[1],0,1/plan.height]]){
    pass(resource.gaussian,plan.width,plan.height,u=>{gl.uniform2f(u.direction,x,y);gl.uniform1f(u.center,kernel.center);gl.uniform1fv(u['weights[0]'],kernel.weights);gl.uniform1fv(u['offsets[0]'],kernel.offsets);});
  }
  return source;
}
function failGPU(error){
  failed=true;
  if(error&&!warned){warned=true;console.warn('Glass video renderer could not initialize; native glass remains active.',error);}
  for(const surface of surfaces)surface.fallback();
}
function requestDraw(surface){
  dirty.add(surface);
  if(!frame&&!document.hidden)frame=requestAnimationFrame(()=>{frame=0;const pending=[...dirty];dirty.clear();for(const item of pending)item.draw();});
}
function documentVisibility(){for(const surface of surfaces)surface.visibilityChanged();}
function viewportResized(){for(const surface of surfaces)surface.invalidate();}
function positionPart(value,fallback=.5){if(value?.endsWith('%'))return parseFloat(value)/100;return {left:0,top:0,center:.5,right:1,bottom:1}[value]??fallback;}

/** Material owns no label or layout. The filtered content is overscanned beneath a stable mask. */
export function createButtonMaterial(element,content,settings,{video: suppliedVideo=null}={}){
  const canvas=document.createElement('canvas');canvas.className='sr-button-material';canvas.setAttribute('aria-hidden','true');canvas.hidden=true;
  (content.querySelector('.sr-button-content')||content).prepend(canvas);
  const context=canvas.getContext('2d'),scratch=document.createElement('canvas'),capture=scratch.getContext('2d');
  const isVideoButton=Boolean(suppliedVideo)||element.classList.contains('hero-apply');
  const video=suppliedVideo||(isVideoButton?element.closest('.hero')?.querySelector('video'):null);
  const poster=video?.poster?new Image():null;
  const previous=new Map(['--sr-material-radius','--sr-material-opacity','--sr-material-brightness','--sr-shadow-opacity','--sr-shadow-spread','--sr-shadow-center-opacity','--sr-shadow-center-spread'].map(key=>[key,element.style.getPropertyValue(key)]));
  let config=normalizeButtonMaterial(settings.surface),visible=false,destroyed=false,videoFrame=0,videoFallback=0,lastVideo=-Infinity,sourceFailed=false;
  let needsRedraw=true,lastCrop='';
  let originalRadius=getComputedStyle(element).borderTopLeftRadius;
  const media=matchMedia('(forced-colors: active)');
  function canRender(){return !destroyed&&visible&&!document.hidden&&!media.matches&&context&&capture&&config.opacity>0&&!failed&&!gpu?.lost&&!sourceFailed;}
  function canPlay(){return video&&canRender()&&!video.paused&&!video.ended;}
  function stopVideo(){if(videoFrame)video.cancelVideoFrameCallback(videoFrame);if(videoFallback)cancelAnimationFrame(videoFallback);videoFrame=videoFallback=0;}
  function scheduleVideo(){
    if(!canPlay()||videoFrame||videoFallback)return;
    const tick=time=>{videoFrame=videoFallback=0;if(!canPlay())return;if(time-lastVideo>=32){lastVideo=time;api.invalidate();}scheduleVideo();};
    if(video.requestVideoFrameCallback)videoFrame=video.requestVideoFrameCallback(tick);else videoFallback=requestAnimationFrame(tick);
  }
  function draw(){
    if(!canRender())return;
    try{if(!gpu)gpu=createGPU();}catch(error){failGPU(error);return;}
    if(!gpu){failGPU();return;}
    if(gpu.lost){api.fallback();return;}
    // Keep the light's contour aligned with the fractional CSS mask dimensions.
    // Bounding rects contain elastic motion, so read untransformed layout sizes.
    const layout=getComputedStyle(content);
    const width=parseFloat(layout.width)||content.offsetWidth,height=parseFloat(layout.height)||content.offsetHeight;if(!width||!height)return;
    const style=getComputedStyle(element),bleed=Math.max(0,parseFloat(style.getPropertyValue('--sr-glass-bleed'))||16);
    const area={width:width+2*bleed,height:height+2*bleed};
    const pixels=materialResolution(area.width,area.height,devicePixelRatio);
    // Ripple-only motion deforms the already rendered tile. A new video frame,
    // setting or resize forces repaint; otherwise only a changed crop needs it.
    const rect=video?element.getBoundingClientRect():null,videoRect=video?.getBoundingClientRect();
    const objectPosition=video?getComputedStyle(video).objectPosition:'50% 50%';
    const cropKey=video?[width,height,bleed,pixels.width,pixels.height,rect.left-videoRect.left,rect.top-videoRect.top,rect.width,rect.height,videoRect.width,videoRect.height,objectPosition].join(','):'';
    if(!needsRedraw&&cropKey===lastCrop)return;
    if(canvas.width!==pixels.width||canvas.height!==pixels.height){canvas.width=pixels.width;canvas.height=pixels.height;}
    const {gl,program,uniforms:u}=gpu;
    if(gpu.canvas.width!==pixels.width||gpu.canvas.height!==pixels.height){gpu.canvas.width=pixels.width;gpu.canvas.height=pixels.height;}
    gl.bindTexture(gl.TEXTURE_2D,gpu.texture);
    let hasVideo=false;
    // An unplayed, paused video still displays its poster, even after a frame decodes.
    const showingPoster=video?.paused&&video.currentTime===0&&!video.played.length;
    const source=video?.readyState>=2&&!showingPoster?video:poster?.complete&&poster.naturalWidth?poster:null;
    if(source){
      if(scratch.width!==pixels.width||scratch.height!==pixels.height){scratch.width=pixels.width;scratch.height=pixels.height;}
      // Capture before elastic deformation: the visual wrapper stretches these
      // source pixels together with its text, frame, mask and highlights.
      const sx=rect.width/width,sy=rect.height/height,position=objectPosition.split(' ');
      const sourceSize={width:source.videoWidth||source.naturalWidth,height:source.videoHeight||source.naturalHeight};
      const crop=coverCrop(sourceSize,videoRect,{left:rect.left-bleed*sx,top:rect.top-bleed*sy,width:area.width*sx,height:area.height*sy},{x:positionPart(position[0]),y:positionPart(position[1])});
      capture.clearRect(0,0,pixels.width,pixels.height);
      try{for(const tile of clampedCropTiles(crop,sourceSize,pixels.width,pixels.height))capture.drawImage(source,...tile);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,scratch);hasVideo=true;}catch{sourceFailed=true;api.fallback();return;}
    }else gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([0,0,0,0]));
    let image=gpu.texture;
    if(hasVideo){try{image=preblur(gpu,pixels,area,config.blur);}catch(error){failGPU(error);return;}}
    gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.viewport(0,0,pixels.width,pixels.height);gl.useProgram(program);gl.bindTexture(gl.TEXTURE_2D,image);
    const tintValues=(style.getPropertyValue('--glass-tint').match(/[\d.]+/g)||[]).map(Number);
    gl.uniform4f(u.tint,(tintValues[0]||0)/255,(tintValues[1]||0)/255,(tintValues[2]||0)/255,tintValues[3]??0);
    gl.uniform1i(u.image,0);gl.uniform2f(u.size,area.width,area.height);gl.uniform2f(u.body,width,height);
    const radius=config.cornerRadius??parseFloat(style.borderTopLeftRadius)??parseFloat(originalRadius);
    for(const [key,value] of Object.entries({bleed,radius:Math.max(0,Math.min(radius||0,width/2,height/2)),depth:config.zRadius,refraction:config.refraction,aberration:config.chromAberration,edgeLight:config.edgeHighlight,specular:config.specular,specularPower:specularExponent(config.specularSharpness),fresnel:config.fresnel,distortion:config.distortion,brightness:config.brightness,saturation:config.saturation,dome:config.bevelMode==='dome'?1:0,hasVideo:hasVideo?1:0}))gl.uniform1f(u[key],value);
    // Keep the overscanned input, but do not shade pixels outside the inner clip.
    // Clear the shared output before each body so another button leaves no tail.
    const bounds=materialScissor(area,pixels,bleed);
    gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT);
    gl.enable(gl.SCISSOR_TEST);gl.scissor(bounds.x,bounds.y,bounds.width,bounds.height);
    try{gl.drawArrays(gl.TRIANGLE_STRIP,0,4);}finally{gl.disable(gl.SCISSOR_TEST);}
    context.clearRect(0,0,pixels.width,pixels.height);context.drawImage(gpu.canvas,0,0);canvas.hidden=false;
    needsRedraw=false;lastCrop=cropKey;
    canvas.dataset.source=hasVideo?'video':'lighting';
    element.classList.toggle('sr-material-video-ready',hasVideo);
  }
  const api={
    draw,
    invalidate(){needsRedraw=true;if(canRender())requestDraw(api);},
    refreshBackdrop(){if(video&&canRender())requestDraw(api);},
    fallback(){canvas.hidden=true;element.classList.remove('sr-material-video-ready');stopVideo();dirty.delete(api);},
    update(next){
      config=normalizeButtonMaterial(next.surface);
      if(config.cornerRadius===null)element.style.removeProperty('--sr-material-radius');else element.style.setProperty('--sr-material-radius',`${config.cornerRadius}px`);
      element.style.setProperty('--sr-material-opacity',String(config.opacity));element.style.setProperty('--sr-material-brightness',String(config.brightness));
      element.style.setProperty('--sr-shadow-opacity',String(isVideoButton?config.videoShadowOpacity:config.shadowOpacity));
      element.style.setProperty('--sr-shadow-spread',`${isVideoButton?config.videoShadowSpread:config.shadowSpread}px`);
      element.style.setProperty('--sr-shadow-center-opacity',String(isVideoButton?0:config.shadowCenterOpacity));
      element.style.setProperty('--sr-shadow-center-spread',`${isVideoButton?0:config.shadowCenterSpread}px`);
      if(config.opacity<=0)api.fallback();else{api.invalidate();scheduleVideo();}
    },
    visibilityChanged(){stopVideo();if(!document.hidden){api.invalidate();scheduleVideo();}},
    destroy(){if(destroyed)return;destroyed=true;stopVideo();dirty.delete(api);observer.disconnect();resize.disconnect();media.removeEventListener('change',changed);if(video)for(const event of events)video.removeEventListener(event,changed);if(poster)poster.onload=null;canvas.remove();element.classList.remove('sr-material-video-ready');for(const [key,value]of previous){if(value)element.style.setProperty(key,value);else element.style.removeProperty(key);}surfaces.delete(api);if(!surfaces.size){document.removeEventListener('visibilitychange',documentVisibility);window.removeEventListener('resize',viewportResized);if(frame)cancelAnimationFrame(frame);frame=0;dirty.clear();releaseGPU(gpu);gpu=null;failed=false;}},
  };
  const changed=event=>{if(event.type==='loadeddata'||event.type==='loadedmetadata')sourceFailed=false;if(media.matches)api.fallback();stopVideo();api.invalidate();scheduleVideo();};
  const events=['play','pause','ended','seeked','loadeddata','loadedmetadata'];
  if(video)for(const event of events)video.addEventListener(event,changed);
  if(poster){poster.onload=()=>api.invalidate();poster.src=video.poster;}
  const observer=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;if(visible){api.invalidate();scheduleVideo();}else{dirty.delete(api);stopVideo();}});observer.observe(element);
  const resize=new ResizeObserver(()=>api.invalidate());resize.observe(content);if(video)resize.observe(video);
  media.addEventListener('change',changed);
  if(!surfaces.size){document.addEventListener('visibilitychange',documentVisibility);window.addEventListener('resize',viewportResized,{passive:true});}surfaces.add(api);api.update(settings);
  return api;
}
