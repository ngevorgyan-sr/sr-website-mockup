import { clamp, cubicBezier, keyframeAt } from './motion.js';

const RESPONSE = [0, .25, .5, .75, 1].map(t => ({ t, value: t }));
const DEFAULT_CURVE = [.22, .61, .36, 1];
const FALLBACK = {
  lift: { duration: 360, returnDuration: 240 },
  scale: { duration: 420, returnDuration: 280 },
};
function layerSettings(settings, name) {
  const input = settings?.[`${name}Motion`] || {}, fallback = FALLBACK[name];
  return {
    duration: Math.max(1, input.duration ?? fallback.duration), delay: Math.max(0, input.delay ?? 0),
    curve: input.curve || DEFAULT_CURVE, keyframes: input.keyframes || RESPONSE,
    returnDuration: Math.max(1, input.returnDuration ?? fallback.returnDuration),
    returnCurve: input.returnCurve || DEFAULT_CURVE, returnKeyframes: input.returnKeyframes || RESPONSE,
  };
}
const entering = phase => phase !== 'leave';

/** Total clock for the independent lift and scale tracks. Return has no delay. */
export function hoverMotionDuration(settings, phase = 'enter') {
  return Math.max(...['lift', 'scale'].map(name => {
    const layer = layerSettings(settings, name);
    return entering(phase) ? layer.delay + layer.duration : layer.returnDuration;
  }));
}
function layerResponse(progress, settings, name, phase) {
  const layer = layerSettings(settings, name), enter = entering(phase);
  const elapsed = clamp(progress) * hoverMotionDuration(settings, phase);
  const time = clamp((elapsed - (enter ? layer.delay : 0)) / (enter ? layer.duration : layer.returnDuration));
  if (time === 0 || time === 1) return time;
  const curved = clamp(cubicBezier(time, enter ? layer.curve : layer.returnCurve));
  return keyframeAt(curved, enter ? layer.keyframes : layer.returnKeyframes);
}

/** Pose progress is 0→1 on entry and 1→0 on return, including intentional overshoot. */
export function hoverMotionFrame(progress, settings, phase = 'enter') {
  const enter = entering(phase);
  const liftResponse = layerResponse(progress, settings, 'lift', phase);
  const scaleResponse = layerResponse(progress, settings, 'scale', phase);
  const liftProgress = enter ? liftResponse : 1 - liftResponse;
  const scaleProgress = enter ? scaleResponse : 1 - scaleResponse;
  return { lift: (settings.lift || 0) * liftProgress, scale: 1 + ((settings.hoverScale ?? 1) - 1) * scaleProgress, liftProgress, scaleProgress };
}

const controllers = new Set(), active = new Map();
let raf = 0;
function tick(time) {
  raf = 0;
  for (const [controller, update] of [...active]) if (active.has(controller)) update(time);
  if (active.size) raf = requestAnimationFrame(tick);
}
function start(controller, update) { active.set(controller, update); if (!raf) raf = requestAnimationFrame(tick); }
function stop(controller) {
  active.delete(controller);
  if (!active.size && raf) { cancelAnimationFrame(raf); raf = 0; }
}
function hidden() { if (document.hidden) for (const controller of controllers) controller.reset(); }

/** Shares the rendered lift clock with the shell's shadow and material crop. */
export function createHoverMotion(element, initialSettings, { onFrame } = {}) {
  if (!element?.style) throw new TypeError('Hover motion requires an element with a style declaration.');
  let settings = structuredClone(initialSettings), desiredHovered = false, destroyed = false;
  let pose = { lift: 0, scale: 1, response: 0 }, frozen = null, playing = null;
  const media = window.matchMedia('(prefers-reduced-motion: reduce)');
  const previousLift = element.style.getPropertyValue('--sr-hover-lift'), previousScale = element.style.getPropertyValue('--sr-hover-scale');
  const previousElevation = element.style.getPropertyValue('--sr-hover-elevation');
  const previousBorder = element.style.getPropertyValue('--sr-hover-border');
  const resting = () => ({ lift: 0, scale: 1, response: 0 });
  const hovered = () => ({ lift: settings.lift || 0, scale: settings.hoverScale ?? 1, response: 1 });
  function render(next) {
    pose = { lift: next.lift, scale: next.scale, response: next.response ?? next.liftProgress ?? 0 };
    element.style.setProperty('--sr-hover-lift', `${Number(pose.lift.toFixed(6))}px`);
    element.style.setProperty('--sr-hover-scale', String(Number(pose.scale.toFixed(6))));
    // Derive this from the displayed pose, including partial reversals and delays.
    // Reduced motion disables the shell transform, so it has no visual elevation.
    const scaleRange = (settings.hoverScale ?? 1) - 1;
    const elevation = media.matches ? 0 : clamp(settings.lift ? pose.lift / settings.lift : scaleRange ? (pose.scale - 1) / scaleRange : 0);
    element.style.setProperty('--sr-hover-elevation', String(Number(elevation.toFixed(6))));
    // A color-only hover still uses the lift clock when both pose amounts are zero.
    const border = media.matches ? Number(desiredHovered) : settings.lift || scaleRange ? elevation : clamp(pose.response);
    element.style.setProperty('--sr-hover-border', String(Number(border.toFixed(6))));
    if (typeof onFrame === 'function') onFrame();
  }
  function transition(phase, deterministic = false) {
    if (destroyed) return;
    stop(api); frozen = null;
    const enter = entering(phase);
    desiredHovered = enter;
    if (deterministic) render(enter ? resting() : hovered());
    const from = { ...pose }, to = enter ? hovered() : resting();
    if (media.matches || document.hidden || (from.lift === to.lift && from.scale === to.scale && from.response === to.response)) {
      playing = null; render(to); return;
    }
    playing = { phase: enter ? 'enter' : 'leave', deterministic };
    const began = performance.now(), duration = hoverMotionDuration(settings, phase);
    start(api, time => {
      const progress = clamp((time - began) / duration);
      const lift = layerResponse(progress, settings, 'lift', phase), scale = layerResponse(progress, settings, 'scale', phase);
      render({ lift: from.lift + (to.lift - from.lift) * lift, scale: from.scale + (to.scale - from.scale) * scale, response: from.response + (to.response - from.response) * lift });
      if (progress >= 1) { stop(api); playing = null; render(to); }
    });
  }
  const api = {
    enter() { if (!destroyed && (!desiredHovered || frozen)) transition('enter'); },
    leave() { if (!destroyed && (desiredHovered || frozen)) transition('leave'); },
    update(next) {
      if (destroyed) return;
      settings = structuredClone(next);
      if (frozen) {
        render(media.matches ? (entering(frozen.phase) ? hovered() : resting()) : hoverMotionFrame(frozen.progress, settings, frozen.phase));
      } else if (playing) {
        // Live tuning restarts from the displayed pose, never from a stale target.
        transition(playing.phase);
      } else render(desiredHovered ? hovered() : resting());
    },
    seek(progress, phase = 'enter') {
      if (destroyed) return;
      stop(api); playing = null;
      frozen = { progress: clamp(Number.isFinite(progress) ? progress : 0), phase: entering(phase) ? 'enter' : 'leave' };
      desiredHovered = entering(phase);
      render(media.matches ? (desiredHovered ? hovered() : resting()) : hoverMotionFrame(frozen.progress, settings, frozen.phase));
    },
    play(phase = 'enter') { transition(phase, true); },
    reset() {
      if (destroyed) return;
      stop(api); playing = frozen = null; desiredHovered = false; render(resting());
    },
    destroy() {
      if (destroyed) return;
      api.reset(); destroyed = true;
      media.removeEventListener?.('change', reducedChange);
      if (previousLift) element.style.setProperty('--sr-hover-lift', previousLift); else element.style.removeProperty('--sr-hover-lift');
      if (previousScale) element.style.setProperty('--sr-hover-scale', previousScale); else element.style.removeProperty('--sr-hover-scale');
      if (previousElevation) element.style.setProperty('--sr-hover-elevation', previousElevation); else element.style.removeProperty('--sr-hover-elevation');
      if (previousBorder) element.style.setProperty('--sr-hover-border', previousBorder); else element.style.removeProperty('--sr-hover-border');
      controllers.delete(api);
      if (!controllers.size) document.removeEventListener('visibilitychange', hidden);
    },
  };
  const reducedChange = () => {
    if (media.matches) { stop(api); playing = frozen = null; render(desiredHovered ? hovered() : resting()); }
    else render(pose);
  };
  if (!controllers.size) document.addEventListener('visibilitychange', hidden);
  controllers.add(api); media.addEventListener?.('change', reducedChange); render(resting());
  return api;
}
