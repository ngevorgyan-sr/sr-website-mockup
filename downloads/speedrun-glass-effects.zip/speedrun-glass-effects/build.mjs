import {build} from 'vite';
import {copyFile,readFile,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {buildButtonDemo} from './build-button-demo.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
await build({
  root,configFile:false,publicDir:false,
  build:{
    target:'es2022',outDir:'dist',emptyOutDir:true,minify:true,
    lib:{entry:path.join(root,'src/index.js'),name:'SpeedrunGlass',formats:['es','iife'],fileName:format=>format==='es'?'glass-effects.js':'glass-effects.global.js',cssFileName:'glass-effects'},
  },
});
await copyFile(path.join(root,'src/index.d.ts'),path.join(root,'dist/index.d.ts'));

// The demo is a single portable HTML file: file:// cannot load ES modules, and
// local-file poster pixels can taint the video material's canvas. Embed both the
// classic-script build and its media so opening the example needs no server.
const [template,glassCSS,demoCSS,runtime,bootstrap,poster,font]=await Promise.all([
  readFile(path.join(root,'demo/index.template.html'),'utf8'),
  readFile(path.join(root,'dist/glass-effects.css'),'utf8'),
  readFile(path.join(root,'demo/demo.css'),'utf8'),
  readFile(path.join(root,'dist/glass-effects.global.js'),'utf8'),
  readFile(path.join(root,'demo/demo.js'),'utf8'),
  readFile(path.join(root,'demo/assets/poster.png')),
  readFile(path.join(root,'demo/assets/MessinaSans-Regular.otf')),
]);
const inlineJS=source=>source.replace(/<\/script/gi,'<\\/script');
const inlineCSS=source=>source.replace(/<\/style/gi,'<\\/style');
const typography=demoCSS.replace("url('./assets/MessinaSans-Regular.otf')",()=>`url('data:font/otf;base64,${font.toString('base64')}')`);
const html=template
  .replace('<link rel="stylesheet" href="../dist/glass-effects.css">',()=>`<style>${inlineCSS(glassCSS)}</style>`)
  .replace('<link rel="stylesheet" href="demo.css">',()=>`<style>${inlineCSS(typography)}</style>`)
  .replace('poster="assets/poster.png"',()=>`poster="data:image/png;base64,${poster.toString('base64')}"`)
  .replace('<script src="../dist/glass-effects.global.js"></script>',()=>`<script>${inlineJS(runtime)}</script>`)
  .replace('<script src="demo.js"></script>',()=>`<script>${inlineJS(bootstrap)}</script>`);
await writeFile(path.join(root,'demo/index.html'),html);
console.log('Built standalone demo/index.html: no module imports, server or external visual assets required.');
await buildButtonDemo(root);
