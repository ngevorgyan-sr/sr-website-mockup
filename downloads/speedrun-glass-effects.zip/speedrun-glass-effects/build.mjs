import {build} from 'vite';
import {copyFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=path.dirname(fileURLToPath(import.meta.url));
await build({
  root,configFile:false,publicDir:false,
  build:{
    target:'es2022',outDir:'dist',emptyOutDir:true,minify:true,
    lib:{entry:path.join(root,'src/index.js'),name:'SpeedrunGlass',formats:['es','iife'],fileName:format=>format==='es'?'glass-effects.js':'glass-effects.global.js',cssFileName:'glass-effects'},
  },
});
await copyFile(path.join(root,'src/index.d.ts'),path.join(root,'dist/index.d.ts'));
