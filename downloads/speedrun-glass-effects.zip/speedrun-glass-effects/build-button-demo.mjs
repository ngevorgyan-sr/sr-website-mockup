import {readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';

export async function buildButtonDemo(root){
  const demo=path.join(root,'demo/buttons');
  const [shell,section,layout,variants,bootstrap,logos,runtime,glassCSS]=await Promise.all([
    readFile(path.join(demo,'index.template.html'),'utf8'),readFile(path.join(demo,'benefits.template.html'),'utf8'),
    readFile(path.join(demo,'section.css'),'utf8'),readFile(path.join(demo,'buttons.css'),'utf8'),
    readFile(path.join(demo,'buttons.js'),'utf8'),readFile(path.join(demo,'partner-logos.js'),'utf8'),
    readFile(path.join(root,'dist/glass-effects.global.js'),'utf8'),readFile(path.join(root,'dist/glass-effects.css'),'utf8'),
  ]);
  const labels=['01 · Current Glass','02 · Grey Gloss','03 · Flat Black'];
  const copies=labels.map((label,index)=>{
    const id=`button-0${index+1}`,ids=new Map([...section.matchAll(/\bid="([^"]+)"/g)].map(m=>[m[1],m[1]==='benefits'?id:`${id}-${m[1]}`]));
    let html=section.replace(/\bid="([^"]+)"/g,(_,old)=>`id="${ids.get(old)}"`).replace(/aria-labelledby="([^"]+)"/g,(_,old)=>`aria-labelledby="${old.split(' ').map(key=>ids.get(key)||key).join(' ')}"`);
    html=html.replace('<div class="benefits-intro">',()=>`<div class="benefits-intro"><p class="comparison-variant">${label}</p>`);
    let count=0;
    html=html.replace(/<a class="button button--border"[^>]*>([\s\S]*?)<\/a>/g,(_,content)=>{count++;return `<button class="comparison-button" type="button" data-button-design="0${index+1}">${content}</button>`;});
    if(count!==3)throw new Error('Expected three benefits CTAs in the shared section.');
    return html;
  }).join('\n');
  let html=shell.replace('<!-- BUTTON_DEMO_SECTIONS -->',()=>copies);
  for(const asset of new Set([...html.matchAll(/src="(assets\/[^"]+)"/g)].map(m=>m[1]))){
    const bytes=await readFile(path.join(demo,asset));
    html=html.replaceAll(`src="${asset}"`,`src="data:image/svg+xml;base64,${bytes.toString('base64')}"`);
  }
  let css=layout+'\n'+glassCSS+'\n'+variants;
  for(const asset of new Set([...css.matchAll(/url\('([^']+\.otf)'\)/g)].map(m=>m[1]))){
    const bytes=await readFile(path.join(demo,asset));
    css=css.replaceAll(`url('${asset}')`,`url('data:font/otf;base64,${bytes.toString('base64')}')`);
  }
  const safeJS=source=>source.replace(/<\/script/gi,'<\\/script');
  html=html.replace('<!-- BUTTON_DEMO_STYLES -->',()=>`<style>${css.replace(/<\/style/gi,'<\\/style')}</style>`)
    .replace('<!-- BUTTON_DEMO_SCRIPTS -->',()=>`<script>${safeJS(runtime)}</script><script>(()=>{${safeJS(logos)}\n})();</script><script>${safeJS(bootstrap)}</script>`);
  await writeFile(path.join(demo,'index.html'),html);
  console.log('Built portable demo/buttons/index.html with all three button finishes.');
}
