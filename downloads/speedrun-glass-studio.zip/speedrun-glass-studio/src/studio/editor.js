import './editor.css';
import { animationDuration, animationPhases, cubicBezier, keyframeAt, originScaleAt, quoteClickLightOnset, releaseAmounts, upwardStretchAt, waveFrame, warmupFrame } from '../glass/motion.js';
import { hoverMotionDuration, hoverMotionFrame } from '../glass/hover-motion.js';
import { createKeyframeGraph } from './keyframe-graph.js';
import { graphProgress, timelineProgress } from './keyframe-clock.js';

const clone = (value) => JSON.parse(JSON.stringify(value));
const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
const TRAVEL_PRESETS = [
  { name: 'Reference', value: [0.25, 0.1, 0.35, 1] },
  { name: 'Fluid', value: [0.22, 0.61, 0.36, 1] },
  { name: 'Even', value: [0, 0, 1, 1] },
  { name: 'Soft arrival', value: [0.25, 0.1, 0.25, 1] },
  { name: 'Slow → fast → slow', value: [0.42, 0, 0.58, 1] },
];
const MATERIAL_FIELDS = [
  { key: 'duration', label: 'Ripple duration', min: 200, max: 4000, step: 10, unit: 'ms', tip: 'Time for the expanding ripple to travel and settle.' },
  { key: 'strength', label: 'Warp', min: 0, max: 64, step: 0.5, unit: 'px', tip: 'How far the ripple bends the content beneath the glass.' },
  { key: 'width', label: 'Ring width', min: 0.08, max: 0.8, step: 0.01, percent: true, tip: 'Thickness of the curved ripple band. Wider feels softer.' },
  { key: 'dispersion', label: 'Color split', min: 0, max: 8, step: 0.05, unit: 'px', tip: 'Separation of the actual content’s red and blue channels.' },
  { key: 'glow', label: 'Iridescence', min: 0, max: 1, step: 0.01, percent: true, tip: 'Strength of the colored refraction layer. Its spectrum is editable below.' },
  { key: 'sheen', label: 'Ring highlight', min: 0, max: 1, step: 0.01, percent: true, tip: 'White illumination on the expanding ring, independent of the origin glow.' },
  { key: 'coreGlow', label: 'Origin glow', min: 0, max: 1, step: 0.01, percent: true, tip: 'Soft white light anchored to the center where the ripple begins.' },
  { key: 'stretch', label: 'Stretch', min: 0, max: 0.08, step: 0.001, percent: true, tip: 'Elastic stretch of the content. Its timing and intensity have independent controls below.' },
  { key: 'lift', label: 'Hover lift', min: 0, max: 12, step: 0.25, unit: 'px', buttonOnly: true, tip: 'How far a button rises while hovered. Leaving lowers it without another ripple.' },
  { key: 'hoverScale', label: 'Hover scale', min: 1, max: 1.12, step: 0.001, unit: '×', buttonOnly: true, tip: 'Button size while hovered. 1.020 means a gentle 2% enlargement.' },
];
const WARMUP_FIELDS = [
  { key: 'previewDuration', label: 'Windup preview duration', min: 200, max: 3000, step: 10, unit: 'ms', tip: 'Duration of Play warmup in this panel. On the page, scroll visibility drives the windup; lower Release at to fire sooner.' },
  { key: 'strength', label: 'Warmup warp', min: 0, max: 32, step: 0.5, unit: 'px', tip: 'Distortion of the incoming energy, independent of the release ripple.' },
  { key: 'width', label: 'Warmup ring width', min: 0.08, max: 0.8, step: 0.01, percent: true, tip: 'Thickness of the incoming band as it gathers toward the origin.' },
  { key: 'glow', label: 'Warmup iridescence', min: 0, max: 1, step: 0.005, percent: true, tip: 'Color intensity while energy collects. Uses the same editable spectrum.' },
  { key: 'sheen', label: 'Warmup ring highlight', min: 0, max: 1, step: 0.01, percent: true, tip: 'White light on the incoming ring before release.' },
  { key: 'coreGlow', label: 'Warmup origin glow', min: 0, max: 1, step: 0.01, percent: true, tip: 'White light collecting at the release point, independent of the incoming ring.' },
  { key: 'stretch', label: 'Warmup stretch', min: 0, max: 0.08, step: 0.001, percent: true, tip: 'Subtle elastic movement during collection, independent of the release stretch.' },
  { key: 'stretchY', label: 'Warmup upward stretch', min: 0, max: 0.16, step: 0.001, percent: true, tip: 'Stretches the content vertically toward the top, anchored at the bottom and clipped inside the frame. It clears with the windup fade after release.' },
];
const STOP_LABELS = ['Inner edge', 'Inner shoulder', 'Center', 'Outer shoulder', 'Outer edge'];
const svgNS = 'http://www.w3.org/2000/svg';
function make(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs)) {
    if (key === 'class') node.className = value;
    else if (key === 'text') node.textContent = value;
    else if (key === 'title') node.title = value;
    else if (value != null) node.setAttribute(key, String(value));
  }
  for (const child of children) node.append(child);
  return node;
}
function svg(tag, attrs = {}) {
  const node = document.createElementNS(svgNS, tag);
  for (const [key, value] of Object.entries(attrs)) node.setAttribute(key, String(value));
  return node;
}
function button(text, className = 'gs-button', attrs = {}) {
  return make('button', { type: 'button', class: className, text, ...attrs });
}
function titleLabel(text, tip, forId) {
  return make('label', { class: 'gs-label', for: forId, title: tip }, [make('span', { text }), make('span', { class: 'gs-help', text: 'i', 'aria-hidden': true })]);
}
function makeGraph(label) {
  const graph = svg('svg', { class: 'gs-graph', viewBox: '0 0 280 100', role: 'img', 'aria-label': label });
  const grid = svg('path', { class: 'gs-graph-grid', d: 'M14 12H266M14 48H266M14 84H266M14 12V84M77 12V84M140 12V84M203 12V84M266 12V84' });
  const under = svg('g');
  const line = svg('path', { class: 'gs-graph-line', fill: 'none' });
  const points = svg('g');
  graph.append(grid, under, line, points);
  return { graph, under, line, points };
}


/** Mounted by the development entry or the separately built Studio playground. */
export function mountGlassEditor(controller, {
  saveLabel='Save as final', savingLabel='Saving…',
  saveTitle='Save these values for the clean production mockup',
  savedMessage='Saved as the final preset.',
  pendingMessage='Saved. Newer changes still need saving.',
  footerNote='Studio controls are excluded from the final build.',
  badge='DEV',
} = {}) {
  if (!controller || typeof controller.getSettings !== 'function') throw new TypeError('Glass Studio needs a glass controller.');
  let settings = clone(controller.getSettings());
  const defaults = clone(controller.getDefaults?.() ?? controller.defaults ?? settings);
  let active = 'quote';
  let phase = 'release';
  let open = true, isScrubbing = false, pending = false, applying = false, destroyed = false;
  let lastFocus = null, objectUrl = null, playbackTimer = null, playbackFrame = null;
  const uid = `glass-studio-${Math.random().toString(36).slice(2, 8)}`;
  const listeners = [], renderers = [], linkedGraphs = [];
  const current = () => settings[active];
  const releaseHasGathering = () => active === 'quote' && phase === 'release' && current().warmup.enabled;
  const restProgress = () => phase === 'leave' || releaseHasGathering() ? 1 : 0;
  const showNumber = (input, value, committedInput) => {
    if (document.activeElement !== input || input === committedInput) input.value = String(Number(Number(value).toFixed(4)));
  };
  function listen(target, event, handler) {
    target.addEventListener(event, handler);
    listeners.push(() => target.removeEventListener(event, handler));
  }
  function clearPlayback() {
    if (playbackTimer !== null) { clearTimeout(playbackTimer); playbackTimer = null; }
    if (playbackFrame !== null) { cancelAnimationFrame(playbackFrame); playbackFrame = null; }
  }
  // Incomplete numbers remain editable; only complete, valid values affect the preview.
  function bindNumber(input, bounds, update) {
    function edit(commit) {
      if (input.disabled) return;
      const raw = input.value.trim();
      const value = raw === '' || input.validity.badInput || /[.eE+-]$/.test(raw) ? NaN : Number(raw);
      if (!Number.isFinite(value)) { if (commit) render(input); return; }
      const [min, max] = bounds();
      if (!commit && (value < min || value > max)) return;
      update(clamp(value, min, max));
      if (commit) render(input);
    }
    listen(input, 'input', () => edit(false));
    listen(input, 'change', () => edit(true));
    listen(input, 'blur', () => render(input));
  }
  function updateValue(path, value) {
    const next = clone(settings);
    const keys = path.split('.');
    let target = next[active];
    for (const key of keys.slice(0, -1)) target = target[key];
    target[keys.at(-1)] = value;
    apply(next);
  }
  function readValue(path) { return path.split('.').reduce((value, key) => value?.[key], current()); }
  function details(title, description) {
    const section = make('details', { class: 'gs-section gs-details' }, [make('summary', { text: title })]);
    if (description) section.append(make('p', { class: 'gs-note', text: description }));
    return section;
  }
  function scalar(section, field, prefix = '') {
    const path = prefix ? `${prefix}.${field.key}` : field.key;
    const id = `${uid}-${path.replaceAll('.', '-')}`;
    const multiplier = field.percent ? 100 : 1;
    const limits = () => field.bounds?.() ?? [field.min, field.max];
    const range = make('input', { type: 'range', id, class: 'gs-range', min: field.min, max: field.max, step: field.step, 'aria-describedby': `${id}-help` });
    const numeric = make('input', { type: 'number', class: 'gs-number', min: field.min * multiplier, max: field.max * multiplier, step: field.step * multiplier, 'aria-label': `${field.label} value`, inputmode: 'decimal' });
    const value = make('span', { class: 'gs-value' }, [numeric, make('span', { class: 'gs-unit', text: field.percent ? '%' : field.unit, 'aria-hidden': true })]);
    const row = make('div', { class: 'gs-control' }, [make('div', { class: 'gs-row' }, [titleLabel(field.label, field.tip, id), value]), range, make('span', { class: 'gs-visually-hidden', id: `${id}-help`, text: field.tip })]);
    section.append(row);
    listen(range, 'input', () => updateValue(path, clamp(Number(range.value), ...limits())));
    bindNumber(numeric, () => limits().map(v => v * multiplier), value => updateValue(path, value / multiplier));
    renderers.push(committedInput => {
      row.hidden = (!!field.buttonOnly && active !== 'button') || !!field.hideWhen?.();
      if (readValue(path) == null) return;
      const val = Number(readValue(path));
      const [min, max] = limits();
      range.min = String(min); range.max = String(max); range.value = String(val);
      numeric.min = String(min * multiplier); numeric.max = String(max * multiplier);
      range.style.setProperty('--gs-progress', `${clamp((val - min) / (max - min) * 100, 0, 100)}%`);
      showNumber(numeric, val * multiplier, committedInput);
    });
    return row;
  }
  function choice(section, label, tip, path, options) {
    const select = make('select', { class: 'gs-select', id: `${uid}-${path.replaceAll('.', '-')}`, 'aria-label': label });
    options.forEach(([value, text]) => select.append(make('option', { value, text })));
    const row = make('div', { class: 'gs-choice' }, [titleLabel(label, tip, select.id), select]);
    section.append(row);
    listen(select, 'change', () => updateValue(path, select.value));
    renderers.push(() => { select.value = readValue(path); });
    return row;
  }
  const graphAxes = () => make('div', { class: 'gs-graph-axes' }, [make('span', { text: 'Start' }), make('span', { text: 'Time →' }), make('span', { text: 'Finish' })]);
  function curve(section, path, label) {
    const select = make('select', { class: 'gs-select', 'aria-label': `${label} preset` });
    select.append(make('option', { value: 'custom', text: 'Custom curve' }));
    TRAVEL_PRESETS.forEach((preset, index) => select.append(make('option', { value: index, text: preset.name })));
    const graph = makeGraph(`${label}: time horizontally, progress vertically`);
    const inputs = [], grid = make('div', { class: 'gs-bezier-inputs' });
    ['x₁', 'y₁', 'x₂', 'y₂'].forEach((name, index) => {
      const input = make('input', { id: `${uid}-${path}-${index}`, type: 'number', class: 'gs-number gs-curve-number', min: 0, max: 1, step: 0.01, 'aria-label': `${label} ${['x1', 'y1', 'x2', 'y2'][index]}`, inputmode: 'decimal' });
      inputs.push(input);
      grid.append(make('label', { for: input.id, class: 'gs-small-label', text: name }, [input]));
      bindNumber(input, () => [0, 1], value => { const next = [...readValue(path)]; next[index] = value; updateValue(path, next); });
    });
    listen(select, 'change', () => { if (select.value !== 'custom') updateValue(path, [...TRAVEL_PRESETS[Number(select.value)].value]); });
    section.append(select, graph.graph, graphAxes(), grid);
    renderers.push(committedInput => {
      const values = readValue(path);
      if (!Array.isArray(values)) return;
      values.forEach((value, index) => showNumber(inputs[index], value, committedInput));
      const presetIndex = TRAVEL_PRESETS.findIndex(preset => preset.value.every((value, index) => Math.abs(value - values[index]) < 0.0001));
      select.value = presetIndex === -1 ? 'custom' : String(presetIndex);
      const [x1, y1, x2, y2] = values, px = v => 14 + 252 * v, py = v => 84 - 72 * v;
      graph.line.setAttribute('d', `M14 84C${px(x1)} ${py(y1)} ${px(x2)} ${py(y2)} 266 12`);
      graph.under.replaceChildren(svg('path', { class: 'gs-graph-tangent', d: `M14 84L${px(x1)} ${py(y1)}M266 12L${px(x2)} ${py(y2)}`, fill: 'none' }));
      graph.points.replaceChildren(svg('circle', { class: 'gs-graph-point', cx: px(x1), cy: py(y1), r: 3 }), svg('circle', { class: 'gs-graph-point', cx: px(x2), cy: py(y2), r: 3 }));
    });
  }
  function keyframes(section, path, label, { hue = false, response = false, freeEnds = false } = {}) {
    const count = hue ? 3 : 5, min = hue ? -360 : 0, max = hue ? 360 : 200;
    const graph = createKeyframeGraph({
      label, count, min:hue ? -360 : 0, max:hue ? 360 : 2,
      lockEndpointValues:!hue && !freeEnds,
      getFrames:()=>readValue(path),
      setFrames:frames=>updateValue(path,frames),
      onScrub:progress=>scrubLayer(path,progress),
    });
    linkedGraphs.push({path,graph});
    const inputs = [], grid = make('div', { class:'gs-envelope-grid',role:'group','aria-label':label });
    grid.append(make('span',{class:'gs-table-heading',text:'KEY'}),make('span',{class:'gs-table-heading',text:'TIME %'}),make('span',{class:'gs-table-heading',text:hue?'HUE SHIFT °':response?'RESPONSE %':'INTENSITY %'}));
    for(let index=0;index<count;index++){
      const time=make('input',{type:'number',class:'gs-number gs-envelope-number',min:0,max:100,step:.1,'aria-label':`${label} ${index+1} time percent`,inputmode:'decimal'});
      const value=make('input',{type:'number',class:'gs-number gs-envelope-number',min,max,step:1,'aria-label':`${label} ${index+1} ${hue?'hue degrees':response?'response percent':'intensity percent'}`,inputmode:'decimal'});
      if(index===0||index===count-1){
        time.disabled=true;value.disabled=!hue&&!freeEnds;
        time.title='0% and 100% anchor the start and end of this layer’s animation.';
        if(value.disabled)value.title=response?'These values anchor the starting pose and the completed movement. Move the inner keys to change the approach.':'Zero at both ends lets the effect start and finish at rest. Move the inner keys to change the attack and fade.';
      }
      inputs.push({time,value});grid.append(make('span',{class:'gs-key-number',text:`0${index+1}`}),time,value);
      bindNumber(time,()=>{const frames=readValue(path),before=frames[index-1].t,after=frames[index+1].t,gap=Math.min(.001,(after-before)/3);return[(before+gap)*100,(after-gap)*100];},percent=>{const frames=clone(readValue(path));frames[index].t=percent/100;updateValue(path,frames);});
      bindNumber(value,()=>[min,max],value=>{const frames=clone(readValue(path));frames[index].value=hue?value:value/100;updateValue(path,frames);});
    }
    const numbers=details('Numeric values');numbers.append(grid);section.append(graph.element,numbers);
    renderers.push(committedInput=>{
      const frames=readValue(path);if(!Array.isArray(frames))return;
      frames.forEach((frame,index)=>{showNumber(inputs[index].time,frame.t*100,committedInput);showNumber(inputs[index].value,frame.value*(hue?1:100),committedInput);});
      graph.render(layerProgress(path,Number(scrub.value)));
    });
  }

  const root = make('div', { class: 'glass-studio', 'data-glass-studio': '' });
  const launcher = button('Glass Studio', 'gs-launcher', { 'aria-expanded': true, 'aria-controls': `${uid}-panel`, title: 'Open the development glass controls' });
  launcher.prepend(make('span', { class: 'gs-status-dot', 'aria-hidden': true }));
  const panel = make('aside', { class: 'gs-panel', id: `${uid}-panel`, 'aria-label': 'Glass Studio effect controls' });
  const heading = make('div', { class: 'gs-heading' }, [make('h2', { text: 'Glass Studio' }), make('span', { class: 'gs-badge', text: badge })]);
  const close = button('−', 'gs-icon-button', { 'aria-label': 'Minimize Glass Studio', title: 'Minimize (Escape)' });
  const header = make('header', { class: 'gs-header' }, [heading, close]);
  const intro = make('p', { class: 'gs-intro', text: 'Collect. Release. Shape the ripple.' });
  const tablist = make('div', { class: 'gs-tabs', role: 'tablist', 'aria-label': 'Effect surface' }), tabs = {};
  for (const [key, label] of [['quote', 'Quote'], ['button', 'Buttons']]) {
    tabs[key] = button(label, 'gs-tab', { id: `${uid}-tab-${key}`, role: 'tab', 'aria-selected': key === active, 'aria-controls': `${uid}-content`, tabindex: key === active ? 0 : -1 });
    tablist.append(tabs[key]);
    listen(tabs[key], 'click', () => setActive(key));
    listen(tabs[key], 'keydown', event => {
      if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) {
        event.preventDefault(); setActive(event.key === 'Home' ? 'quote' : event.key === 'End' ? 'button' : key === 'quote' ? 'button' : 'quote'); tabs[active].focus();
      }
    });
  }
  const body = make('div', { class: 'gs-body', id: `${uid}-content`, role: 'tabpanel', 'aria-labelledby': `${uid}-tab-quote` });
  const preview = make('section', { class: 'gs-section gs-preview', 'aria-label': 'Preview effect' });
  const phaseGroup = make('div', { class: 'gs-segments', role: 'group', 'aria-label': 'Quote animation phase' }), phaseButtons = {};
  for (const [key, label] of [['warmup', 'Warmup'], ['release', 'Release'], ['click', 'Click'], ['enter', 'Enter'], ['leave', 'Leave']]) {
    phaseButtons[key] = button(label, 'gs-segment', { 'aria-pressed': key === phase });
    phaseGroup.append(phaseButtons[key]);
    listen(phaseButtons[key], 'click', () => {
      clearPlayback(); controller.reset(active); phase = key; isScrubbing = phase === 'leave' || releaseHasGathering(); scrub.value = '0'; render();
      // Leave starts raised; quote Release may start with gathered light.
      // Keep the page and its initial playhead aligned through live edits.
      if (isScrubbing) seek();
    });
  }
  const play = button('Play ripple', 'gs-button gs-primary');
  const resetPose = button('Reset pose', 'gs-button gs-secondary', { title: 'Return the surface to its undistorted state' });
  const scrub = make('input', { type: 'range', min: 0, max: 1, step: 0.001, value: restProgress(), id: `${uid}-scrub`, class: 'gs-range', 'aria-label': 'Timeline playhead', 'aria-describedby': `${uid}-timeline-help` });
  const scrubOutput = make('output', { for: scrub.id, text: '0%', class: 'gs-readout' });
  const previewHint = make('p', { class: 'gs-note' });
  const motionPreference = window.matchMedia('(prefers-reduced-motion: reduce)');
  const motionNote = make('p', { class: 'gs-note', role: 'status', text: 'Reduced motion is enabled: the page uses a brief light-only effect; the timeline shows configured motion.' });
  const showMotionPreference = () => { motionNote.hidden = !motionPreference.matches; };
  listen(motionPreference, 'change', showMotionPreference); showMotionPreference();
  const timeline = make('div', { class: 'gs-timeline', 'aria-label': 'Layer animation timeline' });
  const timelinePlot = svg('svg', { class: 'gs-timeline-plot', viewBox: '0 0 310 130', role: 'img', 'aria-label': 'Ripple and stretch intensity over time. Drag to scrub.' });
  const timelineGrid = svg('path', { class: 'gs-timeline-grid', fill: 'none', d: 'M80 8V100M134.5 8V100M189 8V100M243.5 8V100M298 8V100M80 48H298M80 95H298' });
  const timelineHundred = svg('path', { class: 'gs-timeline-hundred', fill: 'none' });
  const timelineTracks = [0, 1, 2, 3, 4].map(index => {
    const label = svg('text', { class: 'gs-timeline-label', x: 0, y: 23 + index * 47 });
    const value = svg('text', { class: 'gs-timeline-value', x: 0, y: 38 + index * 47 });
    const fill = svg('path', { class: `gs-timeline-fill gs-timeline-track-${index}` });
    const line = svg('path', { class: `gs-timeline-line gs-timeline-track-${index}`, fill: 'none' });
    const dot = svg('circle', { class: `gs-timeline-dot gs-timeline-track-${index}`, r: 3 });
    return { label, value, fill, line, dot };
  });
  const timelineTicks = [0, .5, 1].map(t => svg('text', { class: 'gs-timeline-tick', x: 80 + t * 218, y: 120, 'text-anchor': t === 0 ? 'start' : t === 1 ? 'end' : 'middle' }));
  const timelineCursor = svg('g', { class: 'gs-timeline-cursor', 'aria-hidden': true });
  const timelineHeadLine = svg('path', { d: 'M0 5V103', class: 'gs-timeline-playhead' });
  timelineCursor.append(timelineHeadLine, svg('path', { d: 'M-4 3H4V8L0 12L-4 8Z', class: 'gs-timeline-handle' }));
  timelinePlot.append(timelineGrid, timelineHundred, ...timelineTracks.flatMap(track => [track.fill, track.line, track.label, track.value]), ...timelineTicks, timelineCursor, ...timelineTracks.map(track => track.dot));
  timeline.append(timelinePlot, scrub, make('p', { class: 'gs-timeline-help', id: `${uid}-timeline-help`, text: 'Drag the playhead to freeze the page at any moment.' }));
  let timelineDragging = false;
  const scrubTimeline = event => {
    const rect = timelinePlot.getBoundingClientRect();
    if (!rect.width) return;
    clearPlayback(); isScrubbing = true;
    scrub.value = String(clamp(((event.clientX - rect.left) / rect.width * 310 - 80) / 218, 0, 1));
    seek();
  };
  listen(timelinePlot, 'pointerdown', event => { if (event.button !== 0) return; event.preventDefault(); timelineDragging = true; timelinePlot.setPointerCapture(event.pointerId); scrub.focus({ preventScroll: true }); scrubTimeline(event); });
  listen(timelinePlot, 'pointermove', event => { if (timelineDragging) scrubTimeline(event); });
  for (const eventName of ['pointerup', 'pointercancel', 'lostpointercapture']) listen(timelinePlot, eventName, () => { timelineDragging = false; });
  preview.append(make('div', { class: 'gs-row gs-preview-top' }, [make('span', { class: 'gs-eyebrow', text: 'PREVIEW' }), phaseGroup]), make('div', { class: 'gs-preview-actions' }, [play, resetPose]), make('div', { class: 'gs-row' }, [titleLabel('Timeline', 'Intensity tracks show how much of a layer is active. Origin size shows its size multiplier: 1× is the base glow size. Drag the playhead to inspect the pose.', scrub.id), scrubOutput]), timeline, previewHint, motionNote);
  listen(scrub, 'input', () => { clearPlayback(); isScrubbing = true; seek(); });
  listen(play, 'click', () => {
    clearPlayback(); isScrubbing = false; scrub.value = '0'; scrubOutput.textContent = 'Playing';
    controller.play(active, phase); renderSpectrum(); renderTimelineCursor();
    setStatus(`${active === 'quote' ? 'Quote' : 'Button'} ${phase === 'release' ? 'ripple' : phase} playing.`, false);
    const duration = timelineDuration();
    const began = performance.now();
    // Advance the editor only during an explicit preview; there is no idle loop.
    const tick = now => {
      const progress = clamp((now - began) / duration, 0, 1);
      scrub.value = String(progress); renderTimelineCursor(); renderSpectrum();
      playbackFrame = progress < 1 ? requestAnimationFrame(tick) : null;
    };
    playbackFrame = requestAnimationFrame(tick);
    playbackTimer = setTimeout(() => {
      playbackTimer = null; if (destroyed) return;
      if (playbackFrame !== null) cancelAnimationFrame(playbackFrame); playbackFrame = null;
      scrub.value = '1'; renderTimelineCursor(); renderSpectrum();
      setStatus(pending ? 'Preview complete. Unsaved changes.' : 'Preview complete.', false);
    }, duration);
  });
  listen(resetPose, 'click', () => { clearPlayback(); isScrubbing = false; scrub.value = String(restProgress()); controller.reset(active); renderSpectrum(); renderTimelineCursor(); setStatus('Surface reset.', false); });

  const buttonSurface = make('section', {class:'gs-section','aria-label':'Button glass surface controls'},[
    make('h3',{text:'Glass surface'}),
    make('p',{class:'gs-note gs-before-controls',text:'Refraction, color separation and distortion sample the actual hero video. Blur, tint, light and shape also tune the other buttons over their browser backdrop.'}),
  ]);
  const videoPreview = button('Preview over video','gs-button gs-secondary');
  buttonSurface.append(videoPreview);
  listen(videoPreview,'click',()=>{
    clearPlayback();controller.showVideoButton?.();isScrubbing=false;scrub.value=String(restProgress());
    renderTimelineCursor();renderSpectrum();setStatus('Hero video button in view. Hover it, play Enter, or scrub the timeline.',false);
  });
  const customTint = make('input',{type:'checkbox',id:`${uid}-custom-tint`});
  buttonSurface.append(make('label',{class:'gs-toggle',for:customTint.id},[customTint,make('span',{text:'Use custom tint color'})]));
  const tintColor = make('input',{type:'color',class:'gs-color','aria-label':'Glass tint color'});
  const tintHex = make('input',{type:'text',class:'gs-hex','aria-label':'Glass tint hex color',maxlength:7,spellcheck:'false'});
  const tintRow = make('div',{class:'gs-row'},[tintColor,tintHex]);
  buttonSurface.append(tintRow);
  listen(customTint,'change',()=>updateValue('surface.tintColor',customTint.checked?'#ffffff':null));
  listen(tintColor,'input',()=>updateValue('surface.tintColor',tintColor.value));
  listen(tintHex,'input',()=>{if(/^#[0-9a-fA-F]{6}$/.test(tintHex.value))updateValue('surface.tintColor',tintHex.value);});
  listen(tintHex,'blur',()=>render(tintHex));
  renderers.push(committedInput=>{
    const value=current().surface?.tintColor;
    customTint.checked=typeof value==='string';tintRow.hidden=!customTint.checked;
    tintColor.value=value||'#ffffff';
    if(document.activeElement!==tintHex||committedInput===tintHex)tintHex.value=value||'#ffffff';
  });
  scalar(buttonSurface,{key:'videoTintOpacity',label:'Video button tint opacity',min:0,max:2,step:.01,percent:true,tip:'Tint for the button over the hero video only. 0% removes tint; 100% keeps its original tint; 200% doubles it.'},'surface');
  scalar(buttonSurface,{key:'tintOpacity',label:'Other buttons tint opacity',min:0,max:2,step:.01,percent:true,tip:'Tint for all remaining buttons, independent of the video button. 0% removes tint; 100% keeps each original tint; 200% doubles it.'},'surface');
  scalar(buttonSurface,{key:'opacity',label:'Glass opacity',min:0,max:1,step:.01,percent:true,tip:'Opacity of the glass layers. The button label stays fully readable at every setting.'},'surface');
  scalar(buttonSurface,{key:'brightness',label:'Glass brightness',min:.25,max:2,step:.01,percent:true,tip:'Brightness of the glass and the view through it. 100% is unchanged; the text keeps its own color.'},'surface');
  const surfaceOptics = details('Refraction & light','The hero lens samples the moving video. Refraction bends it, chromatic aberration separates its colors, and edge distortion thickens the rounded lens while keeping its center calm. Other buttons use their native backdrop with these light and shape settings.');
  scalar(surfaceOptics,{key:'refraction',label:'Refraction',min:0,max:2,step:.01,percent:true,tip:'Strength of bending in the actual hero video beneath the button. 0% leaves the sampled video aligned.'},'surface');
  scalar(surfaceOptics,{key:'chromAberration',label:'Chromatic aberration',min:0,max:1,step:.005,percent:true,tip:'Separates the red, green and blue samples of the hero video along the curved glass. This is separate from the animated ripple color split.'},'surface');
  scalar(surfaceOptics,{key:'distortion',label:'Edge distortion',min:0,max:1,step:.01,percent:true,tip:'Smooth bending through the thick rounded glass edge. The center stays calm.'},'surface');
  scalar(surfaceOptics,{key:'blur',label:'Backdrop blur',min:0,max:24,step:.1,unit:'px',tip:'Softens the video through the hero lens, or the browser backdrop behind other buttons.'},'surface');
  scalar(surfaceOptics,{key:'saturation',label:'Backdrop saturation',min:0,max:3,step:.01,percent:true,tip:'Color saturation through the glass. 100% preserves the original colors; 0% removes color.'},'surface');
  scalar(surfaceOptics,{key:'edgeHighlight',label:'Edge highlight',min:0,max:2,step:.01,percent:true,tip:'Soft optical light inside the glass near its edge. It does not control the button border.'},'surface');
  scalar(surfaceOptics,{key:'specular',label:'Specular light',min:0,max:2,step:.01,percent:true,tip:'Strength of the glossy reflection rolling across the rounded bevel.'},'surface');
  scalar(surfaceOptics,{key:'specularSharpness',label:'Specular sharpness',min:0,max:1,step:.01,percent:true,tip:'Highlight width: 0% is broad and soft; 100% is narrow and crisp. 50% preserves the previous shape. Specular light controls strength separately.'},'surface');
  scalar(surfaceOptics,{key:'fresnel',label:'Fresnel light',min:0,max:2,step:.01,percent:true,tip:'Soft rim reflection that follows the outline around its rounded corners.'},'surface');
  const surfaceShape = details('Glass shape','The bevel rounds the glass thickness while the button keeps its rectangular outline. Z radius controls depth; corner radius changes only the outline.');
  choice(surfaceShape,'Bevel mode','Rounded bevel curves the glass thickness along the perimeter. Dome extends the curvature farther inward. These profiles keep the button’s outline.','surface.bevelMode',[['pill','Rounded bevel'],['dome','Dome']]);
  scalar(surfaceShape,{key:'zRadius',label:'Z radius',min:1,max:100,step:1,unit:'px',tip:'Glass thickness and optical bevel width, independent of the outline corners. Increase for a thicker lens with a broader, smooth roll.'},'surface');
  const originalCorners = make('input',{type:'checkbox',id:`${uid}-original-corners`});
  surfaceShape.append(make('label',{class:'gs-toggle',for:originalCorners.id},[originalCorners,make('span',{text:'Use original corners'})]));
  listen(originalCorners,'change',()=>updateValue('surface.cornerRadius',originalCorners.checked?null:8));
  scalar(surfaceShape,{key:'cornerRadius',label:'Corner radius',min:0,max:100,step:1,unit:'px',hideWhen:()=>current().surface?.cornerRadius==null,tip:'Overrides the button’s corner radius, including its glass layers and frame. 0px gives square corners.'},'surface');
  renderers.push(()=>{originalCorners.checked=current().surface?.cornerRadius==null;});
  const videoShadow = details('Video button shadow','A soft dark shadow for the video button, with no bright center. It follows the button’s lift.');
  scalar(videoShadow,{key:'videoShadowOpacity',label:'Video shadow opacity',min:0,max:1,step:.01,percent:true,tip:'Darkness beneath the video button only. Does not change the other buttons.'},'surface');
  scalar(videoShadow,{key:'videoShadowSpread',label:'Video shadow spread',min:0,max:32,step:.5,unit:'px',tip:'Size of the shadow beneath the video button as it lifts.'},'surface');
  const surfaceShadow = details('Other button shadows','Tune the bright center and dark rim independently. Both follow lift timing; lowering the rim’s opacity keeps the center bright.');
  scalar(surfaceShadow,{key:'shadowCenterOpacity',label:'Center brightness',min:0,max:2,step:.001,percent:true,tip:'Strength of the light inside the cast shadow. Independent of the dark rim; zero removes only the light.'},'surface');
  scalar(surfaceShadow,{key:'shadowCenterSpread',label:'Center spread',min:0,max:32,step:.5,unit:'px',tip:'Size of the bright area inside the shadow, independent of the dark rim.'},'surface');
  scalar(surfaceShadow,{key:'shadowOpacity',label:'Dark rim opacity',min:0,max:1,step:.01,percent:true,tip:'Darkness of the feathered outer shadow. Lower it without reducing center brightness.'},'surface');
  scalar(surfaceShadow,{key:'shadowSpread',label:'Dark rim spread',min:0,max:32,step:.5,unit:'px',tip:'Size of the dark outer shadow as the button lifts, independent of the bright center.'},'surface');
  buttonSurface.append(surfaceOptics,surfaceShape,videoShadow,surfaceShadow);

  const materialHeading = make('h3', { text: 'Release · glass & light' });
  const material = make('section', { class: 'gs-section', 'aria-label': 'Glass and movement properties' }, [materialHeading]);
  MATERIAL_FIELDS.forEach(field => scalar(material, { ...field, hideWhen: () => phase === 'leave' && !field.buttonOnly }));
  const arrival = make('section', { class: 'gs-section', 'aria-label': 'Windup and release controls' }, [
    make('h3', { text: 'Windup & release' }),
    make('p', { class: 'gs-note gs-before-controls', text: 'Scroll drives the windup. Lower Release at to fire sooner; a shorter gap between these two points makes the buildup quicker.' }),
  ]);
  const warmup = make('section', { class: 'gs-section', 'aria-label': 'Warmup properties' }, [make('h3', { text: 'Warmup · collect energy' }), make('p', { class: 'gs-note gs-before-controls', text: 'Scroll gathers energy toward the origin. At the release point, the outward ripple takes over.' })]);
  const warmupEnabled = make('input', { type: 'checkbox', id: `${uid}-warmup-enabled` });
  arrival.append(make('label', { class: 'gs-toggle', for: warmupEnabled.id }, [warmupEnabled, make('span', { text: 'Enable scroll warmup' })]));
  listen(warmupEnabled, 'change', () => updateValue('warmup.enabled', warmupEnabled.checked));
  scalar(arrival, {key:'start',label:'Begin collecting at',min:0,max:.6,step:.01,percent:true,bounds:()=>[0,Math.min(.6,current().warmup.release-.01)],tip:'Visible share of the quote frame when the incoming energy begins.'},'warmup');
  scalar(arrival, {key:'release',label:'Release at',min:.05,max:1,step:.01,percent:true,bounds:()=>[Math.max(.05,current().warmup.start+.01),1],tip:'Visible share of the quote that releases the ripple. Lower values fire sooner while scrolling.'},'warmup');
  scalar(arrival, {key:'releaseFade',label:'Windup fade after release',min:0,max:2000,step:10,unit:'ms',tip:'How quickly the collected origin glow, color halo and stretch clear after release. Zero clears the collected energy immediately.'},'warmup');
  scalar(arrival, {key:'coreDuration',label:'Origin glow duration',min:80,max:4000,step:10,unit:'ms',tip:'Total lifetime of the new light pulse at the origin, including its colored halo. The traveling ring keeps its own duration.'});
  WARMUP_FIELDS.forEach(field => scalar(warmup, field, 'warmup'));
  const warmupGlow = details('Warmup origin intensity', 'Shape the glow and color at the source as you scroll. This multiplies the collecting light: 100% preserves it; lower values fade it. Both endpoint intensities are editable, and Release starts with the resulting amount.');
  keyframes(warmupGlow,'warmup.coreEnvelope','Warmup glow keyframe',{freeEnds:true});
  const warmupCurve = details('Collection curve', 'Controls how the incoming energy gathers as the frame becomes visible.');
  curve(warmupCurve, 'warmup.curve', 'Collection curve');
  const coreTiming = details('Origin glow keyframes', 'Shape the short light pulse at the source. These keyframes cover Origin glow duration, independently of the traveling ring. 0% is clear; 100% uses the chosen Origin glow strength. The colored halo fades with the same pulse.');
  const clickOnsetNote = make('p', { class: 'gs-note gs-before-controls', text: 'Click light fades in softly over the first part of the pulse. This graph keeps your saved keyframes; the Origin glow timeline above shows the softened result. Warp and stretch keep their timing.' });
  coreTiming.append(clickOnsetNote);
  keyframes(coreTiming, 'coreEnvelope', 'Origin glow keyframe');
  const coreMotion = details('Origin glow movement', 'The white glow and colored halo contract together before release, then expand as they fade. Sizes multiply Origin glow size: 100% is its base size. Expansion shares the source fade timing above.');
  scalar(coreMotion, {key:'startScale',label:'Windup start size',min:.1,max:3,step:.01,percent:true,tip:'Source size before contraction begins, relative to the base Origin glow size.'},'coreMotion');
  scalar(coreMotion, {key:'releaseScale',label:'Size at release',min:.1,max:3,step:.01,percent:true,tip:'The contracted source size at the release point. Both phases meet at this size without a jump.'},'coreMotion');
  scalar(coreMotion, {key:'endScale',label:'Fade-out size',min:.1,max:3,step:.01,percent:true,tip:'Source size reached as its glow and colors disappear. Larger than Size at release creates an outward follow-through.'},'coreMotion');
  scalar(coreMotion, {key:'contractStart',label:'Start contraction at',min:0,max:.95,step:.01,percent:true,tip:'Progress through the windup when the glow starts contracting. This is windup progress, not quote visibility.'},'coreMotion');
  const contractionCurve = details('Contraction curve', 'Shapes the squeeze from Start contraction at to the release point.');
  curve(contractionCurve, 'coreMotion.contractCurve', 'Contraction curve');
  const expansionCurve = details('Expansion curve', 'Shapes the outward motion during the source pulse and any remaining windup fade. The source still clears at the selected fade times.');
  curve(expansionCurve, 'coreMotion.expandCurve', 'Expansion curve');
  coreMotion.append(contractionCurve, expansionCurve);

  const origin = details('Origin & radius', 'Choose the fixed release point and how far the circle travels. A smaller radius makes the arc easier to see on buttons.');
  const originSelect = make('select', { class: 'gs-select', 'aria-label': 'Ripple origin preset' });
  const originPresets = { top: { x: .5, y: 0 }, left: { x: 0, y: .5 }, center: { x: .5, y: .5 }, bottom: { x: .5, y: 1 }, right: { x: 1, y: .5 } };
  [['top', 'Top center'], ['left', 'Left edge'], ['center', 'Center'], ['bottom', 'Bottom center'], ['right', 'Right edge'], ['custom', 'Custom position']].forEach(([value, text]) => originSelect.append(make('option', { value, text })));
  origin.append(originSelect);
  listen(originSelect, 'change', () => { if (originPresets[originSelect.value]) updateValue('origin', { ...originPresets[originSelect.value] }); });
  scalar(origin, { key: 'x', label: 'Origin · horizontal', min: 0, max: 1, step: .01, percent: true, tip: '0% is the left edge; 100% is the right edge.' }, 'origin');
  scalar(origin, { key: 'y', label: 'Origin · vertical', min: 0, max: 1, step: .01, percent: true, tip: '0% is the top edge; 100% is the bottom edge.' }, 'origin');
  scalar(origin, { key: 'radius', label: 'Radius reach', min: .2, max: 1.6, step: .01, percent: true, tip: 'Maximum circle radius relative to the distance from the origin to the farthest corner. 100% reaches that corner.' });
  const hoverOrigin = choice(origin, 'Hover origin', 'Entry edge uses the side the pointer arrives from. Fixed uses the position above.', 'hoverOrigin', [['entry', 'From pointer entry edge'], ['fixed', 'Fixed origin']]);
  choice(origin, 'Click origin', 'Pointer makes each click ripple outward from that exact point.', 'clickOrigin', [['pointer', 'From the pointer'], ['fixed', 'Fixed origin']]);

  const highlight = details('Glow size & ring softness', 'The origin glow and moving ring have separate brightness controls above. Shape their falloff here.');
  scalar(highlight, { key: 'highlightSize', label: 'Origin glow size', hideWhen: () => active === 'quote' && phase === 'click', min: .05, max: 1, step: .01, percent: true, tip: 'Soft origin glow radius relative to the component’s shorter side.' });
  scalar(highlight, { key: 'clickHighlightSize', label: 'Click origin size', min: .05, max: 1, step: .01, percent: true, hideWhen: () => active !== 'quote' || phase !== 'click', tip: 'Radius of the compact pointer flash, relative to the frame’s shorter side. Independent of the larger scroll origin glow.' });
  scalar(highlight, { key: 'ringSoftness', label: 'Ring softness', min: .05, max: 1, step: .01, percent: true, tip: 'Feather the bright ring’s edges. Larger values blend the highlight more softly into the surface.' });

  const spectrum = details('Refraction spectrum', 'Drag the three inner stops or edit the swatches. The bar describes the colors across the curved ripple band.');
  const gradient = make('div', { class: 'gs-gradient', 'aria-label': 'Editable refraction gradient' });
  const gradientPaint = make('div', { class: 'gs-gradient-paint', 'aria-hidden': true });
  gradient.append(gradientPaint);
  const gradientAxes = make('div', { class: 'gs-gradient-axes' }, [make('span', { text: 'Inner edge' }), make('span', { text: 'Center' }), make('span', { text: 'Outer edge' })]);
  const spectrumRows = [], spectrumGrid = make('div', { class: 'gs-spectrum-grid' });
  function stopBounds(index) { const stops = current().spectrum, before = stops[index - 1].position, after = stops[index + 1].position, gap = Math.min(.005, (after - before) / 3); return [before + gap, after - gap]; }
  function setStopPosition(index, position) { const stops = clone(current().spectrum); stops[index].position = clamp(position, ...stopBounds(index)); updateValue('spectrum', stops); }
  for (let index = 0; index < 5; index++) {
    const label = STOP_LABELS[index], endpoint = index === 0 || index === 4;
    const marker = button('', 'gs-gradient-stop', { role: 'slider', 'aria-label': `${label} gradient position`, 'aria-valuemin': 0, 'aria-valuemax': 100, title: endpoint ? 'Edge positions are fixed. Edit the color below.' : 'Drag to move this color, or use arrow keys.', tabindex: endpoint ? -1 : 0 });
    marker.setAttribute('aria-disabled', String(endpoint));
    gradient.append(marker);
    const color = make('input', { type: 'color', class: 'gs-color', 'aria-label': `${label} color`, title: `Edit ${label.toLowerCase()} color` });
    const position = make('input', { type: 'number', class: 'gs-number gs-stop-position', min: 0, max: 100, step: .5, 'aria-label': `${label} position percent`, inputmode: 'decimal' });
    position.disabled = endpoint;
    const hex = make('input', { type: 'text', class: 'gs-hex', maxlength: 7, spellcheck: false, 'aria-label': `${label} hex color`, pattern: '#[0-9a-fA-F]{6}', title: 'Six-digit hex color, such as #ff7664' });
    spectrumRows.push({ marker, color, hex, position });
    spectrumGrid.append(make('div', { class: 'gs-stop-swatch' }, [color, make('span', { class: 'gs-stop-label', text: label })]), hex, make('span', { class: 'gs-value' }, [position, make('span', { class: 'gs-unit', text: '%' })]));
    const setColor = value => { const stops = clone(current().spectrum); stops[index].color = value; updateValue('spectrum', stops); };
    listen(color, 'input', () => setColor(color.value));
    listen(hex, 'input', () => { if (/^#[0-9a-fA-F]{6}$/.test(hex.value)) setColor(hex.value); });
    listen(hex, 'change', () => { if (/^#[0-9a-fA-F]{6}$/.test(hex.value)) setColor(hex.value); render(hex); });
    listen(hex, 'blur', () => render(hex));
    bindNumber(position, () => stopBounds(index).map(v => v * 100), value => setStopPosition(index, value / 100));
    if (endpoint) continue;
    let dragging = false;
    const drag = event => { const rect = gradient.getBoundingClientRect(); if (rect.width) setStopPosition(index, (event.clientX - rect.left) / rect.width); };
    listen(marker, 'pointerdown', event => { if (event.button !== 0) return; event.preventDefault(); dragging = true; marker.setPointerCapture(event.pointerId); marker.focus(); drag(event); });
    listen(marker, 'pointermove', event => { if (dragging) drag(event); });
    listen(marker, 'pointerup', () => { dragging = false; });
    listen(marker, 'pointercancel', () => { dragging = false; });
    listen(marker, 'lostpointercapture', () => { dragging = false; });
    listen(marker, 'keydown', event => {
      if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
      event.preventDefault(); const bounds = stopBounds(index), currentPosition = current().spectrum[index].position;
      setStopPosition(index, event.key === 'Home' ? bounds[0] : event.key === 'End' ? bounds[1] : currentPosition + (event.key === 'ArrowRight' ? 1 : -1) * (event.shiftKey ? .05 : .01));
    });
  }
  const hueReadout = make('output', { class: 'gs-readout', text: '0°' });
  spectrum.append(gradient, gradientAxes, spectrumGrid, make('div', { class: 'gs-subheading gs-row' }, [make('h4', { text: 'Color shift over time' }), hueReadout]), make('p', { class: 'gs-note', text: 'Angle shifts the whole spectrum as the ripple expands, like turning holographic film. Scrub the preview to inspect each moment.' }));
  keyframes(spectrum, 'spectrumShift', 'Spectrum keyframe', { hue: true });
  const timing = details('Ripple travel curve', 'Controls the speed of the expanding circle.');
  curve(timing, 'travel', 'Ripple travel curve');
  const amplitude = details('Ripple intensity keyframes', 'Time says when. Intensity scales the traveling ring’s Warp, Iridescence, and Ring highlight: 0% = off, 100% = the chosen amount, 200% = twice that amount. Origin glow has its own clock and keyframes. Follow the Ripple track in the timeline.');
  keyframes(amplitude, 'envelope', 'Ripple keyframe');
  const stretch = details('Stretch timing', 'The elastic movement has its own delay, duration, and curve. It can settle after the ripple has passed.');
  scalar(stretch, { key: 'stretchDelay', label: 'Stretch delay', min: 0, max: 2000, step: 10, unit: 'ms', tip: 'Wait before the elastic movement begins.' });
  scalar(stretch, { key: 'stretchDuration', label: 'Stretch duration', min: 200, max: 4000, step: 10, unit: 'ms', tip: 'Time for the stretch to build and return to its original size.' });
  stretch.append(make('h4', { class: 'gs-subheading', text: 'Stretch progression curve' }));
  curve(stretch, 'stretchTravel', 'Stretch curve');
  const stretchIntensity = details('Stretch intensity keyframes', 'Time says when within the stretch animation. Intensity multiplies the chosen Stretch: 0% = original size, 100% = the chosen amount, 200% = twice. Zero endpoints restore the frame. The timeline’s Stretch track includes its separate delay, duration, and curve.');
  keyframes(stretchIntensity, 'stretchEnvelope', 'Stretch keyframe');

  const hoverSections = [];
  for (const [path, label] of [['liftMotion', 'Lift'], ['scaleMotion', 'Scale']]) {
    const section = details(`${label} timing & keyframes`, `${label} has its own timing, curve, and response. Use Enter or Leave above to tune each direction.`);
    const enter = make('div', { class: 'gs-motion-phase' });
    const leave = make('div', { class: 'gs-motion-phase' });
    enter.append(make('h4', { class: 'gs-motion-heading', text: 'Enter · reach the hover pose' }));
    scalar(enter, { key: 'duration', label: `${label} enter duration`, min: 80, max: 3000, step: 10, unit: 'ms', tip: `Time for the button’s ${label.toLowerCase()} to reach its hover pose.` }, path);
    scalar(enter, { key: 'delay', label: `${label} enter delay`, min: 0, max: 2000, step: 10, unit: 'ms', tip: `Wait before ${label.toLowerCase()} begins on hover.` }, path);
    enter.append(make('h4', { class: 'gs-subheading', text: 'Enter curve' }));
    curve(enter, `${path}.curve`, `${label} enter curve`);
    enter.append(make('h4', { class: 'gs-subheading', text: 'Enter response keyframes' }), make('p', { class: 'gs-note', text: `0% is the resting pose; 100% reaches your chosen Hover ${label.toLowerCase()}. Values above 100% overshoot, then settle at 100%.` }));
    keyframes(enter, `${path}.keyframes`, `${label} enter keyframe`, { response: true });
    leave.append(make('h4', { class: 'gs-motion-heading', text: 'Leave · return to rest' }));
    scalar(leave, { key: 'returnDuration', label: `${label} leave duration`, min: 80, max: 3000, step: 10, unit: 'ms', tip: `Time for the button’s ${label.toLowerCase()} to return to rest, without another ripple.` }, path);
    leave.append(make('h4', { class: 'gs-subheading', text: 'Leave curve' }));
    curve(leave, `${path}.returnCurve`, `${label} leave curve`);
    leave.append(make('h4', { class: 'gs-subheading', text: 'Leave response keyframes' }), make('p', { class: 'gs-note', text: '0% begins at the hovered pose; 100% completes the return to rest. Above 100% moves briefly beyond rest. The timeline shows the resulting pose: 100% raised, 0% resting.' }));
    keyframes(leave, `${path}.returnKeyframes`, `${label} leave keyframe`, { response: true });
    section.append(enter, leave); hoverSections.push({ section, enter, leave });
  }

  const presets = make('section', { class: 'gs-section gs-presets', 'aria-label': 'Preset files' });
  const download = button('Export JSON', 'gs-text-button', { title: 'Download the current quote and button settings' });
  const importButton = button('Import JSON', 'gs-text-button', { title: 'Load a saved quote and button preset' });
  const restore = button('Reset defaults', 'gs-text-button', { title: 'Restore both surfaces to the default settings' });
  const fileInput = make('input', { type: 'file', accept: '.json,application/json', class: 'gs-visually-hidden', tabindex: -1, 'aria-label': 'Import glass settings file' });
  presets.append(download, importButton, restore, fileInput);
  body.append(preview, buttonSurface, arrival, coreMotion, warmupCurve, coreTiming, material, warmup, warmupGlow, ...hoverSections.map(item => item.section), origin, highlight, spectrum, timing, amplitude, stretch, stretchIntensity, presets);
  const status = make('p', { class: 'gs-status', role: 'status', 'aria-live': 'polite', text: 'Ready to tune.' });
  const save = button(saveLabel, 'gs-button gs-primary gs-save', { title: saveTitle });
  const footer = make('footer', { class: 'gs-footer' }, [status, save, make('p', { class: 'gs-footer-note', text: footerNote })]);
  panel.append(header, intro, tablist, body, footer); root.append(panel, launcher); document.body.append(root);

  function setStatus(message, dirty = true, error = false) {
    status.textContent = message; status.classList.toggle('is-error', error);
    if (dirty) pending = true;
    root.classList.toggle('has-changes', pending);
  }
  function setOpen(next) {
    open = next; panel.hidden = !open; launcher.setAttribute('aria-expanded', String(open)); root.classList.toggle('is-open', open);
    if (open) { lastFocus = document.activeElement; close.focus(); }
    else if (panel.contains(document.activeElement)) (lastFocus?.isConnected && !panel.contains(lastFocus) ? lastFocus : launcher).focus();
  }
  function setActive(next) {
    clearPlayback(); controller.reset(active);
    active = next; phase = active === 'button' ? 'enter' : 'release'; isScrubbing = releaseHasGathering(); scrub.value = '0'; body.scrollTop = 0; render();
    if (isScrubbing) seek();
  }
  function seek() {
    const progress = Number(scrub.value); scrubOutput.textContent = `${Math.round(progress * 100)}%`;
    scrub.style.setProperty('--gs-progress', `${progress * 100}%`); controller.seek(active, progress, phase); renderSpectrum(); renderTimelineCursor();
  }
  function apply(next) {
    try {
      // A timed preview captures its duration. Stop both clocks before changing it;
      // a paused scrub instead stays at the selected moment while values change.
      if (playbackTimer !== null || playbackFrame !== null) {
        clearPlayback(); controller.reset(active); isScrubbing = false; scrub.value = String(restProgress());
      }
      const wasResting = !isScrubbing && Number(scrub.value) === restProgress();
      applying = true; controller.updateSettings(clone(next)); settings = clone(controller.getSettings());
      if (wasResting) scrub.value = String(restProgress());
      setStatus('Unsaved changes.'); render(); if (isScrubbing) seek(); return true;
    } catch (error) { setStatus(error?.message || 'Could not apply these settings.', false, true); return false; }
    finally { applying = false; }
  }
  function timelineDuration() {
    if (phase === 'warmup') return current().warmup.previewDuration;
    if (active !== 'button') return animationDuration(current());
    const hoverDuration = hoverMotionDuration(current(), phase);
    return phase === 'leave' ? hoverDuration : Math.max(animationDuration(current()), hoverDuration);
  }
  function layerProgress(path, progress) {
    return graphProgress(path, current(), phase, timelineDuration(), progress);
  }
  function scrubLayer(path, local) {
    clearPlayback(); isScrubbing = true;
    scrub.value = String(timelineProgress(path, current(), phase, timelineDuration(), local));
    seek();
  }
  function timelineLabels() {
    return phase === 'warmup' ? ['Incoming ring', 'Origin glow', 'Upward pull', 'Origin size'] : active === 'button' ? phase === 'leave' ? ['Lift', 'Scale'] : ['Ripple', 'Stretch', 'Lift', 'Scale'] : [phase === 'click' ? 'Ripple warp' : 'Ripple', 'Stretch', 'Upward pull', 'Origin glow', 'Origin size'];
  }
  function opticalProgress(progress) { return clamp(progress * timelineDuration() / animationDuration(current()), 0, 1); }
  function timelineState(progress) {
    if (phase === 'warmup') { const state = warmupFrame(progress, current(), { width: 1, height: 1 }); return [state.amplitude, state.core, current().warmup.stretchY ? state.build : 0, originScaleAt(progress,current(),{phase:'warmup'})]; }
    if (active === 'button') {
      const hover = hoverMotionFrame(clamp(progress * timelineDuration() / hoverMotionDuration(current(), phase), 0, 1), current(), phase);
      const pose = [hover.liftProgress, hover.scaleProgress];
      if (phase === 'leave') return pose;
      const optical = waveFrame(opticalProgress(progress), current(), { width: 1, height: 1 });
      return [optical.amplitude, optical.stretchAmplitude, ...pose];
    }
    const state = waveFrame(progress, current(), { width: 1, height: 1 });
    const amounts = releaseAmounts(state, current(), releaseHasGathering());
    const lightOnset = phase === 'click' ? quoteClickLightOnset(state.elapsed,current()) : 1;
    return [state.amplitude,
      amounts.stretchAmount / (current().stretch || current().warmup.stretch || 1),
      upwardStretchAt(progress,current(),{fromWarmup:releaseHasGathering()}) / (current().warmup.stretchY || 1),
      amounts.coreAmount * lightOnset / (current().coreGlow || current().warmup.coreGlow || 1),
      originScaleAt(progress,current(),{fromWarmup:releaseHasGathering()})];
  }
  let timelineMaximums = [];
  function isHoverTrack(track) { return active === 'button' && (phase === 'leave' || track >= 2); }
  function timelineY(value, track) {
    const base = 48 + track * 47;
    if (isHoverTrack(track)) return base - (clamp(value, -1, 2) + 1) * 12;
    const maximum = timelineMaximums[track] || (phase === 'warmup' ? 1 : 2);
    return base - clamp(value, 0, maximum) / maximum * 36;
  }
  function formatTime(milliseconds) { return milliseconds < 1000 ? `${Math.round(milliseconds)} ms` : `${(milliseconds / 1000).toFixed(2)} s`; }
  function renderTimelineCursor() {
    const progress = Number(scrub.value), duration = timelineDuration(), values = timelineState(progress), x = 80 + progress * 218;
    timelineCursor.setAttribute('transform', `translate(${x} 0)`);
    timelineTracks.forEach((track, index) => {
      if (index >= values.length) return;
      const isOriginSize = active === 'quote' && index === (phase === 'warmup' ? 3 : 4);
      track.value.textContent = isOriginSize ? `${values[index].toFixed(2)}×` : `${Math.round(values[index] * 100)}%`;
      track.dot.setAttribute('cx', x); track.dot.setAttribute('cy', timelineY(values[index], index));
    });
    scrubOutput.textContent = `${formatTime(progress * duration)} / ${formatTime(duration)}`;
    scrub.setAttribute('aria-valuetext', `${Math.round(progress * 100)} percent, ${formatTime(progress * duration)} of ${formatTime(duration)}`);
    scrub.style.setProperty('--gs-progress', `${progress * 100}%`);
    linkedGraphs.forEach(({path,graph})=>graph.updateCursor(layerProgress(path,progress),`${formatTime(progress * duration)} / ${formatTime(duration)}`));
  }
  function renderTimeline() {
    const duration = timelineDuration(), labels = timelineLabels(), count = labels.length, bottom = 48 + (count - 1) * 47;
    const samples = Array.from({ length: 81 }, (_, index) => timelineState(index / 80));
    timelineMaximums = labels.map((_, index) => Math.max(phase === 'warmup' ? 1 : 2, ...samples.map(values => values[index])));
    timelinePlot.setAttribute('viewBox', `0 0 310 ${bottom + 35}`);
    timelinePlot.setAttribute('aria-label', `${labels.join(', ')} over ${formatTime(duration)}. Drag to scrub.`);
    timelineGrid.setAttribute('d', [80, 134.5, 189, 243.5, 298].map(x => `M${x} 8V${bottom + 5}`).join('') + labels.map((_, index) => `M80 ${timelineY(0, index)}H298`).join(''));
    timelineHundred.setAttribute('d', labels.map((_, index) => `M80 ${timelineY(1, index)}H298`).join(''));
    timelineHeadLine.setAttribute('d', `M0 5V${bottom + 8}`);
    timelineTracks.forEach((track, trackIndex) => {
      for (const node of Object.values(track)) node.style.display = trackIndex < count ? '' : 'none';
      if (trackIndex >= count) return;
      track.label.textContent = labels[trackIndex];
      const points = samples.map((values, index) => `${80 + index / 80 * 218} ${timelineY(values[trackIndex], trackIndex)}`);
      track.line.setAttribute('d', `M${points.join('L')}`);
      track.fill.setAttribute('d', `M80 ${timelineY(0, trackIndex)}L${points.join('L')}L298 ${timelineY(0, trackIndex)}Z`);
    });
    timelineTicks.forEach((tick, index) => { tick.textContent = formatTime(duration * index / 2); tick.setAttribute('y', bottom + 25); });
    renderTimelineCursor();
  }
  function renderSpectrum(committedInput) {
    const stops = current().spectrum;
    gradientPaint.style.background = `linear-gradient(to right, ${stops.map(stop => `${stop.color} ${stop.position * 100}%`).join(', ')})`;
    const progress = Number(scrub.value);
    const colorProgress = phase === 'warmup' ? 1 - cubicBezier(progress, current().warmup.curve) : phase === 'leave' ? 0 : animationPhases(opticalProgress(progress), current()).optical;
    const hue = keyframeAt(colorProgress, current().spectrumShift);
    gradientPaint.style.filter = `hue-rotate(${hue}deg)`;
    hueReadout.textContent = `${Math.round(hue)}° at ${Math.round(Number(scrub.value) * 100)}%`;
    spectrumRows.forEach(({ marker, color, hex, position }, index) => {
      const stop = stops[index]; marker.style.left = `${stop.position * 100}%`; marker.style.setProperty('--gs-stop-color', stop.color);
      marker.setAttribute('aria-valuenow', String(Math.round(stop.position * 1000) / 10)); color.value = stop.color;
      if (document.activeElement !== hex || hex === committedInput) hex.value = stop.color;
      showNumber(position, stop.position * 100, committedInput);
    });
  }
  function render(committedInput) {
    for (const [key, tab] of Object.entries(tabs)) { tab.setAttribute('aria-selected', String(key === active)); tab.tabIndex = key === active ? 0 : -1; }
    body.setAttribute('aria-labelledby', `${uid}-tab-${active}`);
    phaseGroup.setAttribute('aria-label', active === 'button' ? 'Button animation phase' : 'Quote animation phase');
    for (const [key, node] of Object.entries(phaseButtons)) { node.setAttribute('aria-pressed', String(key === phase)); node.hidden = active === 'button' ? !['enter', 'leave'].includes(key) : !['warmup', 'release', 'click'].includes(key); }
    const collecting = active === 'quote' && phase === 'warmup';
    material.hidden = collecting; warmup.hidden = !collecting;
    buttonSurface.hidden = active !== 'button';
    arrival.hidden = coreMotion.hidden = warmupCurve.hidden = coreTiming.hidden = active !== 'quote';
    coreMotion.hidden = active !== 'quote' || phase === 'click';
    coreTiming.hidden = active !== 'quote' || collecting;
    clickOnsetNote.hidden = active !== 'quote' || phase !== 'click';
    warmupGlow.hidden = !collecting;
    for (const section of [timing, amplitude, stretch, stretchIntensity]) section.hidden = collecting || phase === 'leave';
    for (const section of [origin, highlight, spectrum]) section.hidden = phase === 'leave';
    for (const item of hoverSections) { item.section.hidden = active !== 'button'; item.enter.hidden = phase === 'leave'; item.leave.hidden = phase !== 'leave'; }
    materialHeading.textContent = active === 'button' ? phase === 'leave' ? 'Leave · lift & scale' : 'Enter · glass & movement' : 'Release · glass & light';
    hoverOrigin.hidden = active !== 'button';
    play.textContent = collecting ? 'Play warmup' : active === 'button' ? phase === 'leave' ? 'Play leave' : 'Play enter' : phase === 'click' ? 'Play click' : 'Play release';
    previewHint.textContent = collecting ? 'Preview the scroll-only collection. Scrub here or in any keyframe graph.' : active === 'quote' ? phase === 'click' ? 'A fresh outward ripple. Source and ring light fade in softly; warp and stretch keep their timing. Tune Click origin size below.' : 'Scroll release begins where collection ends. Use Click to preview a fresh pointer ripple.' : phase === 'leave' ? 'Lift and scale return to rest. Leaving adds no new ripple.' : 'Enter combines ripple, stretch, lift, and scale on one timeline.';
    warmupEnabled.checked = current().warmup.enabled;
    originSelect.value = Object.keys(originPresets).find(key => Math.abs(originPresets[key].x - current().origin.x) < .0001 && Math.abs(originPresets[key].y - current().origin.y) < .0001) ?? 'custom';
    renderers.forEach(renderer => renderer(committedInput)); renderSpectrum(committedInput); renderTimeline();
    scrub.style.setProperty('--gs-progress', `${Number(scrub.value) * 100}%`);
  }
  listen(launcher, 'click', () => setOpen(!open)); listen(close, 'click', () => setOpen(false));
  listen(root, 'keydown', event => { if (event.key === 'Escape' && open) { event.preventDefault(); setOpen(false); } });
  listen(download, 'click', () => {
    if (objectUrl) URL.revokeObjectURL(objectUrl);
    objectUrl = URL.createObjectURL(new Blob([JSON.stringify(settings, null, 2) + '\n'], { type: 'application/json' }));
    make('a', { href: objectUrl, download: 'speedrun-glass-preset.json' }).click(); setStatus('Preset exported.', false);
  });
  listen(importButton, 'click', () => fileInput.click());
  listen(fileInput, 'change', async () => {
    const file = fileInput.files?.[0]; if (!file) return;
    try {
      if (file.size > 64 * 1024) throw new Error('Choose a glass preset smaller than 64 KB.');
      const candidate = JSON.parse(await file.text()); if (destroyed) return;
      // The shared settings validator is authoritative for imports and live edits.
      if (apply(candidate?.settings ?? candidate)) setStatus('Preset imported. Export or save to keep these values.');
    } catch (error) { if (!destroyed) setStatus(error?.message || 'Could not read this JSON preset.', false, true); }
    fileInput.value = '';
  });
  listen(restore, 'click', () => { if (apply(clone(defaults))) setStatus('Defaults restored. Export or save to keep these values.'); });
  listen(save, 'click', async () => {
    save.disabled = true; save.textContent = savingLabel; const savedSnapshot = JSON.stringify(settings);
    try {
      await controller.save(); if (destroyed) return;
      pending = JSON.stringify(settings) !== savedSnapshot; root.classList.toggle('has-changes', pending);
      setStatus(pending ? pendingMessage : savedMessage, false);
    } catch (error) { if (!destroyed) setStatus(error?.message || 'Save failed. Export JSON to keep your settings.', false, true); }
    finally { if (!destroyed) { save.disabled = false; save.textContent = saveLabel; } }
  });
  const unsubscribe = controller.subscribe?.(next => { if (applying || destroyed) return; settings = clone(next?.button && next?.quote ? next : controller.getSettings()); render(); });
  root.classList.add('is-open'); render();
  return {
    open: () => setOpen(true), close: () => setOpen(false),
    cancelPlayback() {
      clearPlayback();
      if (destroyed) return;
      isScrubbing = false; scrub.value = String(restProgress()); renderSpectrum(); renderTimelineCursor();
      setStatus('Preview interrupted.', false);
    },
    destroy() { destroyed = true; clearPlayback(); if (isScrubbing) controller.reset(active); if (typeof unsubscribe === 'function') unsubscribe(); listeners.forEach(remove => remove()); linkedGraphs.forEach(({graph})=>graph.destroy()); if (objectUrl) URL.revokeObjectURL(objectUrl); root.remove(); },
  };
}
