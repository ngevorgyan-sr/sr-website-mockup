import './keyframe-graph.css';
import { keyframeAt } from '../glass/motion.js';

const NS = 'http://www.w3.org/2000/svg';
const DEFAULT_EASE = [1 / 3, 0, 2 / 3, 1];
const PRESETS = [
  {name:'Smooth',value:DEFAULT_EASE},
  {name:'Linear',value:[0,0,1,1]},
  {name:'Ease in',value:[.42,0,1,1]},
  {name:'Ease out',value:[0,0,.58,1]},
  {name:'Ease in/out',value:[.42,0,.58,1]},
];
const WIDTH=310, HEIGHT=145, LEFT=16, RIGHT=294, TOP=12, BOTTOM=108, RAIL=132;
const clamp=(value,min=0,max=1)=>Math.max(min,Math.min(max,value));
const copy=frames=>frames.map(point=>({...point,...(point.ease?{ease:[...point.ease]}:{})}));
const svg=(tag,attributes={})=>{
  const node=document.createElementNS(NS,tag);
  for(const [name,value] of Object.entries(attributes))node.setAttribute(name,String(value));
  return node;
};
const html=(tag,className,text)=>{
  const node=document.createElement(tag);if(className)node.className=className;if(text)node.textContent=text;return node;
};

/** Persistent SVG controls: parent renders never replace focused/captured nodes. */
export function createKeyframeGraph({label='Intensity',count=5,min=0,max=2,lockEndpointValues=true,getFrames,setFrames,onScrub=()=>{}}={}) {
  if(typeof getFrames!=='function'||typeof setFrames!=='function')throw new TypeError('A keyframe graph requires getFrames and setFrames.');
  if(count<2||!Number.isInteger(count)||!(max>min))throw new TypeError('A keyframe graph needs at least two points and an increasing value range.');
  let selected=0,progress=0,drag=null,destroyed=false;
  const listeners=[];
  const listen=(target,event,handler)=>{target.addEventListener(event,handler);listeners.push(()=>target.removeEventListener(event,handler));};
  const frames=()=>getFrames();
  const x=time=>LEFT+clamp(time)*(RIGHT-LEFT);
  const y=value=>BOTTOM-clamp((value-min)/(max-min))*(BOTTOM-TOP);
  const fromX=value=>clamp((value-LEFT)/(RIGHT-LEFT));
  const fromY=value=>clamp(min+(BOTTOM-value)/(BOTTOM-TOP)*(max-min),min,max);
  const ease=()=>frames()[selected]?.ease||DEFAULT_EASE;
  const endpoint=index=>index===0||index===count-1;
  const valueText=value=>max>10?`${Number(value.toFixed(1))} degrees`:`${Number((value*100).toFixed(1))} percent`;
  const pointPosition=index=>({x:x(frames()[index].t),y:y(frames()[index].value)});
  const controlPosition=index=>{
    const a=frames()[selected],b=frames()[selected+1],points=ease();
    return {x:x(a.t+(b.t-a.t)*points[index*2]),y:y(a.value+(b.value-a.value)*points[index*2+1])};
  };
  const element=html('div','gs-keyframe-editor');
  const chart=svg('svg',{class:'gs-kfg-chart',viewBox:`0 0 ${WIDTH} ${HEIGHT}`,preserveAspectRatio:'none',role:'group','aria-label':`${label} editable graph`});
  const title=svg('title');title.textContent=`${label}. Drag points to edit; drag the bottom rail to preview.`;
  const grid=svg('path',{class:'gs-kfg-grid',d:[0,.25,.5,.75,1].map(t=>`M${x(t)} ${TOP}V${BOTTOM}`).join('')+[TOP,(TOP+BOTTOM)/2,BOTTOM].map(v=>`M${LEFT} ${v}H${RIGHT}`).join('')});
  const zero=svg('path',{class:'gs-kfg-zero',d:min<=0&&max>=0?`M${LEFT} ${y(0)}H${RIGHT}`:''});
  const curvePath=svg('path',{class:'gs-kfg-line'});
  const selectedPath=svg('path',{class:'gs-kfg-selected'});
  const tangents=svg('path',{class:'gs-kfg-tangents'});
  const cursor=svg('path',{class:'gs-kfg-playhead'});
  const cursorDot=svg('circle',{class:'gs-kfg-cursor-dot',r:2.5});
  const rail=svg('g',{'data-kfg-rail':'',class:'gs-kfg-rail',role:'slider',tabindex:0,'aria-label':`${label} playhead`,'aria-valuemin':0,'aria-valuemax':100});
  const railHit=svg('rect',{x:LEFT-6,y:RAIL-9,width:RIGHT-LEFT+12,height:18,class:'gs-kfg-hit'});
  const railLine=svg('path',{d:`M${LEFT} ${RAIL}H${RIGHT}`,class:'gs-kfg-rail-line'});
  const railThumb=svg('circle',{cy:RAIL,r:4,class:'gs-kfg-rail-thumb'});
  rail.append(railHit,railLine,railThumb);
  const handles=[0,1].map(index=>{
    const group=svg('g',{'data-kfg-handle':index,class:'gs-kfg-handle',tabindex:0,role:'slider','aria-label':`${label} easing handle ${index+1}`,'aria-valuemin':0,'aria-valuemax':100});
    group.append(svg('circle',{r:9,class:'gs-kfg-hit'}),svg('circle',{r:3.5,class:'gs-kfg-handle-dot'}));
    return group;
  });
  const points=Array.from({length:count},(_,index)=>{
    const group=svg('g',{'data-kfg-point':index,class:'gs-kfg-point',tabindex:0,role:'slider','aria-label':`${label} keyframe ${index+1}`,'aria-valuemin':min,'aria-valuemax':max});
    group.append(svg('circle',{r:10,class:'gs-kfg-hit'}),svg('circle',{r:4,class:'gs-kfg-point-dot'}));
    return group;
  });
  chart.append(title,grid,zero,curvePath,selectedPath,tangents,cursor,cursorDot,rail,...handles,...points);
  const selectors=html('div','gs-kfg-selectors');
  const segmentLabel=html('label','gs-kfg-select-label','Segment');
  const segment=document.createElement('select');segment.className='gs-select';segment.setAttribute('aria-label',`${label} segment`);
  for(let index=0;index<count-1;index++){
    const option=document.createElement('option');option.value=String(index);option.textContent=`${index+1} → ${index+2}`;segment.append(option);
  }
  segmentLabel.append(segment);
  const presetLabel=html('label','gs-kfg-select-label','Easing');
  const preset=document.createElement('select');preset.className='gs-select';preset.setAttribute('aria-label',`${label} segment easing`);
  const custom=document.createElement('option');custom.value='custom';custom.textContent='Custom';preset.append(custom);
  PRESETS.forEach((item,index)=>{const option=document.createElement('option');option.value=String(index);option.textContent=item.name;preset.append(option);});
  presetLabel.append(preset);selectors.append(segmentLabel,presetLabel);
  const inputRow=html('div','gs-kfg-inputs');
  const inputs=['x₁','y₁','x₂','y₂'].map((name,index)=>{
    const inputLabel=html('label','gs-kfg-input-label',name);
    const input=document.createElement('input');input.className='gs-number';input.type='number';input.min='0';input.max='1';input.step='.01';input.inputMode='decimal';
    input.setAttribute('aria-label',`${label} segment ${['x1','y1','x2','y2'][index]}`);
    inputLabel.append(input);inputRow.append(inputLabel);return input;
  });
  const note=html('p','gs-note gs-kfg-help',lockEndpointValues?'Drag inner points to edit time and amount. Endpoint times and amounts stay anchored.':'Drag points to edit time and amount. First and last times stay fixed; their amounts are editable.');
  const selectedNote=html('p','gs-note gs-kfg-selection');
  const clock=html('div','gs-kfg-clock');
  const elapsed=html('span','','Linked timeline'),position=html('span');
  clock.append(elapsed,position);
  element.append(chart,clock,selectors,inputRow,note,selectedNote);

  function commit(next){
    if(destroyed)return;
    setFrames(next);
    render(progress);
  }
  function setEase(next,reset=false){
    const value=copy(frames());
    if(reset)delete value[selected].ease;else value[selected].ease=next.map(v=>clamp(v));
    commit(value);
  }
  function movePoint(index,position){
    const next=copy(frames()),point=next[index];
    if(!endpoint(index)){
      const before=next[index-1].t,after=next[index+1].t,gap=Math.min(.001,(after-before)/3);
      point.t=clamp(fromX(position.x),before+gap,after-gap);
    }
    if(!endpoint(index)||!lockEndpointValues)point.value=fromY(position.y);
    if(point.t===frames()[index].t&&point.value===frames()[index].value){render(progress);return;}
    commit(next);
  }
  function moveHandle(index,position){
    const a=frames()[selected],b=frames()[selected+1],next=[...ease()];
    next[index*2]=clamp((fromX(position.x)-a.t)/(b.t-a.t));
    // A flat interval has no visible y tangent; its y easing remains editable by keyboard/numbers.
    if(Math.abs(b.value-a.value)>1e-9)next[index*2+1]=clamp((fromY(position.y)-a.value)/(b.value-a.value));
    setEase(next);
  }
  function scrub(next){progress=clamp(next);updateCursor(progress);onScrub(progress);}
  const location=event=>{
    const rect=chart.getBoundingClientRect();
    return {x:(event.clientX-rect.left)/Math.max(1,rect.width)*WIDTH,y:(event.clientY-rect.top)/Math.max(1,rect.height)*HEIGHT};
  };
  listen(chart,'pointerdown',event=>{
    if(event.button!==0||destroyed)return;
    const target=event.target.closest?.('[data-kfg-point],[data-kfg-handle],[data-kfg-rail]');
    const pos=location(event);
    if(target?.hasAttribute('data-kfg-point')){
      const index=Number(target.getAttribute('data-kfg-point'));selected=Math.min(index,count-2);
      const original=pointPosition(index);drag={kind:'point',index,pointerId:event.pointerId,dx:pos.x-original.x,dy:pos.y-original.y};
      target.focus({preventScroll:true});render(progress);
    }else if(target?.hasAttribute('data-kfg-handle')){
      const index=Number(target.getAttribute('data-kfg-handle')),original=controlPosition(index);
      drag={kind:'handle',index,pointerId:event.pointerId,dx:pos.x-original.x,dy:pos.y-original.y};target.focus({preventScroll:true});
    }else{
      drag={kind:'scrub',pointerId:event.pointerId};rail.focus({preventScroll:true});scrub(fromX(pos.x));
    }
    event.preventDefault();chart.setPointerCapture(event.pointerId);
  });
  listen(chart,'pointermove',event=>{
    if(!drag||event.pointerId!==drag.pointerId||destroyed)return;
    event.preventDefault();const pos=location(event);
    if(drag.kind==='point')movePoint(drag.index,{x:pos.x-drag.dx,y:pos.y-drag.dy});
    else if(drag.kind==='handle')moveHandle(drag.index,{x:pos.x-drag.dx,y:pos.y-drag.dy});
    else scrub(fromX(pos.x));
  });
  const stopDrag=event=>{if(drag&&event.pointerId===drag.pointerId)drag=null;};
  listen(chart,'pointerup',stopDrag);listen(chart,'pointercancel',stopDrag);listen(chart,'lostpointercapture',stopDrag);
  listen(chart,'keydown',event=>{
    if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'].includes(event.key))return;
    const target=event.target.closest?.('[data-kfg-point],[data-kfg-handle],[data-kfg-rail]');if(!target)return;
    event.preventDefault();const step=event.shiftKey ? .1 : .01;
    if(target.hasAttribute('data-kfg-rail')){
      const delta=['ArrowRight','ArrowUp'].includes(event.key)?step:-step;
      scrub(event.key==='Home'?0:event.key==='End'?1:progress+delta);return;
    }
    if(target.hasAttribute('data-kfg-point')){
      const index=Number(target.getAttribute('data-kfg-point'));selected=Math.min(index,count-2);
      const pos=pointPosition(index);
      if(event.key==='ArrowLeft')pos.x-=step*(RIGHT-LEFT);
      if(event.key==='ArrowRight')pos.x+=step*(RIGHT-LEFT);
      if(event.key==='ArrowUp')pos.y-=step*(BOTTOM-TOP);
      if(event.key==='ArrowDown')pos.y+=step*(BOTTOM-TOP);
      if(event.key==='Home')pos.y=BOTTOM;
      if(event.key==='End')pos.y=TOP;
      movePoint(index,pos);return;
    }
    const index=Number(target.getAttribute('data-kfg-handle')),next=[...ease()];
    if(event.key==='ArrowLeft')next[index*2]-=step;
    if(event.key==='ArrowRight')next[index*2]+=step;
    const verticalSign=Math.sign(frames()[selected+1].value-frames()[selected].value)||1;
    if(event.key==='ArrowUp')next[index*2+1]+=step*verticalSign;
    if(event.key==='ArrowDown')next[index*2+1]-=step*verticalSign;
    if(event.key==='Home')next[index*2]=0;
    if(event.key==='End')next[index*2]=1;
    setEase(next);
  });
  listen(segment,'change',()=>{selected=clamp(Number(segment.value),0,count-2);render(progress);});
  listen(preset,'change',()=>{if(preset.value!=='custom')setEase(PRESETS[Number(preset.value)].value,Number(preset.value)===0);});
  inputs.forEach((input,index)=>{
    const edit=commitInput=>{
      const raw=input.value.trim(),value=Number(raw);
      if(!raw||!Number.isFinite(value)||(!commitInput&&(value<0||value>1)))return;
      const next=[...ease()];next[index]=clamp(value);if(commitInput)input.value=String(next[index]);setEase(next);
    };
    listen(input,'input',()=>edit(false));listen(input,'change',()=>edit(true));
    listen(input,'blur',()=>{input.value=String(Number(ease()[index].toFixed(4)));});
  });

  function updateCursor(next=progress,elapsedLabel){
    if(destroyed)return;
    progress=Number.isFinite(next)?clamp(next):progress;
    if(elapsedLabel)elapsed.textContent=`Timeline · ${elapsedLabel}`;
    position.textContent=`Layer ${Math.round(progress*100)}%`;
    const px=x(progress);cursor.setAttribute('d',`M${px} ${TOP}V${RAIL}`);
    cursorDot.setAttribute('cx',px);cursorDot.setAttribute('cy',y(keyframeAt(progress,frames())));
    railThumb.setAttribute('cx',px);rail.setAttribute('aria-valuenow',String(Number((progress*100).toFixed(1))));
    rail.setAttribute('aria-valuetext',`${Math.round(progress*100)} percent of ${label.toLowerCase()}`);
  }
  function render(next=progress){
    if(destroyed)return;
    const values=frames();if(!Array.isArray(values)||values.length!==count)return;
    let path=`M${x(values[0].t)} ${y(values[0].value)}`,chosen='';
    for(let index=0;index<count-1;index++){
      const a=values[index],b=values[index+1],e=a.ease||DEFAULT_EASE,dt=b.t-a.t,dv=b.value-a.value;
      const command=`C${x(a.t+dt*e[0])} ${y(a.value+dv*e[1])} ${x(a.t+dt*e[2])} ${y(a.value+dv*e[3])} ${x(b.t)} ${y(b.value)}`;
      path+=command;if(index===selected)chosen=`M${x(a.t)} ${y(a.value)}${command}`;
    }
    curvePath.setAttribute('d',path);selectedPath.setAttribute('d',chosen);
    points.forEach((node,index)=>{
      const point=values[index];node.setAttribute('transform',`translate(${x(point.t)} ${y(point.value)})`);
      node.setAttribute('aria-valuenow',String(point.value));
      node.setAttribute('aria-valuetext',`${Number((point.t*100).toFixed(1))} percent time, ${valueText(point.value)}${endpoint(index)?', time fixed':''}${endpoint(index)&&lockEndpointValues?', value fixed':''}`);
      node.setAttribute('aria-readonly',String(endpoint(index)&&lockEndpointValues));
      node.classList.toggle('is-anchor',endpoint(index)&&lockEndpointValues);
    });
    const a=pointPosition(selected),b=pointPosition(selected+1),h0=controlPosition(0),h1=controlPosition(1);
    tangents.setAttribute('d',`M${a.x} ${a.y}L${h0.x} ${h0.y}M${b.x} ${b.y}L${h1.x} ${h1.y}`);
    handles.forEach((node,index)=>{
      const handle=index?h1:h0,e=ease();node.setAttribute('transform',`translate(${handle.x} ${handle.y})`);
      node.setAttribute('aria-valuenow',String(Math.round(e[index*2]*100)));
      node.setAttribute('aria-valuetext',`x ${Number(e[index*2].toFixed(3))}, y ${Number(e[index*2+1].toFixed(3))}. Left/right changes x; up/down changes y.`);
    });
    segment.value=String(selected);
    const e=ease(),presetIndex=PRESETS.findIndex(item=>item.value.every((v,index)=>Math.abs(v-e[index])<1e-6));preset.value=presetIndex<0?'custom':String(presetIndex);
    inputs.forEach((input,index)=>{if(document.activeElement!==input)input.value=String(Number(e[index].toFixed(4)));});
    selectedNote.textContent=Math.abs(values[selected+1].value-values[selected].value)<1e-9?'Flat segment: y easing has no visible effect. Use the numeric fields or arrow keys to set it.':'Hollow handles shape the selected segment. Arrow keys edit; Shift moves faster. The bottom rail previews without editing.';
    updateCursor(next);
  }
  render();
  return {element,render,updateCursor,destroy(){
    if(destroyed)return;destroyed=true;
    if(drag){try{chart.releasePointerCapture(drag.pointerId);}catch{}drag=null;}
    listeners.forEach(remove=>remove());element.remove();
  }};
}
