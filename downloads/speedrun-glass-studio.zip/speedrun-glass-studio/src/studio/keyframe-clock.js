import { clamp, cubicBezier } from '../glass/motion.js';

const unit = value => Number.isFinite(value) ? clamp(value) : value === Infinity ? 1 : 0;
const duration = (value, fallback = 1) => Number.isFinite(value) && value > 0 ? value : fallback;
const delay = value => Number.isFinite(value) ? Math.max(0,value) : 0;
const HOVER_CURVE = [.22,.61,.36,1];

function inverseCurve(value, curve) {
  const target = unit(value);
  if (target === 0 || target === 1) return target;
  let low = 0, high = 1;
  for (let step = 0; step < 25; step++) {
    const middle = (low+high)/2;
    if (cubicBezier(middle,curve) < target) low = middle;
    else high = middle;
  }
  return (low+high)/2;
}

function keyframeClock(path, settings) {
  const optical = duration(settings.duration);
  if (path === 'warmup.coreEnvelope') return {duration:duration(settings.warmup?.previewDuration,optical),delay:0};
  if (path === 'coreEnvelope') return {duration:duration(settings.coreDuration,optical),delay:0};
  if (path === 'stretchEnvelope') return {duration:duration(settings.stretchDuration,optical),delay:delay(settings.stretchDelay),curve:settings.stretchTravel};
  if (path.startsWith('liftMotion.') || path.startsWith('scaleMotion.')) {
    const name = path.split('.')[0], motion = settings[name] || {}, leaving = path.endsWith('returnKeyframes');
    const fallback = name === 'liftMotion' ? {enter:360,leave:240} : {enter:420,leave:280};
    return {
      duration:duration(leaving ? motion.returnDuration : motion.duration,leaving ? fallback.leave : fallback.enter),
      delay:leaving ? 0 : delay(motion.delay),
      curve:(leaving ? motion.returnCurve : motion.curve) || HOVER_CURVE,
    };
  }
  return {duration:optical,delay:0};
}

/** Position on a layer's keyframe graph at a shared timeline position. */
export function graphProgress(path, settings, phase, totalDuration, globalProgress) {
  const progress = unit(globalProgress);
  if (phase === 'warmup') return path === 'spectrumShift' ? unit(1-cubicBezier(progress,settings.warmup.curve)) : progress;
  const clock = keyframeClock(path,settings);
  const local = unit((progress*duration(totalDuration)-clock.delay)/clock.duration);
  return clock.curve ? unit(cubicBezier(local,clock.curve)) : local;
}

/** Inverse graph scrubbing; clamped endpoints seek the layer's start/end time. */
export function timelineProgress(path, settings, phase, totalDuration, localProgress) {
  const local = unit(localProgress);
  if (phase === 'warmup') return path === 'spectrumShift' ? inverseCurve(1-local,settings.warmup.curve) : local;
  const clock = keyframeClock(path,settings);
  const time = clock.curve ? inverseCurve(local,clock.curve) : local;
  return unit((clock.delay+time*clock.duration)/duration(totalDuration));
}
