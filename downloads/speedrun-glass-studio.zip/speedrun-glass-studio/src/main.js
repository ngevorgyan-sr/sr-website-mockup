// Generated from the website controller by scripts/package-studio.mjs.
import './page.css';
import './media.js';
import {mountGlassEditor} from './studio/editor.js';
import {validateSettings} from './glass/settings.js';
import defaults from './glass/defaults.json';
import {createQuoteGPU} from './glass/quote-gpu.js';
import './glass/glass.css';
import './glass/integration.css';
import finalSettings from './glass/final.json';
import { createGlassSurface } from './glass/engine.js';
import { createHoverMotion, hoverMotionDuration } from './glass/hover-motion.js';
import { animationDuration } from './glass/motion.js';
import { entryOrigin, quoteArrival } from './glass/triggers.js';

const surfaces=[];
// The fixed navigation CTA keeps its footprint while its glass still ripples.
const buttonHoverSettings=(element,config)=>element.classList.contains('header-apply')?{...config,lift:0,hoverScale:1}:config;
let settings=structuredClone(finalSettings);
let quoteManual=false;
let quoteReleased=false;
let queueQuoteArrival=()=>{};
let stopStudioPreview=()=>{};
let checkStudioVisibility=()=>{};
const buttons=[...document.querySelectorAll('.button,.question-button,.send-button')];
for(const element of buttons){
  const clip=document.createElement('span');clip.className='sr-button-clip';
  const visual=document.createElement('span');visual.className='sr-button-visual';
  const hitArea=document.createElement('span');hitArea.className='sr-button-hit-area';hitArea.setAttribute('aria-hidden','true');
  const content=document.createElement('span');
  content.className='sr-button-content';content.style.borderRadius='inherit';
  element.style.padding='0';element.style.background='none';
  for(const child of [...element.childNodes]){
    if(child.nodeType===1&&child.classList.contains('glass-button-edge'))continue;
    content.append(child);
  }
  clip.append(content);visual.append(clip);element.prepend(visual);element.append(hitArea);
  const surface=createGlassSurface(element,{kind:'button',content:visual,settings:settings.button});
  // Clip the material first, then deform the complete object, including its light and frame.
  clip.append(element.querySelector(':scope > .sr-glass-fx'));
  const hover=createHoverMotion(element,buttonHoverSettings(element,settings.button),{onFrame:()=>surface.refreshMaterial()});
  surfaces.push({kind:'button',element,surface,hover});
  const enabled=()=>!element.matches(':disabled,[aria-disabled="true"]');
  const enter=event=>{
    if(!enabled()||event.pointerType==='touch')return;
    stopStudioPreview('button');
    const config=settings.button;
    const origin=config.hoverOrigin==='entry'
      ?entryOrigin(element.getBoundingClientRect(),event.clientX,event.clientY,config.origin):config.origin;
    element.classList.add('sr-glass-hovered');
    hover.enter();
    surface.play({...origin,fromWarmup:false});
  };
  element.addEventListener('pointerenter',enter);
  const leave=()=>{
    stopStudioPreview('button',element);
    element.classList.remove('sr-glass-hovered');hover.leave();
  };
  element.addEventListener('pointerleave',leave);
  element.addEventListener('blur',leave);
  element.addEventListener('focus',()=>{if(element.matches(':focus-visible')&&enabled())enter({});});
  element.addEventListener('click',event=>{
    if(!enabled())return;
    if(stopStudioPreview('button')&&element.matches(':hover,:focus-visible')){
      element.classList.add('sr-glass-hovered');hover.enter();
    }
    const rect=element.getBoundingClientRect();
    const origin=event.detail&&settings.button.clickOrigin==='pointer'
      ?{x:(event.clientX-rect.left)/rect.width,y:(event.clientY-rect.top)/rect.height}:settings.button.origin;
    surface.play({...origin,fromWarmup:false});
  },true);
}
const quote=document.querySelector('#belief');
if(quote){
  const content=document.createElement('div');content.className='sr-quote-content';
  while(quote.firstChild)content.append(quote.firstChild);
  quote.append(content);
  content.querySelectorAll('.reveal').forEach(el=>{el.classList.remove('reveal');el.classList.add('is-visible');});
  // Chromium already accelerates the native SVG effect. Safari uses the same
  // authored motion with an explicit GPU renderer for this owned quote only.
  const safari=/safari/i.test(navigator.userAgent)&&!/chrome|chromium|android/i.test(navigator.userAgent);
  const renderer=safari?createQuoteGPU(content):null;
  const surface=createGlassSurface(quote,{kind:'quote',content,settings:settings.quote,renderer});
  surfaces.push({kind:'quote',element:quote,surface});
  let visible=false,frame=0;
  const updateArrival=()=>{
    frame=0;
    if(!visible||quoteManual||quoteReleased||document.hidden)return;
    const config=settings.quote;
    const arrival=quoteArrival(quote.getBoundingClientRect(),innerHeight,config.warmup);
    if(!arrival.visible){surface.reset();return;}
    if(arrival.release){
      quoteReleased=true;
      surface.play({...config.origin,fromWarmup:config.warmup.enabled});
    }else if(config.warmup.enabled){surface.warmup(arrival.progress,config.origin);}
    else surface.reset();
  };
  queueQuoteArrival=()=>{if(!frame&&visible&&!quoteManual&&!quoteReleased)frame=requestAnimationFrame(updateArrival);};
  const stopArrival=()=>{if(frame)cancelAnimationFrame(frame);frame=0;};
  new IntersectionObserver(entries=>{
    const entry=entries[0];visible=entry.isIntersecting;
    if(visible){window.addEventListener('scroll',queueQuoteArrival,{passive:true});queueQuoteArrival();}
    else{
      window.removeEventListener('scroll',queueQuoteArrival);stopArrival();stopStudioPreview('quote');
      quoteReleased=false;quoteManual=false;surface.reset();
    }
  },{threshold:[0],rootMargin:'-64px 0px 0px 0px'}).observe(quote);
  window.addEventListener('resize',queueQuoteArrival,{passive:true});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)stopArrival();else queueQuoteArrival();});
  quote.addEventListener('click',event=>{
    if(getSelection()?.toString())return;
    quoteManual=false;quoteReleased=true;stopArrival();stopStudioPreview('quote');
    const rect=quote.getBoundingClientRect();
    const origin=settings.quote.clickOrigin==='pointer'
      ?{x:(event.clientX-rect.left)/rect.width,y:(event.clientY-rect.top)/rect.height}:settings.quote.origin;
    surface.play({...origin,fromWarmup:false,click:true});
  });
}
const visibility=new IntersectionObserver(entries=>{
  for(const entry of entries)if(!entry.isIntersecting){
    const target=surfaces.find(s=>s.element===entry.target);
    target?.surface.reset();target?.hover?.reset();target?.element.classList.remove('sr-glass-hovered');
  }
  checkStudioVisibility();
});
surfaces.forEach(({element})=>visibility.observe(element));
document.addEventListener('visibilitychange',()=>{
  if(document.hidden)surfaces.forEach(({element})=>element.classList.remove('sr-glass-hovered'));
});

// This standalone playground always mounts the editor; the website does not.
{
  let presetURL;
  window.addEventListener('pagehide',()=>{if(presetURL)URL.revokeObjectURL(presetURL);});
  const listeners=new Set();
  let previewFrame=0,previewPhase='release',previewKind=null,previewTargets=[];
  const stopPreview=()=>{if(previewFrame)cancelAnimationFrame(previewFrame);previewFrame=0;};
  const select=kind=>surfaces.filter(s=>s.kind===kind);
  const example=kind=>{
    if(kind==='quote')return select(kind);
    const visible=select(kind).filter(({element})=>{const r=element.getBoundingClientRect();return r.top>64&&r.bottom<innerHeight&&r.width>0;});
    return visible.length?visible:[select(kind).find(s=>s.element.classList.contains('hero-apply'))||select(kind)[0]];
  };
  const prepare=kind=>{
    const targets=example(kind),element=targets[0]?.element;
    if(kind==='quote')quoteManual=true;
    if(element){const r=element.getBoundingClientRect();if(r.top<64||r.bottom>innerHeight)element.scrollIntoView({block:'center',behavior:'instant'});}
    previewTargets=targets;
    return targets;
  };
  const resetTargets=kind=>select(kind).forEach(s=>{s.surface.reset();s.hover?.reset();s.element.classList.remove('sr-glass-hovered');});
  const editor=mountGlassEditor({
    getSettings:()=>structuredClone(settings),getDefaults:()=>structuredClone(defaults),
    showVideoButton(){
      stopPreview();previewKind=null;resetTargets('button');
      window.scrollTo({top:0,behavior:'instant'});
      const hero=select('button').find(s=>s.element.classList.contains('hero-apply'));
      if(hero){const r=hero.element.getBoundingClientRect();if(r.top<64||r.bottom>innerHeight)hero.element.scrollIntoView({block:'center',behavior:'instant'});}
    },
    updateSettings(next){
      settings=validateSettings(next);surfaces.forEach(s=>{s.surface.update(settings[s.kind]);s.hover?.update(buttonHoverSettings(s.element,settings[s.kind]));});
      listeners.forEach(fn=>fn(structuredClone(settings)));queueQuoteArrival();
    },
    play(kind,phase='release'){
      stopPreview();previewKind=kind;
      const targets=prepare(kind),origin=settings[kind].origin;
      if(kind==='button'){
        const leaving=phase==='leave';previewPhase=phase;
        targets.forEach(s=>{
          s.element.classList.toggle('sr-glass-hovered',!leaving);
          s.hover.play(leaving?'leave':'enter');
          if(leaving)s.surface.reset();else s.surface.play(origin);
        });
        return;
      }
      if(phase==='warmup'&&kind==='quote'){
        targets.forEach(s=>s.surface.reset());previewPhase='warmup';
        const began=performance.now(),duration=settings.quote.warmup.previewDuration;
        const tick=time=>{
          previewFrame=0;if(document.hidden)return;
          const progress=Math.min(1,(time-began)/duration);
          targets.forEach(s=>s.surface.warmup(progress,origin));
          if(progress<1)previewFrame=requestAnimationFrame(tick);
        };
        previewFrame=requestAnimationFrame(tick);
      }else{
        const fromWarmup=phase!=='click'&&settings.quote.warmup.enabled;previewPhase=phase;
        targets.forEach(s=>s.surface.play({...origin,fromWarmup,click:phase==='click'}));
      }
    },
    seek(kind,progress,phase='release'){
      stopPreview();previewKind=kind;const targets=prepare(kind);previewPhase=phase;
      if(kind==='button'){
        const leaving=phase==='leave',hoverPhase=leaving?'leave':'enter';
        const hoverDuration=hoverMotionDuration(settings.button,hoverPhase),opticalDuration=animationDuration(settings.button);
        const elapsed=progress*(leaving?hoverDuration:Math.max(hoverDuration,opticalDuration));
        targets.forEach(s=>{
          s.element.classList.toggle('sr-glass-hovered',leaving?progress<1:progress>0);
          s.hover.seek(Math.min(1,elapsed/hoverDuration),hoverPhase);
          if(leaving)s.surface.reset();else s.surface.seek(Math.min(1,elapsed/opticalDuration),settings.button.origin);
        });
      }else targets.forEach(s=>phase==='warmup'?s.surface.warmup(progress,settings.quote.origin):s.surface.seek(progress,settings.quote.origin,{fromWarmup:phase!=='click'&&settings.quote.warmup.enabled,click:phase==='click'}));
    },
    reset(kind){stopPreview();previewKind=null;previewPhase='release';resetTargets(kind);if(kind==='quote')quoteManual=true;},
    subscribe(fn){listeners.add(fn);return()=>listeners.delete(fn);},
    async save(){
      if(presetURL)URL.revokeObjectURL(presetURL);
      presetURL=URL.createObjectURL(new Blob([JSON.stringify(settings,null,2)+'\n'],{type:'application/json'}));
      const download=document.createElement('a');download.href=presetURL;download.download='speedrun-glass-preset.json';
      document.body.append(download);download.click();download.remove();
      return {saved:true};
    }
  },{
    saveLabel:'Download preset',savingLabel:'Preparing…',
    saveTitle:'Download the current settings as JSON',
    savedMessage:'Preset downloaded.',pendingMessage:'Preset downloaded. Newer changes still need exporting.',
    footerNote:'Changes stay in this page. Download a preset to keep them.',badge:'PLAY',
  });
  stopStudioPreview=(kind,preserveHoverElement=null)=>{
    if(!previewKind||kind!==previewKind)return;
    stopPreview();previewKind=null;editor.cancelPlayback();
    select(kind).forEach(s=>{
      s.surface.reset();
      if(s.element!==preserveHoverElement){s.hover?.reset();s.element.classList.remove('sr-glass-hovered');}
    });
    return true;
  };
  checkStudioVisibility=()=>{
    if(previewKind==='button'&&previewTargets.every(({element})=>{
      const r=element.getBoundingClientRect();return r.bottom<=0||r.top>=innerHeight||!r.width;
    }))stopStudioPreview('button');
  };
  document.addEventListener('visibilitychange',()=>{if(document.hidden)stopStudioPreview(previewKind);});
}
