import {paintQuote} from './quote-painter.js';

const VERTEX = `attribute vec2 position;varying vec2 uv;
void main(){uv=vec2(position.x*.5+.5,.5-position.y*.5);gl_Position=vec4(position,0.,1.);}`;
const FRAGMENT = `precision highp float;varying vec2 uv;
uniform sampler2D source,map;uniform vec2 size,mapOrigin;uniform float diameter,strength,dispersion;
vec4 pixel(vec2 p){
 // This owned source has an opaque flat fill. Extend that fill at its edge
 // so split color samples cannot expose a colored seam at the fixed frame.
 return texture2D(source,p);
}
void main(){
 vec2 m=(uv*size-mapOrigin)/diameter+.5, d=vec2(0.);
 if(all(greaterThanEqual(m,vec2(0.)))&&all(lessThanEqual(m,vec2(1.))))
  d=texture2D(map,m).rg-vec2(128./255.);
 vec4 base=pixel(uv+d*(strength*2.)/size);
 float r=pixel(uv+d*((strength+dispersion*.5)*2.)/size).r;
 float b=pixel(uv+d*((strength-dispersion*.5)*2.)/size).b;
 gl_FragColor=vec4(r,base.g,b,base.a);
}`;

function createDevice(canvas) {
  const gl=canvas.getContext('webgl',{alpha:true,premultipliedAlpha:false,antialias:false,preserveDrawingBuffer:true});
  if(!gl || gl.isContextLost()) return null;
  const shaders=[], textures=[]; let program,buffer;
  const dispose=()=>{
    if(gl.isContextLost())return;
    for(const shader of shaders)gl.deleteShader(shader);
    for(const texture of textures)gl.deleteTexture(texture);
    if(buffer)gl.deleteBuffer(buffer);if(program)gl.deleteProgram(program);
  };
  try {
    const compile=(type,text)=>{
      const shader=gl.createShader(type);shaders.push(shader);gl.shaderSource(shader,text);gl.compileShader(shader);
      if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS))throw Error('Quote shader unavailable');
      return shader;
    };
    const vertex=compile(gl.VERTEX_SHADER,VERTEX),fragment=compile(gl.FRAGMENT_SHADER,FRAGMENT);
    program=gl.createProgram();gl.attachShader(program,vertex);gl.attachShader(program,fragment);
    gl.bindAttribLocation(program,0,'position');gl.linkProgram(program);
    if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error('Quote shader unavailable');
    gl.useProgram(program);
    buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);
    gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,2,gl.FLOAT,false,0,0);
    const uniforms=Object.fromEntries(['source','map','size','mapOrigin','diameter','strength','dispersion'].map(name=>[name,gl.getUniformLocation(program,name)]));
    for(let i=0;i<2;i++) {
      gl.activeTexture(gl.TEXTURE0+i);const texture=gl.createTexture();textures.push(texture);gl.bindTexture(gl.TEXTURE_2D,texture);
      for(const p of [gl.TEXTURE_MIN_FILTER,gl.TEXTURE_MAG_FILTER])gl.texParameteri(gl.TEXTURE_2D,p,gl.LINEAR);
      for(const p of [gl.TEXTURE_WRAP_S,gl.TEXTURE_WRAP_T])gl.texParameteri(gl.TEXTURE_2D,p,gl.CLAMP_TO_EDGE);
    }
    gl.uniform1i(uniforms.source,0);gl.uniform1i(uniforms.map,1);
    return {gl,uniforms,textures,dispose,maxSize:gl.getParameter(gl.MAX_TEXTURE_SIZE)};
  } catch { dispose(); return null; }
}

/** Optional accelerated renderer for this owned quote layout. Native HTML remains
 * selectable and accessible. No DOM screenshots, readbacks, reduced resolution,
 * per-frame text painting, or independent animation loop are used here. */
export function createQuoteGPU(content) {
  if(typeof ResizeObserver!=='function'||typeof IntersectionObserver!=='function')return null;
  if(!content.querySelector('blockquote') || !content.querySelector('.quote-attribution'))return null;
  const canvas=document.createElement('canvas'), source=document.createElement('canvas');
  canvas.className='sr-quote-gpu';canvas.setAttribute('aria-hidden','true');canvas.hidden=true;
  canvas.style.cssText='position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:2';
  const originalIsolation=content.style.isolation;content.style.isolation='isolate';
  content.append(canvas);
  let device=null,ready=false,destroyed=false,failed=false,near=false,lastMap=null,size=null;
  let revision=0,queued=false,refreshFrame=0,redraw=()=>{},signature='',selection=false;
  let sourceUploads=0,draws=0,losses=0,restores=0,lastError='';
  const accessibility=window.matchMedia('(prefers-reduced-motion: reduce), (forced-colors: active)');
  const density=()=>window.devicePixelRatio||1;
  const hide=()=>{canvas.hidden=true;};
  const refresh=()=>{
    if(destroyed)return;
    revision++;ready=false;hide();
    if(!queued && (near||device)) {
      queued=true;refreshFrame=requestAnimationFrame(()=>{refreshFrame=0;queued=false;prepare();});
    }
    redraw();
  };
  async function prepare() {
    if(accessibility.matches)return;
    const token=revision;
    try {
      await document.fonts.ready;
      await Promise.all([...content.querySelectorAll('.quote-avatars img')].map(img=>img.decode()));
      if(destroyed||token!==revision||failed||accessibility.matches)return;
      device ||= createDevice(canvas);
      if(!device){failed=true;return;}
      const width=content.offsetWidth,height=content.offsetHeight,dpr=density();
      // Retain native pixel density. Oversized canvases use the original SVG,
      // rather than silently lowering the quality to meet a memory budget.
      if(!width||!height || width*dpr>device.maxSize || height*dpr>device.maxSize || width*height*dpr*dpr>16_000_000)return;
      const transform=content.style.transform;content.style.transform='none';
      try{size=paintQuote(content,source,dpr);}finally{content.style.transform=transform;}
      canvas.width=source.width;canvas.height=source.height;
      const {gl,textures,uniforms}=device;
      gl.viewport(0,0,canvas.width,canvas.height);
      gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,textures[0]);
      gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,source);
      gl.uniform2f(uniforms.size,size.width,size.height);
      if(gl.getError()!==gl.NO_ERROR)throw Error('Quote texture unavailable');
      sourceUploads++;signature=`${width}:${height}:${dpr}`;ready=true;redraw();
    } catch (error) {
      if(destroyed||token!==revision)return;
      lastError=error.message;ready=false;hide();
    }
  }
  const resized=()=>{
    if(signature!==`${content.offsetWidth}:${content.offsetHeight}:${density()}`)refresh();
  };
  const resizeObserver=new ResizeObserver(resized);resizeObserver.observe(content);
  const visibilityObserver=new IntersectionObserver(entries=>{
    near=entries[0].isIntersecting;
    if(near&&!ready&&!failed)refresh();
  },{rootMargin:'200px'});visibilityObserver.observe(content);
  const themeObserver=new MutationObserver(refresh);
  themeObserver.observe(document.documentElement,{attributes:true,attributeFilter:['data-theme']});
  const textObserver=new MutationObserver(refresh);
  // Watch the owned semantic text/images, never animated style attributes.
  textObserver.observe(content,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['src','srcset']});
  const selectionChanged=()=>{
    const value=document.getSelection();
    const next=Boolean(value&&!value.isCollapsed&&(content.contains(value.anchorNode)||content.contains(value.focusNode)));
    if(next!==selection){selection=next;if(next)hide();redraw();}
  };
  const contextLost=event=>{losses++;event.preventDefault();ready=false;lastMap=null;hide();redraw();};
  // The browser already invalidated old handles. Deleting them after restore
  // raises INVALID_OPERATION in Safari and can poison the next upload check.
  const contextRestored=()=>{restores++;device=null;failed=false;lastMap=null;refresh();};
  canvas.addEventListener('webglcontextlost',contextLost);canvas.addEventListener('webglcontextrestored',contextRestored);
  document.addEventListener('selectionchange',selectionChanged);
  accessibility.addEventListener('change',refresh);
  document.fonts.addEventListener('loadingdone',refresh);
  content.addEventListener('load',refresh,true);
  window.addEventListener('resize',resized,{passive:true});
  return {
    setRedraw(callback){redraw=callback;},
    render(state,strength,dispersion,map){
      if(!ready||selection||accessibility.matches||!device||device.gl.isContextLost()){hide();return false;}
      const {gl,textures,uniforms}=device;
      if(map!==lastMap){
        gl.activeTexture(gl.TEXTURE1);gl.bindTexture(gl.TEXTURE_2D,textures[1]);
        gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,map);
        if(gl.getError()!==gl.NO_ERROR){ready=false;hide();return false;}lastMap=map;
      }
      gl.uniform2f(uniforms.mapOrigin,state.x,state.y);gl.uniform1f(uniforms.diameter,state.width);
      gl.uniform1f(uniforms.strength,strength);gl.uniform1f(uniforms.dispersion,dispersion);
      gl.drawArrays(gl.TRIANGLE_STRIP,0,4);draws++;canvas.hidden=false;return true;
    },
    hide,refresh,
    diagnostics(){return {ready,sourceUploads,draws,losses,restores,lastError,lost:device?.gl.isContextLost(),width:canvas.width,height:canvas.height,selected:selection,hidden:canvas.hidden};},
    destroy(){
      if(destroyed)return;destroyed=true;revision++;cancelAnimationFrame(refreshFrame);
      resizeObserver.disconnect();visibilityObserver.disconnect();themeObserver.disconnect();textObserver.disconnect();
      window.removeEventListener('resize',resized);document.fonts.removeEventListener('loadingdone',refresh);
      document.removeEventListener('selectionchange',selectionChanged);
      accessibility.removeEventListener('change',refresh);
      content.removeEventListener('load',refresh,true);
      canvas.removeEventListener('webglcontextlost',contextLost);canvas.removeEventListener('webglcontextrestored',contextRestored);
      device?.dispose();device=null;canvas.remove();content.style.isolation=originalIsolation;canvas.width=canvas.height=source.width=source.height=1;redraw=()=>{};
    }
  };
}
