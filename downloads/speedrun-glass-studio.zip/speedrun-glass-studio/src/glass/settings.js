/** Glass preset schema, shared by the renderer and development-only editor. */
const legacyLimits = {
  duration: [200, 4000], strength: [0, 64], width: [.08, .8],
  dispersion: [0, 8], glow: [0, 1], sheen: [0, 1], stretch: [0, .08],
  lift: [0, 12], hoverScale: [1, 1.12],
};
const rippleLimits = {
  radius: [.2, 1.6], highlightSize: [.05, 1], coreGlow: [0, 1], coreDuration: [80, 4000], ringSoftness: [.05, 1],
  stretchDuration: [200, 4000], stretchDelay: [0, 2000],
};
const warmupLimits = {
  start: [0, .6], release: [.05, 1], previewDuration: [200, 3000], releaseFade: [0, 2000],
  strength: [0, 32], width: [.08, .8], glow: [0, 1], sheen: [0, 1], coreGlow: [0, 1], stretch: [0, .08], stretchY: [0, .16],
};
const ENVELOPE = [{t:0,value:0},{t:.14,value:.72},{t:.28,value:1},{t:.65,value:.65},{t:1,value:0}];
const WARMUP_CORE_ENVELOPE = [{t:0,value:1},{t:.25,value:1},{t:.5,value:1},{t:.75,value:1},{t:1,value:1}];
const QUOTE_WARMUP_CORE_ENVELOPE = [{t:0,value:1},{t:.25,value:1},{t:.5,value:1},{t:.75,value:.65},{t:1,value:.25}];
const CORE_ENVELOPE = [{t:0,value:0},{t:.1,value:1},{t:.28,value:.65},{t:.6,value:.12},{t:1,value:0}];
const QUOTE_CORE_MOTION = {startScale:1.15,releaseScale:.55,endScale:1.6,contractStart:.45,contractCurve:[.42,0,.58,1],expandCurve:[.16,.65,.3,1]};
const TRAVEL = [.25, .1, .35, 1];
const HOVER_CURVE = [.22, .61, .36, 1];
const HOVER_RESPONSE = [{t:0,value:0},{t:.25,value:.25},{t:.5,value:.5},{t:.75,value:.75},{t:1,value:1}];
const SPECTRUM = [
  {position:0,color:'#ff7664'},
  {position:.25,color:'#ffd26e'},
  {position:.5,color:'#70e7e3'},
  {position:.75,color:'#7495ff'},
  {position:1,color:'#d38aff'},
];
const SPECTRUM_SHIFT = [{t:0,value:0},{t:.5,value:80},{t:1,value:160}];
const LEGACY_DEFAULTS = {
  button: {duration:700,strength:5,width:.28,dispersion:.65,glow:.18,sheen:.2,stretch:.012,lift:2,hoverScale:1.025,travel:TRAVEL,envelope:ENVELOPE},
  quote: {duration:1150,strength:14,width:.26,dispersion:1.2,glow:.14,sheen:.16,stretch:.005,lift:0,hoverScale:1,travel:TRAVEL,envelope:ENVELOPE,coreDuration:280,coreEnvelope:CORE_ENVELOPE,coreMotion:QUOTE_CORE_MOTION,warmup:{release:.58,previewDuration:650,releaseFade:140,coreEnvelope:QUOTE_WARMUP_CORE_ENVELOPE,stretchY:.02}},
};
const own = (object, key) => Object.prototype.hasOwnProperty.call(object, key);
const optional = (object, key, fallback) => own(object, key) ? object[key] : fallback;
const isRecord = value => value !== null && typeof value === 'object' && !Array.isArray(value);

function number(value, [min, max], label) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max)
    throw new Error(`${label} must be between ${min} and ${max}.`);
  return value;
}
function choice(value, choices, label) {
  if (!choices.includes(value)) throw new Error(`${label} must be ${choices.join(' or ')}.`);
  return value;
}
function curve(value, label) {
  if (!Array.isArray(value) || value.length !== 4)
    throw new Error(`${label} needs four values between 0 and 1.`);
  return value.map(point => number(point, [0, 1], label));
}
function keyframes(value, {count, min, max, zeroEnds = false, label, description = count === 5 ? 'intensity' : 'color'}) {
  if (!Array.isArray(value) || value.length !== count)
    throw new Error(`${label}: provide exactly ${count === 5 ? 'five' : 'three'} ${description} keyframes.`);
  let previous = -1;
  const result = value.map(point => {
    if (!isRecord(point)) throw new Error(`${label}: each keyframe needs a time and a value.`);
    const t = number(point.t, [0, 1], `${label}: keyframe time`);
    const amplitude = number(point.value, [min, max], `${label}: keyframe value`);
    if (t <= previous) throw new Error(`${label}: keyframe times must increase from 0 to 1.`);
    previous = t;
    const frame = {t, value: amplitude};
    if (own(point,'ease')) frame.ease = curve(point.ease,`${label}: outgoing keyframe easing`);
    return frame;
  });
  if (result[0].t !== 0 || result.at(-1).t !== 1)
    throw new Error(`${label}: first and last keyframe times must be 0 and 1.`);
  if (zeroEnds && (result[0].value !== 0 || result.at(-1).value !== 0))
    throw new Error(`${label}: first and last keyframes must be (0,0) and (1,0).`);
  return result;
}
function hoverResponse(value, label) {
  const result = keyframes(value, {count:5,min:0,max:2,label,description:'response'});
  if (result[0].value !== 0 || result.at(-1).value !== 1)
    throw new Error(`${label}: first and last response keyframes must be (0,0) and (1,1).`);
  return result;
}
function hoverMotion(value, name, label) {
  if (!isRecord(value)) throw new Error(`${label} must be an object.`);
  const duration = name === 'liftMotion' ? 360 : 420;
  const returnDuration = name === 'liftMotion' ? 240 : 280;
  return {
    duration: number(optional(value,'duration',duration),[80,3000],`${label}: duration`),
    delay: number(optional(value,'delay',0),[0,2000],`${label}: delay`),
    curve: curve(optional(value,'curve',HOVER_CURVE),`${label}: curve`),
    keyframes: hoverResponse(optional(value,'keyframes',HOVER_RESPONSE),`${label}: response`),
    returnDuration: number(optional(value,'returnDuration',returnDuration),[80,3000],`${label}: return duration`),
    returnCurve: curve(optional(value,'returnCurve',HOVER_CURVE),`${label}: return curve`),
    returnKeyframes: hoverResponse(optional(value,'returnKeyframes',HOVER_RESPONSE),`${label}: return response`),
  };
}
function coreMotion(value, label) {
  if (!isRecord(value)) throw new Error(`${label} must be an object.`);
  return {
    startScale: number(optional(value,'startScale',1),[.1,3],`${label}: start scale`),
    releaseScale: number(optional(value,'releaseScale',1),[.1,3],`${label}: release scale`),
    endScale: number(optional(value,'endScale',1),[.1,3],`${label}: end scale`),
    contractStart: number(optional(value,'contractStart',0),[0,.95],`${label}: contraction start`),
    contractCurve: curve(optional(value,'contractCurve',[0,0,1,1]),`${label}: contraction curve`),
    expandCurve: curve(optional(value,'expandCurve',[0,0,1,1]),`${label}: expansion curve`),
  };
}
function buttonSurface(value) {
  if (!isRecord(value)) throw new Error('button: surface must be an object.');
  const tintColor = optional(value,'tintColor',null);
  if (tintColor !== null && (typeof tintColor !== 'string' || !/^#[0-9a-fA-F]{6}$/.test(tintColor)))
    throw new Error('button: surface tint color must be null or a six-digit hex color, such as #ff7664.');
  const cornerRadius = optional(value,'cornerRadius',null);
  if (cornerRadius !== null) number(cornerRadius,[0,100],'button: surface corner radius');
  const tintOpacity = number(optional(value,'tintOpacity',1),[0,2],'button: surface tint opacity');
  const shadowOpacity = number(optional(value,'shadowOpacity',.16),[0,1],'button: surface shadow opacity');
  const shadowSpread = number(optional(value,'shadowSpread',8),[0,32],'button: surface shadow spread');
  return {
    tintColor,
    cornerRadius,
    refraction: number(optional(value,'refraction',.35),[0,2],'button: surface refraction'),
    chromAberration: number(optional(value,'chromAberration',.03),[0,1],'button: surface chromatic aberration'),
    edgeHighlight: number(optional(value,'edgeHighlight',0),[0,2],'button: surface edge highlight'),
    specular: number(optional(value,'specular',.08),[0,2],'button: surface specular'),
    specularSharpness: number(optional(value,'specularSharpness',.5),[0,1],'button: surface specular sharpness'),
    fresnel: number(optional(value,'fresnel',.15),[0,2],'button: surface Fresnel'),
    distortion: number(optional(value,'distortion',0),[0,1],'button: surface distortion'),
    zRadius: number(optional(value,'zRadius',18),[1,100],'button: surface Z radius'),
    opacity: number(optional(value,'opacity',1),[0,1],'button: surface opacity'),
    brightness: number(optional(value,'brightness',1),[.25,2],'button: surface brightness'),
    shadowOpacity,
    shadowSpread,
    shadowCenterOpacity: number(optional(value,'shadowCenterOpacity',shadowOpacity*18/10),[0,2],'button: surface shadow center opacity'),
    shadowCenterSpread: number(optional(value,'shadowCenterSpread',shadowSpread*.5),[0,32],'button: surface shadow center spread'),
    videoShadowOpacity: number(optional(value,'videoShadowOpacity',shadowOpacity),[0,1],'button: surface video shadow opacity'),
    videoShadowSpread: number(optional(value,'videoShadowSpread',shadowSpread),[0,32],'button: surface video shadow spread'),
    bevelMode: choice(optional(value,'bevelMode','pill'),['pill','dome'],'button: surface bevel mode'),
    tintOpacity,
    videoTintOpacity: number(optional(value,'videoTintOpacity',tintOpacity),[0,2],'button: surface video tint opacity'),
    blur: number(optional(value,'blur',2),[0,24],'button: surface blur'),
    saturation: number(optional(value,'saturation',1),[0,3],'button: surface saturation'),
    shine: number(optional(value,'shine',1),[0,2],'button: surface shine'),
    edge: number(optional(value,'edge',1),[0,2],'button: surface edge'),
  };
}
function spectrum(value, label) {
  if (!Array.isArray(value) || value.length !== 5)
    throw new Error(`${label}: provide exactly five spectrum stops.`);
  let previous = -1;
  const result = value.map(stop => {
    if (!isRecord(stop)) throw new Error(`${label}: each spectrum stop needs a position and a color.`);
    const position = number(stop.position, [0, 1], `${label}: spectrum position`);
    if (position <= previous) throw new Error(`${label}: spectrum positions must increase from 0 to 1.`);
    if (typeof stop.color !== 'string' || !/^#[0-9a-fA-F]{6}$/.test(stop.color))
      throw new Error(`${label}: spectrum colors must use six-digit hex colors, such as #ff7664.`);
    previous = position;
    return {position, color: stop.color};
  });
  if (result[0].position !== 0 || result.at(-1).position !== 1)
    throw new Error(`${label}: first and last spectrum positions must be 0 and 1.`);
  return result;
}

/** Validates one surface, filling new fields for presets exported before the ripple editor. */
export function validateGlassSettings(value, kind = 'button') {
  if (!['button', 'quote'].includes(kind)) throw new Error('Glass surface must be button or quote.');
  if (!isRecord(value)) throw new Error(`Missing ${kind} settings.`);
  const result = {};
  for (const [name, range] of Object.entries(legacyLimits)) result[name] = number(value[name], range, `${kind}: ${name}`);
  result.travel = curve(value.travel, `${kind}: travel`);
  result.envelope = keyframes(value.envelope, {count:5,min:0,max:2,zeroEnds:true,label:`${kind}: intensity`});

  const additions = {
    radius: kind === 'button' ? 1 : 1.05,
    highlightSize: kind === 'button' ? .35 : .32,
    coreGlow: kind === 'button' ? .4 : .5, coreDuration: result.duration, ringSoftness: .65,
    stretchDuration: result.duration, stretchDelay: 0,
  };
  for (const [name, range] of Object.entries(rippleLimits))
    result[name] = number(optional(value, name, additions[name]), range, `${kind}: ${name}`);
  if (kind === 'quote')
    result.clickHighlightSize = number(optional(value,'clickHighlightSize',Math.min(result.highlightSize,.12)),[.05,1],'quote: click highlight size');
  const origin = optional(value, 'origin', kind === 'button' ? {x:0,y:.5} : {x:.5,y:0});
  if (!isRecord(origin)) throw new Error(`${kind}: origin needs x and y coordinates.`);
  result.origin = {x:number(origin.x,[0,1],`${kind}: origin x`),y:number(origin.y,[0,1],`${kind}: origin y`)};
  result.hoverOrigin = choice(optional(value,'hoverOrigin',kind === 'button' ? 'entry' : 'fixed'), ['entry','fixed'], `${kind}: hover origin`);
  result.clickOrigin = choice(optional(value,'clickOrigin','pointer'), ['pointer','fixed'], `${kind}: click origin`);
  result.spectrum = spectrum(optional(value,'spectrum',SPECTRUM), `${kind}: spectrum`);
  result.spectrumShift = keyframes(optional(value,'spectrumShift',SPECTRUM_SHIFT), {count:3,min:-360,max:360,label:`${kind}: spectrum shift`});
  result.coreEnvelope = keyframes(optional(value,'coreEnvelope',result.envelope), {count:5,min:0,max:2,zeroEnds:true,label:`${kind}: origin glow intensity`});
  result.coreMotion = coreMotion(optional(value,'coreMotion',{}),`${kind}: origin motion`);
  result.stretchTravel = curve(optional(value,'stretchTravel',result.travel), `${kind}: stretch travel`);
  result.stretchEnvelope = keyframes(optional(value,'stretchEnvelope',result.envelope), {count:5,min:0,max:2,zeroEnds:true,label:`${kind}: stretch intensity`});

  for (const name of ['liftMotion','scaleMotion'])
    result[name] = hoverMotion(optional(value,name,{}),name,`${kind}: ${name}`);

  const warmup = optional(value,'warmup',{});
  if (!isRecord(warmup)) throw new Error(`${kind}: warmup must be an object.`);
  const warmupDefaults = {
    enabled:kind === 'quote',start:.08,release:.78,previewDuration:1000,releaseFade:Math.min(2000,result.duration*.3),
    strength:3.5,width:.45,glow:.075,sheen:.2,coreGlow:.28,stretch:.003,stretchY:0,curve:[.42,0,.58,1],
  };
  const enabled = optional(warmup,'enabled',warmupDefaults.enabled);
  if (typeof enabled !== 'boolean') throw new Error(`${kind}: warmup enabled must be true or false.`);
  result.warmup = {enabled};
  for (const [name, range] of Object.entries(warmupLimits))
    result.warmup[name] = number(optional(warmup,name,warmupDefaults[name]),range,`${kind}: warmup ${name}`);
  if (result.warmup.release <= result.warmup.start)
    throw new Error(`${kind}: warmup release must be later than warmup start.`);
  result.warmup.curve = curve(optional(warmup,'curve',warmupDefaults.curve),`${kind}: warmup curve`);
  result.warmup.coreEnvelope = keyframes(optional(warmup,'coreEnvelope',WARMUP_CORE_ENVELOPE),{count:5,min:0,max:2,label:`${kind}: warmup origin glow intensity`});
  if (kind === 'button') result.surface = buttonSurface(optional(value,'surface',{}));
  return result;
}

export function validateSettings(input) {
  if (!isRecord(input)) throw new Error('Choose a glass settings JSON file.');
  return {
    button: validateGlassSettings(input.button, 'button'),
    quote: validateGlassSettings(input.quote, 'quote'),
  };
}

/** Complete defaults with distinct arrays/objects for the two surfaces. */
export const GLASS_DEFAULTS = validateSettings(LEGACY_DEFAULTS);
