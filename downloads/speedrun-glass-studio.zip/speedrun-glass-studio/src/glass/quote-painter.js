/** A renderer for the site's owned quote, not a screenshot/capture of arbitrary DOM. */
export function paintQuote(content, canvas, density) {
  const bounds = content.getBoundingClientRect();
  const width = content.offsetWidth, height = content.offsetHeight;
  canvas.width = Math.ceil(width * density); canvas.height = Math.ceil(height * density);
  const ctx = canvas.getContext('2d');
  ctx.scale(density, density);
  const css = getComputedStyle(content);
  ctx.fillStyle = css.backgroundColor; ctx.fillRect(0, 0, width, height);
  const background = content.querySelector('.quote-surface');
  if (background) {
    ctx.fillStyle = getComputedStyle(background).backgroundColor; ctx.fillRect(0, 0, width, height);
    if (getComputedStyle(background, '::after').content !== 'none') {
      for (const [key, from, to] of [['--surface', height, height * .75997], ['--soft', 0, height * .24003]]) {
        const color = css.getPropertyValue(key).trim();
        const g = ctx.createLinearGradient(0, from, 0, to); g.addColorStop(0, color); g.addColorStop(1, 'transparent');
        ctx.fillStyle = g; ctx.fillRect(0, 0, width, height);
      }
    }
  }
  for (const element of content.querySelectorAll('blockquote, .quote-attribution p')) {
    const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      const style = getComputedStyle(node.parentElement);
      ctx.font = `${style.fontStyle} ${style.fontWeight} ${style.fontSize} ${style.fontFamily}`;
      ctx.letterSpacing = '0px'; ctx.fontKerning = 'none';
      ctx.fillStyle = style.color; ctx.textBaseline = 'alphabetic';
      const ascent = ctx.measureText('Mg').fontBoundingBoxAscent;
      if (!Number.isFinite(ascent)) throw Error('Quote font metrics unavailable');
      const range = document.createRange();
      for (let i = 0; i < node.length; i++) {
        range.setStart(node, i); range.setEnd(node, i + 1);
        const box = range.getBoundingClientRect();
        if (box.width > 0 && node.data[i].trim()) ctx.fillText(node.data[i], box.x - bounds.x, box.y - bounds.y + ascent);
      }
    }
  }
  for (const img of content.querySelectorAll('.quote-avatars img')) {
    if (!img.complete || !img.naturalWidth) throw Error('Quote avatar is not ready');
    const r = img.getBoundingClientRect(), x = r.x - bounds.x, y = r.y - bounds.y;
    const scale = Math.max(r.width / img.naturalWidth, r.height / img.naturalHeight);
    const sw = r.width / scale, sh = r.height / scale;
    ctx.save(); ctx.beginPath(); ctx.ellipse(x+r.width/2, y+r.height/2, r.width/2, r.height/2, 0, 0, Math.PI*2); ctx.clip();
    ctx.drawImage(img, (img.naturalWidth-sw)/2, 0, sw, sh, x, y, r.width, r.height); ctx.restore();
  }
  return {width, height};
}
