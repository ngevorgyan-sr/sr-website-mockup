import defaults from './defaults.json';
import { normalizeButtonMaterial } from './material-model.js';
import { createButtonMaterial } from './button-material.js';
import { buttonBleed, buttonFilterPadding } from './button-geometry.js';
import { clamp, normalizeEnvelope, waveFrame, warmupFrame, releaseAmounts, quoteClickLightOnset, originDiameter, originScaleAt, upwardStretchAt, animationDuration, radialDisplacement, rippleSigma, RIPPLE_CENTER } from './motion.js';

export const GLASS_DEFAULTS = defaults;
const NS = 'http://www.w3.org/2000/svg';
const surfaces = new Set(), active = new Map(), mapCache = new Map();
const materialSurfaces = new Set();
let raf = 0, sequence = 0, rootSVG, definitions;
let materialThemeObserver;

function watchMaterial(material) {
  if (typeof MutationObserver !== 'function') return ()=>{};
  materialSurfaces.add(material);
  if (!materialThemeObserver) {
    materialThemeObserver = new MutationObserver(()=>{
      // Read the unmodified theme once, then reapply tuning without compounding alpha.
      for (const item of materialSurfaces) item.restore();
      for (const item of materialSurfaces) item.capture();
      for (const item of materialSurfaces) item.apply();
    });
    materialThemeObserver.observe(document.documentElement,{attributes:true,attributeFilter:['data-theme']});
  }
  return ()=>{
    materialSurfaces.delete(material);
    if (!materialSurfaces.size) {materialThemeObserver.disconnect();materialThemeObserver=null;}
  };
}

function frame(time) {
  raf = 0;
  for (const [surface, tick] of [...active]) if (active.has(surface)) tick(time);
  if (active.size) raf = requestAnimationFrame(frame);
}
function start(surface, tick) { active.set(surface, tick); if (!raf) raf = requestAnimationFrame(frame); }
function stop(surface) {
  active.delete(surface);
  if (!active.size && raf) { cancelAnimationFrame(raf); raf = 0; }
}
function onVisibility() { if (document.hidden) for (const surface of surfaces) surface.reset(); }
function svg(tag, attrs = {}) {
  const node = document.createElementNS(NS, tag);
  for (const [key, value] of Object.entries(attrs)) node.setAttribute(key, String(value));
  return node;
}
function ensureDefinitions() {
  if (rootSVG) return;
  rootSVG = svg('svg', { width: 1, height: 1, 'aria-hidden': 'true', focusable: 'false' });
  rootSVG.style.cssText = 'position:absolute;left:0;top:0;width:1px;height:1px;overflow:hidden;opacity:0;pointer-events:none;';
  definitions = svg('defs'); rootSVG.append(definitions); document.body.append(rootSVG);
  document.addEventListener('visibilitychange', onVisibility);
}

/** Only generated at setup/settings changes; animation frames reuse these pixels. */
function rippleMap(bandWidth) {
  const key = Math.round(bandWidth * 1000) / 1000;
  if (mapCache.has(key)) return mapCache.get(key);
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = 192;
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;
  const pixels = ctx.createImageData(192, 192);
  for (let y = 0; y < 192; y++) for (let x = 0; x < 192; x++) {
    const [dx, dy] = radialDisplacement(x / 191 * 2 - 1, y / 191 * 2 - 1, key);
    const index = (y * 192 + x) * 4;
    pixels.data[index] = Math.round(128 + clamp(dx, -1, 1) * 127);
    pixels.data[index + 1] = Math.round(128 + clamp(dy, -1, 1) * 127);
    pixels.data[index + 2] = 128; pixels.data[index + 3] = 255;
  }
  ctx.putImageData(pixels, 0, 0);
  const url = canvas.toDataURL('image/png');
  const map = {url,canvas};
  if (mapCache.size >= 12) mapCache.delete(mapCache.keys().next().value);
  mapCache.set(key, map);
  return map;
}

function normalized(input, base, initial = false) {
  const result = { ...base, ...input, warmup: { ...base.warmup, ...input.warmup } };
  if (base.surface || input.surface) {
    const material = {...base.surface,...input.surface};
    // Initial legacy presets inherit coupled tint/shadow values before defaults
    // fill the new controls. Later partial edits preserve their independence.
    if (initial && input.surface) for (const key of ['videoTintOpacity','shadowCenterOpacity','shadowCenterSpread','videoShadowOpacity','videoShadowSpread']) {
      if (!Object.hasOwn(input.surface,key)) delete material[key];
    }
    result.surface = normalizeButtonMaterial(material);
  }
  // Presets predating the source-light clock retain their original timing.
  const inheritedDuration = Number.isFinite(input.duration) ? input.duration : base.duration;
  const sourceDuration = input.coreDuration ?? (Number.isFinite(input.duration) ? inheritedDuration : base.coreDuration);
  result.coreDuration = clamp(Number.isFinite(sourceDuration) ? sourceDuration : inheritedDuration,80,4000);
  result.coreEnvelope = normalizeEnvelope(input.coreEnvelope || input.envelope || base.coreEnvelope || result.envelope);
  const sourceFade = input.warmup?.releaseFade ?? (Number.isFinite(input.duration) ? inheritedDuration * .3 : base.warmup?.releaseFade);
  result.warmup.releaseFade = clamp(Number.isFinite(sourceFade) ? sourceFade : inheritedDuration * .3,0,2000);
  const warmupEnvelope = input.warmup?.coreEnvelope ?? (Number.isFinite(input.duration) ? null : base.warmup?.coreEnvelope);
  result.warmup.coreEnvelope = normalizeEnvelope(warmupEnvelope || [0,.25,.5,.75,1].map(t=>({t,value:1})),{zeroEnds:false});
  const upward = input.warmup?.stretchY ?? (Number.isFinite(input.duration) ? 0 : base.warmup?.stretchY);
  result.warmup.stretchY = Number.isFinite(upward) ? clamp(upward,0,.16) : 0;
  if (base.clickHighlightSize !== undefined || input.clickHighlightSize !== undefined) {
    const clickSize = input.clickHighlightSize ?? (Number.isFinite(input.duration) ? Math.min(result.highlightSize ?? base.highlightSize,.12) : base.clickHighlightSize);
    result.clickHighlightSize = Number.isFinite(clickSize) ? clamp(clickSize,.05,1) : .12;
  }
  const sourceMotion = input.coreMotion ?? (Number.isFinite(input.duration) ? {} : base.coreMotion) ?? {};
  result.coreMotion = {};
  for (const name of ['startScale','releaseScale','endScale']) result.coreMotion[name] = Number.isFinite(sourceMotion[name]) ? clamp(sourceMotion[name],.1,3) : 1;
  result.coreMotion.contractStart = Number.isFinite(sourceMotion.contractStart) ? clamp(sourceMotion.contractStart,0,.95) : 0;
  for (const name of ['contractCurve','expandCurve']) result.coreMotion[name] = Array.isArray(sourceMotion[name]) && sourceMotion[name].length === 4 && sourceMotion[name].every(Number.isFinite) ? sourceMotion[name].map(value=>clamp(value)) : [0,0,1,1];
  const bounds = { duration: [200, 4000], strength: [0, 64], width: [.08, .8], radius: [.2, 1.6], dispersion: [0, 8], glow: [0, 1], sheen: [0, 1], coreGlow: [0, 1], highlightSize: [.05, 1], ringSoftness: [.05, 1], stretch: [0, .08], stretchDuration: [200, 4000], stretchDelay: [0, 2000], lift: [0, 12], hoverScale: [1, 1.12] };
  for (const [name, [min, max]] of Object.entries(bounds)) result[name] = Number.isFinite(result[name]) ? clamp(result[name], min, max) : base[name];
  for (const name of ['travel', 'stretchTravel']) result[name] = Array.isArray(result[name]) && result[name].length === 4 && result[name].every(Number.isFinite) ? result[name].map(value => clamp(value)) : [...base[name]];
  for (const name of ['envelope', 'stretchEnvelope']) result[name] = normalizeEnvelope(result[name] || base[name]);
  result.origin = { x: clamp(result.origin?.x ?? base.origin.x), y: clamp(result.origin?.y ?? base.origin.y) };
  result.spectrum = (result.spectrum || base.spectrum).map(stop => ({ ...stop })).sort((a, b) => a.position - b.position);
  result.spectrumShift = (result.spectrumShift || base.spectrumShift).map(point => ({ ...point, ...(point.ease ? {ease:[...point.ease]} : {}) })).sort((a, b) => a.t - b.t);
  result.warmup.curve = [...result.warmup.curve];
  return result;
}
const rgba = (hex, alpha) => `rgba(${parseInt(hex.slice(1, 3), 16)},${parseInt(hex.slice(3, 5), 16)},${parseInt(hex.slice(5, 7), 16)},${alpha})`;
function multiplyColorAlpha(color, amount, tintColor = null) {
  if (color.trim() === 'transparent') return color;
  const components = color.trim().match(/^rgba?\(([^)]+)\)$/i)?.[1].trim().split(/[\s,/]+/);
  if (!components || components.length < 3 || components.length > 4) return color;
  const numbers = components.map((part,index)=>Number.parseFloat(part)*(part.endsWith('%') ? (index < 3 ? 2.55 : .01) : 1));
  if (numbers.some(value=>!Number.isFinite(value))) return color;
  const alpha = Number(clamp((numbers[3] ?? 1)*amount).toFixed(6));
  const channels = tintColor ? [1,3,5].map(index=>parseInt(tintColor.slice(index,index+2),16)) : numbers.slice(0,3);
  return `rgba(${channels.join(',')},${alpha})`;
}
function gradientSet(config, width) {
  const sigma = rippleSigma(width), band = Math.min(sigma * 2.5, .27);
  const feather = Math.min(sigma * .5, .99 - RIPPLE_CENTER - band);
  const position = value => `${(clamp(value) * 100).toFixed(3)}%`;
  const spectrum = config.spectrum.map(stop => {
    const alpha = .18 + Math.sin(Math.PI * stop.position) * .72;
    return `${rgba(stop.color, alpha.toFixed(3))} ${position(RIPPLE_CENTER + (stop.position * 2 - 1) * band)}`;
  });
  const color = `radial-gradient(circle closest-side, transparent ${position(RIPPLE_CENTER - band - feather)},${spectrum.join(',')},transparent ${position(RIPPLE_CENTER + band + feather)})`;
  const softness = Math.min(sigma * (.3 + config.ringSoftness * 1.6), (1 - RIPPLE_CENTER - .005) / 2.7);
  const white = [[-2.7, 0], [-2, .02], [-1.3, .12], [-.65, .45], [0, .94], [.65, .45], [1.3, .12], [2, .02], [2.7, 0]].map(([offset, alpha]) => `rgba(255,255,255,${alpha}) ${position(RIPPLE_CENTER + softness * offset)}`);
  return { color, highlight: `radial-gradient(circle closest-side,${white.join(',')})` };
}

/** Content pixels bend inside the root shell, whose clipping is owned by integration. */
export function createGlassSurface(element, { kind = 'button', content, settings = {}, video = null, onProgress, renderer = null } = {}) {
  if (!(element instanceof HTMLElement)) throw new TypeError('A glass surface requires an HTMLElement.');
  if (!(content instanceof HTMLElement) || content === element || !element.contains(content)) throw new TypeError('content must be a child HTMLElement containing the pixels to refract.');
  const base = GLASS_DEFAULTS[kind] || GLASS_DEFAULTS.button;
  const isVideoButton = Boolean(video) || element.classList.contains('hero-apply');
  let config = normalized(settings, base, true);
  const id = `sr-glass-${++sequence}`;
  let version = 0, destroyed = false, current = null, mapKey = '', filterHasRGB, opticalPhase = '', coreBackgroundDirty = true;
  let size = { width: 1, height: 1 }, displacementNodes = [], mapNode, releaseMap, gatheringMap, gradients;
  const safari = /safari/i.test(navigator.userAgent) && !/chrome|chromium|android/i.test(navigator.userAgent);
  const media = window.matchMedia('(prefers-reduced-motion: reduce)');
  const original = { filter: content.style.filter, transform: content.style.transform, transformOrigin: content.style.transformOrigin };
  const ownClasses = ['sr-glass-surface', ...(kind === 'button' ? ['sr-glass-button'] : [])].filter(name => !element.classList.contains(name));
  if (getComputedStyle(element).position === 'static') ownClasses.push('sr-glass-positioned');
  element.classList.add(...ownClasses);
  const contentHadClass = content.classList.contains('sr-glass-content'); content.classList.add('sr-glass-content');
  const previousLift = element.style.getPropertyValue('--sr-glass-lift'), previousScale = element.style.getPropertyValue('--sr-glass-hover-scale');
  const materialProperties = ['--glass-tint','--glass-shine','--glass-edge','--glass-edge-base','--glass-edge-fallback','--sr-glass-blur','--sr-glass-saturation','--sr-glass-shine-strength','--sr-glass-edge-strength'];
  const previousMaterial = kind === 'button' ? materialProperties.map(name=>({name,value:element.style.getPropertyValue(name),priority:element.style.getPropertyPriority(name)})) : [];
  let materialBase = null, buttonMaterial = null;
  const previousBleed = element.style.getPropertyValue('--sr-glass-bleed');
  const restoreMaterial = () => {
    for (const {name,value,priority} of previousMaterial) {
      if (value) element.style.setProperty(name,value,priority); else element.style.removeProperty(name);
    }
  };
  const captureMaterial = () => {
    if (kind !== 'button') return;
    const computed = getComputedStyle(element);
    materialBase = Object.fromEntries(['--glass-tint','--glass-shine','--glass-edge','--glass-edge-base','--glass-edge-fallback'].map(name=>[name,computed.getPropertyValue(name).trim()]));
  };
  const applyMaterial = () => {
    if (!materialBase) return;
    const surface = config.surface || {tintColor:null,tintOpacity:1,blur:2,saturation:1,shine:1,edge:1};
    const tintOpacity = isVideoButton ? surface.videoTintOpacity ?? surface.tintOpacity : surface.tintOpacity;
    element.style.setProperty('--glass-tint',multiplyColorAlpha(materialBase['--glass-tint'],tintOpacity,surface.tintColor));
    const shine = Number.parseFloat(materialBase['--glass-shine']);
    element.style.setProperty('--glass-shine',String((Number.isFinite(shine) ? shine : 1)*surface.shine));
    for (const name of ['--glass-edge','--glass-edge-base','--glass-edge-fallback']) element.style.setProperty(name,multiplyColorAlpha(materialBase[name],surface.edge));
    element.style.setProperty('--sr-glass-blur',`${surface.blur}px`);
    element.style.setProperty('--sr-glass-saturation',String(surface.saturation));
    element.style.setProperty('--sr-glass-shine-strength',String(surface.shine));
    element.style.setProperty('--sr-glass-edge-strength',String(surface.edge));
    buttonMaterial?.update(config);
  };
  captureMaterial();
  const stopMaterialObserver = kind === 'button' ? watchMaterial({restore:restoreMaterial,capture:captureMaterial,apply:applyMaterial}) : ()=>{};
  const overlay = document.createElement('span'); overlay.className = 'sr-glass-fx'; overlay.setAttribute('aria-hidden', 'true');
  const glow = document.createElement('span'), sheen = document.createElement('span'), core = document.createElement('span');
  glow.className = 'sr-glass-glow'; sheen.className = 'sr-glass-sheen'; core.className = 'sr-glass-core';
  core.hidden = true;
  overlay.append(glow, sheen, core); element.append(overlay);
  ensureDefinitions();
  const filter = svg('filter', { id, filterUnits: 'userSpaceOnUse', primitiveUnits: 'userSpaceOnUse', 'color-interpolation-filters': 'sRGB' });
  definitions.append(filter);
  function buildFilter() {
    filterHasRGB = config.dispersion > .001;
    filter.replaceChildren();
    const neutral = svg('feFlood', { 'flood-color': 'rgb(128,128,128)', result: 'neutral' });
    mapNode = svg('feImage', { preserveAspectRatio: 'none', result: 'mapImage' });
    const composite = svg('feComposite', { in: 'mapImage', in2: 'neutral', operator: 'over', result: 'rawMap' });
    // Keep this fractional centering matrix: Safari rounds a lookup-table
    // replacement differently, which moves the displacement by a pixel.
    const center = svg('feColorMatrix', { in: 'rawMap', type: 'matrix', values: '1 0 0 0 -0.001960784314 0 1 0 0 -0.001960784314 0 0 1 0 0 0 0 0 1 0', result: 'map' });
    filter.append(neutral, mapNode, composite, center);
    displacementNodes = [];
    const displacement = (result) => {
      const node = svg('feDisplacementMap', { in: 'SourceGraphic', in2: 'map', scale: 0, xChannelSelector: 'R', yChannelSelector: 'G', result });
      displacementNodes.push(node); filter.append(node);
    };
    if (filterHasRGB) {
      displacement('warpedR'); displacement('warpedG'); displacement('warpedB');
      // Independent channel lookup tables avoid Safari's general matrix
      // calculation (constant alpha offsets disable its vImage fast path).
      // Isolate each unpremultiplied channel and force temporary opacity.
      // Screen is exactly addition for disjoint RGB channels: a+b-a*b = a+b.
      // Restore the green/base alpha after combining so translucent edges and
      // shadows retain their opacity instead of accumulating three alpha passes.
      for (const channel of ['R', 'G', 'B']) {
        const isolate = svg('feComponentTransfer', {in: `warped${channel}`, result: `channel${channel}`});
        for (const other of ['R', 'G', 'B']) if (other !== channel) isolate.append(svg(`feFunc${other}`, {type:'linear', slope:0, intercept:0}));
        isolate.append(svg('feFuncA', {type:'linear', slope:0, intercept:1}));
        filter.append(isolate);
      }
      filter.append(
        svg('feBlend', { in: 'channelR', in2: 'channelG', mode: 'screen', result: 'redGreen' }),
        svg('feBlend', { in: 'redGreen', in2: 'channelB', mode: 'screen', result: 'rgb' }),
        svg('feComposite', { in: 'rgb', in2: 'warpedG', operator: 'in' }),
      );
    } else displacement('warped');
    mapKey = '';
  }

  function measure() {
    size = { width: Math.max(1, content.offsetWidth), height: Math.max(1, content.offsetHeight) };
    const pad = kind === 'button' ? buttonBleed(config,size) : Math.ceil(Math.max(config.strength, config.warmup.strength) + config.dispersion + 3);
    if(kind === 'button')element.style.setProperty('--sr-glass-bleed',`${pad}px`);
    const filterPad = kind === 'button' ? buttonFilterPadding(config,size,isVideoButton) : pad;
    filter.setAttribute('x', -filterPad); filter.setAttribute('y', -filterPad);
    filter.setAttribute('width', size.width + filterPad * 2); filter.setAttribute('height', size.height + filterPad * 2);
  }
  function prepareOptics() {
    releaseMap = rippleMap(config.width); gatheringMap = rippleMap(config.warmup.width);
    gradients = { release: gradientSet(config, config.width), warmup: gradientSet(config, config.warmup.width) };
    mapKey = opticalPhase = '';
    // Build the large origin gradient only when it actually becomes visible.
    coreBackgroundDirty = true;
    element.style.setProperty('--sr-glass-lift', `${config.lift}px`);
    element.style.setProperty('--sr-glass-hover-scale', String(config.hoverScale));
    applyMaterial();
  }
  function restore() {
    renderer?.hide();
    content.style.filter = original.filter || 'none'; content.style.transform = original.transform; content.style.transformOrigin = original.transformOrigin;
    overlay.classList.remove('sr-glass-visible');
    for (const layer of [glow, sheen, core]) layer.style.opacity = '0';
    if (!core.hidden) core.hidden = true;
    element.classList.remove('sr-glass-active');
    buttonMaterial?.refreshBackdrop();
  }
  function render(progress, origin, phase = 'release', fromWarmup = false, {notify = true, click = false} = {}) {
    if (destroyed) return;
    click = click && kind === 'quote' && phase === 'release';
    fromWarmup = fromWarmup && !click;
    current = { progress: clamp(progress), origin, phase, fromWarmup, click };
    const gathering = phase === 'warmup';
    const state = gathering ? warmupFrame(progress, config, size, origin) : waveFrame(progress, config, size, origin);
    const layer = gathering ? config.warmup : config;
    const {coreAmount,stretchAmount} = gathering
      ? {coreAmount:config.warmup.coreGlow * state.core,stretchAmount:config.warmup.stretch * state.build}
      : releaseAmounts(state,config,fromWarmup);
    const upwardAmount = upwardStretchAt(progress,config,{phase,fromWarmup});
    const hasPixels = state.amplitude > .00001 || coreAmount > .00001 || Math.abs(stretchAmount) > .000001 || upwardAmount > .000001;
    if (!hasPixels || document.hidden) restore();
    else {
      const reduced = media.matches;
      const strength = reduced ? 0 : layer.strength * state.amplitude;
      const dispersion = reduced ? 0 : config.dispersion * state.amplitude * (gathering ? .45 : 1);
      const mapURL = !reduced && (strength || dispersion) ? (gathering ? gatheringMap : releaseMap) : null;
      if (mapURL && renderer?.render(state,strength,dispersion,mapURL.canvas)) {
        content.style.filter = original.filter || 'none';
      } else if (mapURL) {
        if (mapKey !== phase) { mapNode.setAttribute('href', mapURL.url); mapKey = phase; }
        mapNode.setAttribute('x', state.x - state.width / 2); mapNode.setAttribute('y', state.y - state.height / 2);
        mapNode.setAttribute('width', state.width); mapNode.setAttribute('height', state.height);
        if (filterHasRGB) [strength + dispersion / 2, strength, strength - dispersion / 2].forEach((value, index) => displacementNodes[index].setAttribute('scale', value * 2));
        else displacementNodes[0].setAttribute('scale', strength * 2);
        // Retain the existing WebKit invalidation workaround for older Safari.
        if (safari) filter.id = `${id}-${++version}`;
        content.style.filter = `url("#${filter.id}")`;
      } else {renderer?.hide();content.style.filter = original.filter || 'none';}
      const stretch = reduced ? 0 : stretchAmount;
      const vertical = reduced ? 0 : upwardAmount;
      const verticalShift = -size.height*vertical*(1-origin.y);
      content.style.transform = stretch || vertical ? `${original.transform} translateY(${verticalShift}px) scale(${1 + stretch}, ${1 - stretch * .3 + vertical})`.trim() : original.transform;
      content.style.transformOrigin = `${origin.x * 100}% ${origin.y * 100}%`;
      element.classList.add('sr-glass-active'); overlay.classList.add('sr-glass-visible');
      if (opticalPhase !== phase) {
        glow.style.backgroundImage = gradients[phase].color;
        sheen.style.backgroundImage = gradients[phase].highlight;
        opticalPhase = phase;
      }
      const position = `translate3d(${state.x}px, ${state.y}px, 0) translate(-50%, -50%)`;
      const calm = (reduced ? .45 : 1) * (click ? quoteClickLightOnset(state.elapsed,config) : 1);
      for (const [layerNode,amount] of [[glow,layer.glow],[sheen,layer.sheen]]) {
        const opacity=amount*state.amplitude*calm;
        layerNode.style.opacity=String(opacity);
        if (opacity > 0) {
          layerNode.style.width = `${state.width}px`; layerNode.style.height = `${state.height}px`; layerNode.style.transform = position;
          if (layerNode===glow) glow.style.filter=`hue-rotate(${state.hue.toFixed(3)}deg)`;
        }
      }
      const coreOpacity=clamp(coreAmount)*calm;
      if (core.hidden!==(coreOpacity<=0)) core.hidden=coreOpacity<=0;
      core.style.opacity=String(coreOpacity);
      if (coreOpacity > 0) {
        if (coreBackgroundDirty) {
          const halo=config.spectrum.map(stop=>`${rgba(stop.color,.2)} ${(28+stop.position*58).toFixed(2)}%`).join(',');
          core.style.backgroundImage=`var(--sr-glass-core-light),radial-gradient(circle closest-side,transparent 12%,${halo},transparent 100%)`;
          coreBackgroundDirty=false;
        }
        const coreSize=originDiameter(config,size,{kind,phase,click});
        const coreScale=originScaleAt(progress,config,{phase,fromWarmup,reducedMotion:reduced});
        core.style.width=`${coreSize}px`;core.style.height=`${coreSize}px`;core.style.transform=`${position} scale(${coreScale})`;
        core.style.filter=`hue-rotate(${state.hue.toFixed(3)}deg)`;
      }
    }
    buttonMaterial?.refreshBackdrop();
    if (notify && typeof onProgress === 'function') onProgress({ ...current, mode: 'ripple', active: active.has(api) });
  }
  function originValue(origin) {
    return { x: clamp(Number.isFinite(origin?.x) ? origin.x : config.origin.x), y: clamp(Number.isFinite(origin?.y) ? origin.y : config.origin.y) };
  }
  const api = {
    play({ x, y, fromWarmup = false, click = false } = {}) {
      if (destroyed || document.hidden) return;
      const origin = originValue({ x, y }), began = performance.now();
      const duration = media.matches ? Math.min(animationDuration(config), 200) : animationDuration(config);
      measure(); render(0, origin, 'release', fromWarmup, {click});
      start(api, time => {
        const progress = clamp((time - began) / duration);
        if (progress >= 1) stop(api);
        render(progress, origin, 'release', fromWarmup, {click});
      });
    },
    seek(progress, origin = config.origin, { fromWarmup = false, click = false } = {}) {
      if (destroyed) return;
      stop(api); if (!observer) measure(); render(Number.isFinite(progress) ? progress : 0, originValue(origin), 'release', fromWarmup, {click});
    },
    warmup(progress, origin = config.origin) {
      if (destroyed) return;
      stop(api); if (!observer) measure(); render(Number.isFinite(progress) ? progress : 0, originValue(origin), 'warmup');
    },
    update(settings = {}) {
      if (destroyed) return;
      config = normalized(settings, config);
      if (filterHasRGB !== (config.dispersion > .001)) buildFilter();
      prepareOptics(); measure();
      if (current) render(current.progress, current.origin, current.phase, current.fromWarmup, {click:current.click});
    },
    reset() {
      if (destroyed) return;
      stop(api); current = null; restore();
      if (typeof onProgress === 'function') onProgress({ progress: 0, mode: 'ripple', phase: 'release', origin: { ...config.origin }, active: false });
    },
    destroy() {
      if (destroyed) return;
      api.reset(); destroyed = true; renderer?.destroy();
      observer?.disconnect(); window.removeEventListener('resize', resize); media.removeEventListener?.('change', reducedChange);
      buttonMaterial?.destroy();buttonMaterial=null;
      if(previousBleed)element.style.setProperty('--sr-glass-bleed',previousBleed);else element.style.removeProperty('--sr-glass-bleed');
      stopMaterialObserver();restoreMaterial();
      overlay.remove(); filter.remove(); element.classList.remove(...ownClasses);
      if (!contentHadClass) content.classList.remove('sr-glass-content');
      content.style.filter = original.filter;
      if (previousLift) element.style.setProperty('--sr-glass-lift', previousLift); else element.style.removeProperty('--sr-glass-lift');
      if (previousScale) element.style.setProperty('--sr-glass-hover-scale', previousScale); else element.style.removeProperty('--sr-glass-hover-scale');
      surfaces.delete(api);
      if (!surfaces.size) { rootSVG.remove(); rootSVG = definitions = null; document.removeEventListener('visibilitychange', onVisibility); }
    },
    refreshMaterial() { buttonMaterial?.refreshBackdrop(); },
    getSettings() { return structuredClone(config); },
  };
  const resize = () => { measure(); if (current) render(current.progress, current.origin, current.phase, current.fromWarmup, {notify:false,click:current.click}); };
  const reducedChange = () => api.reset();
  const observer = typeof ResizeObserver === 'function' ? new ResizeObserver(resize) : null;
  observer?.observe(content); if (!observer) window.addEventListener('resize', resize, { passive: true });
  media.addEventListener?.('change', reducedChange);
  buildFilter(); prepareOptics(); measure(); restore(); surfaces.add(api);
  renderer?.setRedraw(()=>{if(current&&!destroyed)render(current.progress,current.origin,current.phase,current.fromWarmup,{notify:false,click:current.click});});
  if(kind === 'button')buttonMaterial=createButtonMaterial(element,content,config,{video});
  return api;
}

/** Diagnostics create no background work. */
export function getGlassDiagnostics() { return { surfaces: surfaces.size, active: active.size, scheduled: Boolean(raf), mapsCreated: Boolean(mapCache.size), mapCount: mapCache.size }; }
