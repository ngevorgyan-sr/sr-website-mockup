import {build} from 'vite';
import {readFile,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';

const root=path.dirname(fileURLToPath(import.meta.url));
await build({
  root,configFile:false,publicDir:false,
  build:{
    target:'es2022',outDir:'dist',emptyOutDir:true,minify:true,
    lib:{entry:path.join(root,'src/main.js'),name:'SpeedrunGlassStudio',formats:['iife'],fileName:()=> 'glass-studio.js',cssFileName:'glass-studio'},
  },
});
const [template,css,script,poster,font]=await Promise.all([
  readFile(path.join(root,'index.template.html'),'utf8'),
  readFile(path.join(root,'dist/glass-studio.css'),'utf8'),
  readFile(path.join(root,'dist/glass-studio.js'),'utf8'),
  readFile(path.join(root,'assets/poster.png')),
  readFile(path.join(root,'assets/MessinaSans-Regular.otf')),
]);
const fontCSS=`@font-face{font-family:Messina;src:url('data:font/otf;base64,${font.toString('base64')}') format('opentype');font-display:swap}`;
const html=template
  .replace('<!-- STUDIO_STYLES -->',()=>`<style>${(fontCSS+css).replace(/<\/style/gi,'<\\/style')}</style>`)
  .replace('poster="assets/poster.png"',()=>`poster="data:image/png;base64,${poster.toString('base64')}"`)
  .replace('<!-- STUDIO_SCRIPT -->',()=>`<script>${script.replace(/<\/script/gi,'<\\/script')}</script>`);
await writeFile(path.join(root,'index.html'),html);
console.log('Built standalone Studio index.html with embedded renderer, editor, font and poster.');
